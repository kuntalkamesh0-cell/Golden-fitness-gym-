# Security Specification — Golden Fitness Gym Cloud Firestore

## 1. Data Invariants
1. Every gym owner document at `/owners/{ownerUid}` belongs strictly to `request.auth.uid == ownerUid`; no other authenticated or unauthenticated user can read, list, create, update, or delete it.
2. Every subcollection document under `/owners/{ownerUid}/{subcollection}/{docId}` must satisfy `ownerUid == request.auth.uid`, match the path `{ownerUid}`, pass schema/type/size validation (`isValid*`), and preserve immutable `ownerUid` and `serverCreatedAt` on updates.
3. Document IDs `{memberId}`, `{trainerId}`, `{paymentId}`, `{historyId}`, `{attendanceId}`, `{workoutId}`, `{dietId}` must match `^[a-zA-Z0-9_-]+$` and be <= 128 characters.
4. `serverCreatedAt` on create and `serverUpdatedAt` on create/update must equal `request.time`.
5. `paymentMethods` array on `GymOwner` is bounded to `1..20` entries, with string type verification.
6. Ghost / shadow fields outside each entity schema are rejected via `keys().hasAll(...) && keys().hasOnly(...)`.
7. Completed attendance visits (`LEFT GYM`) cannot have `ownerUid` or `serverCreatedAt` altered.

## 2. Dirty Dozen Attack Payloads (Must All Return PERMISSION_DENIED)
1. **Unauthenticated Read**: `GET /owners/uidA/members/GFG-101` with `auth = null`.
2. **Cross-Tenant Read**: `GET /owners/uidA/members/GFG-101` authenticated as `uidB`.
3. **Cross-Tenant List**: `LIST /owners/uidA/payments` authenticated as `uidB`.
4. **Identity Spoofing on Create**: `CREATE /owners/uidB/members/GFG-101` by `uidB` with `ownerUid: "uidA"`.
5. **Shadow / Ghost Field Injection**: `CREATE /owners/uidA/members/GFG-101` by `uidA` including `"isAdmin": true`.
6. **ID Poisoning**: `CREATE /owners/uidA/members/bad$id..slash` by `uidA`.
7. **Server Timestamp Forgery**: `CREATE /owners/uidA/payments/PAY-1` by `uidA` with client-supplied `serverCreatedAt` != `request.time`.
8. **Immutable Field Tampering**: `UPDATE /owners/uidA/members/GFG-101` by `uidA` attempting to change `ownerUid` or `serverCreatedAt`.
9. **Array Bombing**: `UPDATE /owners/uidA` setting `paymentMethods` to 25 items (> max 20).
10. **Invalid Enum Injection**: `CREATE /owners/uidA/attendance/ATT-1` with `status: "HACKED"`.
11. **Negative Financial Spoof**: `CREATE /owners/uidA/members/GFG-101` with `membershipFee: -500`.
12. **PII Oversized String Bomb**: `CREATE /owners/uidA/members/GFG-101` with `notes` > 1000 chars or `name` > 140 chars.
