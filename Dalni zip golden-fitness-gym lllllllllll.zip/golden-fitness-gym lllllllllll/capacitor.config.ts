import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fitnessclubhouse.goldenfitnessgym',
  appName: 'Golden Fitness Gym',
  webDir: 'dist',
  backgroundColor: '#09090B',
  server: {
    androidScheme: 'https',
    cleartext: true,
    allowNavigation: ['*'],
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    backgroundColor: '#09090B',
  },
};

export default config;
