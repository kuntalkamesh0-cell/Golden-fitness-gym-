/**
 * Security Rules Specification & Verification Cases for Golden Fitness Gym
 * References /security_spec.md invariants and Dirty Dozen adversarial payloads.
 */
export const FIRESTORE_SECURITY_TEST_CASES = [
  {
    name: 'Unauthenticated read on /owners/{ownerUid}/members/{memberId} is denied',
    auth: null,
    op: 'get',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Cross-tenant read on /owners/ownerA/members/GFG-101 by ownerB is denied',
    auth: { uid: 'ownerB' },
    op: 'get',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Cross-tenant list on /owners/ownerA/payments by ownerB is denied',
    auth: { uid: 'ownerB' },
    op: 'list',
    path: '/owners/ownerA/payments',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Owner can create and read own /owners/{ownerUid} and subcollections when schema matches',
    auth: { uid: 'ownerA' },
    op: 'create',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'ALLOW',
  },
  {
    name: 'Shadow/ghost field injection (isAdmin: true) is denied',
    auth: { uid: 'ownerA' },
    op: 'create',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Negative financial spoof (membershipFee < 0) is denied',
    auth: { uid: 'ownerA' },
    op: 'create',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Immutable ownerUid / serverCreatedAt tampering on update is denied',
    auth: { uid: 'ownerA' },
    op: 'update',
    path: '/owners/ownerA/members/GFG-101',
    expect: 'PERMISSION_DENIED',
  },
  {
    name: 'Invalid attendance status enum outside INSIDE GYM / LEFT GYM is denied',
    auth: { uid: 'ownerA' },
    op: 'create',
    path: '/owners/ownerA/attendance/ATT-1',
    expect: 'PERMISSION_DENIED',
  },
] as const;
