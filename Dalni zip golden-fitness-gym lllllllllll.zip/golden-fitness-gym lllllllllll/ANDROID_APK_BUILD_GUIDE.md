# Golden Fitness Gym — Android APK Build & Source Export Guide

This project is pre-configured with **Capacitor Android**, **Firebase Authentication**, **Cloud Firestore** (with offline IndexedDB persistence), **QR Camera Attendance**, **Member Management**, **Custom Fees & PDF Receipts**, **Workout & Diet Plans**, **Branded Splash Screen**, and **PWA** assets—ready to compile into an Android `.apk` or `.aab` without modifying any existing features.

---

## 1. Exported Source Package (Privacy-Safe)

When you click **Download Android APK Source ZIP** in **Settings → Backup & Restore** (or run `npm run export:source`), the archive `golden-fitness-gym-android-source.zip` includes:
- `src/` — All React + TypeScript UI views, Splash Screen, modals, hooks, English/Hindi translations, custom fee engine, WhatsApp templates, printable receipts/reports, and `src/services/firestoreSync.ts`
- `public/` & `src/assets/` — App icons (`pwa-192x192.png`, `pwa-512x512.png`, `icon.svg`) and gym visual assets
- `.env.example`, `firebase-applet-config.example.json`, `firebase-applet-config.json`, `firebase-blueprint.json`, `firestore.rules` — Firebase configuration templates and security rules
- `capacitor.config.ts` — Native Android wrapper configuration (`appName: "Golden Fitness Gym"`, `appId: "com.fitnessclubhouse.goldenfitnessgym"`, `webDir: "dist"`)
- `android/` — Ready-to-build Android Gradle & Android Studio project with `Golden Fitness Gym` as installed app name and `CAMERA`, `INTERNET`, `ACCESS_NETWORK_STATE`, and media storage permissions pre-configured
- `server.ts`, `server/`, `package.json`, `vite.config.ts`, `tsconfig.json`

*Note: Local databases (`data/`, `*.db`), `.env` secrets, keystores (`*.jks`), and personal member/payment/attendance data are strictly excluded from the source ZIP export.*

---

## 2. Prerequisites on Your Computer

1. **Node.js 20+** (`https://nodejs.org`)
2. **Java JDK 17 or 21** (Android Studio bundles JetBrains Runtime / JBR automatically)
3. **Android Studio** (`https://developer.android.com/studio`) with:
   - Android SDK Platform 34 or 35
   - Android SDK Build-Tools
   - Android SDK Platform-Tools (`adb`)

---

## 3. Build an Android APK (Step-by-Step)

### Step A: Extract & Install Dependencies
```bash
unzip golden-fitness-gym-android-source.zip
cd golden-fitness-gym
npm install
```

### Step B: Build the Web Bundle & Sync to Android
```bash
npm run android:sync
```
*(Runs `npm run build` followed by `npx cap sync android`.)*

### Step C1: Build Debug APK via Command Line (Fastest for Direct Phone Install)
On **macOS / Linux**:
```bash
cd android
./gradlew assembleDebug
```
On **Windows (PowerShell / CMD)**:
```powershell
cd android
.\gradlew.bat assembleDebug
```
Your installable APK will be generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

Install directly onto a USB-connected Android phone (with USB Debugging ON):
```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

### Step C2: Build Signed Release APK / Play Store `.aab` via Android Studio
1. Run `npx cap open android` (or open the `android/` folder in **Android Studio**).
2. Wait for Gradle Sync to finish.
3. Click **Build → Generate Signed Bundle / APK...**.
4. Choose **APK** (for direct distribution) or **Android App Bundle** (for Google Play Store).
5. Create or select a `.jks` signing keystore file, choose **release**, and click **Create**.
6. Your signed APK will be output to `android/app/release/app-release.apk`.

---

## 4. Firebase & Android Checklist

1. **Authentication**: Capacitor serves the app from `https://localhost`, which is included in Firebase Authentication's default Authorized Domains. Confirm **Email/Password** sign-in is enabled in Firebase Console → Authentication → Sign-in method.
2. **Camera QR Scanner**: `android/app/src/main/AndroidManifest.xml` includes `<uses-permission android:name="android.permission.CAMERA" />` and `MainActivity.java` requests camera permission automatically on startup.
3. **Offline Sync**: Firestore IndexedDB persistence stays active inside Android WebView so attendance, fees, and member records continue offline and sync automatically when internet returns.
