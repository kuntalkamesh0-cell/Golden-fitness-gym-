import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'fitness_club_house.db');
export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function generateGymQrSecret(): string {
  return `GFG-SEC-${crypto.randomBytes(8).toString('hex').toUpperCase()}`;
}

function ensureColumn(table: string, column: string, definition: string) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      gymName TEXT NOT NULL,
      gymLogo TEXT NOT NULL,
      gymAddress TEXT NOT NULL,
      contactNumber TEXT NOT NULL,
      ownerName TEXT NOT NULL,
      ownerMobile TEXT NOT NULL,
      paymentMethods TEXT NOT NULL,
      theme TEXT NOT NULL DEFAULT 'dark',
      language TEXT NOT NULL DEFAULT 'en',
      ownerPin TEXT NOT NULL DEFAULT '1234',
      receptionPin TEXT NOT NULL DEFAULT '2222',
      trainerPin TEXT NOT NULL DEFAULT '3333',
      gymQrSecret TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS trainers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      mobile TEXT NOT NULL,
      photo TEXT NOT NULL DEFAULT '',
      specialization TEXT NOT NULL DEFAULT '',
      pin TEXT NOT NULL DEFAULT '3333',
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      whatsapp TEXT NOT NULL,
      age INTEGER NOT NULL DEFAULT 24,
      gender TEXT NOT NULL DEFAULT 'Male',
      address TEXT NOT NULL DEFAULT '',
      joiningDate TEXT NOT NULL,
      photo TEXT NOT NULL DEFAULT '',
      durationValue INTEGER NOT NULL DEFAULT 1,
      durationUnit TEXT NOT NULL DEFAULT 'months',
      startDate TEXT NOT NULL,
      expiryDate TEXT NOT NULL,
      membershipFee REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      amountPaid REAL NOT NULL DEFAULT 0,
      remainingAmount REAL NOT NULL DEFAULT 0,
      paymentMethod TEXT NOT NULL DEFAULT 'Cash',
      membershipStatus TEXT NOT NULL DEFAULT 'Active',
      trainerId TEXT NOT NULL DEFAULT '',
      trainerName TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      qrToken TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      memberId TEXT NOT NULL,
      amount REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      paymentMethod TEXT NOT NULL,
      paymentDate TEXT NOT NULL,
      type TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      receiptNumber TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      FOREIGN KEY (memberId) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS membership_history (
      id TEXT PRIMARY KEY,
      memberId TEXT NOT NULL,
      actionType TEXT NOT NULL,
      durationValue INTEGER NOT NULL,
      durationUnit TEXT NOT NULL,
      startDate TEXT NOT NULL,
      expiryDate TEXT NOT NULL,
      fee REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      amountPaid REAL NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      createdAt TEXT NOT NULL,
      FOREIGN KEY (memberId) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id TEXT PRIMARY KEY,
      personType TEXT NOT NULL,
      personId TEXT NOT NULL,
      date TEXT NOT NULL,
      entryTime TEXT NOT NULL,
      exitTime TEXT NOT NULL DEFAULT '',
      entryTimestamp TEXT NOT NULL DEFAULT '',
      exitTimestamp TEXT NOT NULL DEFAULT '',
      durationMinutes INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'INSIDE GYM',
      shift TEXT NOT NULL,
      method TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workout_plans (
      id TEXT PRIMARY KEY,
      memberId TEXT NOT NULL,
      trainerId TEXT NOT NULL DEFAULT '',
      muscleGroup TEXT NOT NULL,
      exerciseName TEXT NOT NULL,
      sets TEXT NOT NULL,
      reps TEXT NOT NULL,
      restTime TEXT NOT NULL,
      workoutDays TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (memberId) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS diet_plans (
      id TEXT PRIMARY KEY,
      memberId TEXT NOT NULL UNIQUE,
      trainerId TEXT NOT NULL DEFAULT '',
      breakfast TEXT NOT NULL DEFAULT '',
      lunch TEXT NOT NULL DEFAULT '',
      dinner TEXT NOT NULL DEFAULT '',
      snacks TEXT NOT NULL DEFAULT '',
      mealDetails TEXT NOT NULL DEFAULT '',
      trainerNotes TEXT NOT NULL DEFAULT '',
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (memberId) REFERENCES members(id) ON DELETE CASCADE
    );
  `);

  // Safe non-destructive migrations for existing databases
  ensureColumn('settings', 'gymQrSecret', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('members', 'membershipStatus', "TEXT NOT NULL DEFAULT 'Active'");
  ensureColumn('attendance', 'exitTime', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('attendance', 'entryTimestamp', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('attendance', 'exitTimestamp', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('attendance', 'durationMinutes', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('attendance', 'status', "TEXT NOT NULL DEFAULT 'INSIDE GYM'");

  // Backfill any legacy attendance rows cleanly without touching existing timestamps
  db.exec(`
    UPDATE attendance
    SET entryTimestamp = CASE WHEN entryTimestamp = '' THEN createdAt ELSE entryTimestamp END,
        status = CASE WHEN exitTime != '' THEN 'LEFT GYM' ELSE status END
  `);

  const existingSettings = db
    .prepare('SELECT id, gymQrSecret FROM settings WHERE id = 1')
    .get() as { id: number; gymQrSecret?: string } | undefined;
  if (!existingSettings) {
    seedDefaultSettingsOnly();
  } else if (!existingSettings.gymQrSecret) {
    db.prepare('UPDATE settings SET gymQrSecret = ? WHERE id = 1').run(generateGymQrSecret());
  }
}

function seedDefaultSettingsOnly() {
  db.prepare(`
    INSERT INTO settings (
      id, gymName, gymLogo, gymAddress, contactNumber, ownerName, ownerMobile,
      paymentMethods, theme, language, ownerPin, receptionPin, trainerPin, gymQrSecret
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    1,
    'Golden Fitness Gym',
    '/src/assets/images/gym_club_logo_1795080326591.jpg',
    '',
    '',
    'Owner',
    '',
    JSON.stringify(['Cash', 'UPI', 'Card', 'Bank Transfer']),
    'dark',
    'en',
    '1234',
    '2222',
    '3333',
    generateGymQrSecret()
  );
}

export function resetAllGymData() {
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM workout_plans').run();
    db.prepare('DELETE FROM diet_plans').run();
    db.prepare('DELETE FROM attendance').run();
    db.prepare('DELETE FROM payments').run();
    db.prepare('DELETE FROM membership_history').run();
    db.prepare('DELETE FROM members').run();
    db.prepare('DELETE FROM trainers').run();
  });
  tx();
}

export function getAllData() {
  const settingsRow = db.prepare('SELECT * FROM settings WHERE id = 1').get() as Record<string, unknown>;
  const settings = {
    ...settingsRow,
    paymentMethods: JSON.parse((settingsRow.paymentMethods as string) || '["Cash","UPI"]'),
  };
  const trainers = db.prepare('SELECT * FROM trainers ORDER BY createdAt ASC').all();
  const members = db.prepare('SELECT * FROM members ORDER BY createdAt DESC').all();
  const payments = db.prepare(`
    SELECT p.*, m.name as memberName
    FROM payments p
    LEFT JOIN members m ON m.id = p.memberId
    ORDER BY p.paymentDate DESC, p.createdAt DESC
  `).all();
  const membershipHistory = db.prepare('SELECT * FROM membership_history ORDER BY createdAt DESC').all();
  const attendance = db.prepare('SELECT * FROM attendance ORDER BY createdAt DESC').all();
  const workoutPlans = db.prepare('SELECT * FROM workout_plans ORDER BY updatedAt DESC').all();
  const dietPlans = db.prepare('SELECT * FROM diet_plans ORDER BY updatedAt DESC').all();

  return {
    settings,
    trainers,
    members,
    payments,
    membershipHistory,
    attendance,
    workoutPlans,
    dietPlans,
  };
}
