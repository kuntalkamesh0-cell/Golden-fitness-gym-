import React, { useEffect, useRef, useState } from 'react';
import { Dumbbell } from 'lucide-react';

interface SplashScreenProps {
  onDone: () => void;
  durationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onDone,
  durationMs = 3000,
}) => {
  const [entered, setEntered] = useState(false);
  const [fadingOut, setFadingOut] = useState(false);
  const onDoneRef = useRef(onDone);

  useEffect(() => {
    onDoneRef.current = onDone;
  }, [onDone]);

  useEffect(() => {
    const enterTimer = window.requestAnimationFrame(() => setEntered(true));
    const fadeOutStart = Math.max(1000, durationMs - 400);
    const fadeTimer = window.setTimeout(() => setFadingOut(true), fadeOutStart);
    const doneTimer = window.setTimeout(() => onDoneRef.current(), durationMs);

    return () => {
      window.cancelAnimationFrame(enterTimer);
      window.clearTimeout(fadeTimer);
      window.clearTimeout(doneTimer);
    };
  }, [durationMs]);

  return (
    <div
      role="status"
      aria-label="Golden Fitness Gym splash screen"
      className={`fixed inset-0 z-[100] bg-[#09090B] text-white flex flex-col items-center justify-center px-6 select-none transition-opacity duration-400 ease-out motion-reduce:transition-none ${
        fadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        backgroundImage:
          'radial-gradient(circle at 50% 50%, rgba(245, 183, 0, 0.22) 0%, rgba(212, 175, 55, 0.07) 36%, rgba(9, 9, 11, 1) 72%)',
      }}
    >
      <div
        className={`flex flex-col items-center justify-center text-center max-w-4xl w-full transition-all duration-700 ease-out motion-reduce:transition-none ${
          entered ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-2'
        }`}
      >
        {/* Subtle Gold Fitness Crest */}
        <div className="relative flex items-center justify-center mb-6">
          <div className="absolute w-24 h-24 rounded-full border border-[#F5B700]/20" />
          <div className="w-16 h-16 rounded-full bg-[#121216] border border-[#F5B700]/75 shadow-[0_0_36px_rgba(245,183,0,0.28)] flex items-center justify-center">
            <Dumbbell className="w-7 h-7 text-[#F5B700] -rotate-12" strokeWidth={2.2} />
          </div>
        </div>

        <p className="font-display text-xs sm:text-sm font-semibold tracking-[0.28em] text-zinc-400 mb-6">
          GOLDEN FITNESS GYM
        </p>

        {/* Centered Prominent Attribution */}
        <div className="flex flex-col items-center justify-center">
          <span className="font-display text-sm sm:text-lg md:text-xl font-bold tracking-[0.38em] text-[#EAB308]">
            CREATED BY
          </span>
          <h1
            className="mt-2 font-display text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-[0.06em] leading-[1.08] text-[#F5B700]"
            style={{
              textShadow: '0 0 36px rgba(245, 183, 0, 0.42), 0 2px 12px rgba(0, 0, 0, 0.8)',
            }}
          >
            KAMESH KUNTAL
          </h1>
        </div>

        <div className="mt-7 w-28 h-[2px] bg-gradient-to-r from-transparent via-[#F5B700] to-transparent" />

        {/* Smooth 3-second gold progress sweep */}
        <div className="mt-7 w-52 h-1 rounded-full bg-zinc-900 overflow-hidden border border-zinc-800/80">
          <div
            className="h-full w-full origin-left bg-gradient-to-r from-[#D4AF37] via-[#F5B700] to-[#FACC15] transition-transform ease-linear motion-reduce:transition-none"
            style={{
              transitionDuration: `${Math.max(1000, durationMs - 300)}ms`,
              transform: entered ? 'scaleX(1)' : 'scaleX(0.05)',
            }}
          />
        </div>
      </div>
    </div>
  );
};
