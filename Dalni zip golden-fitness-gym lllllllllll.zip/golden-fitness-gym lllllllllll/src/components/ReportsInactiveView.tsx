import React, { useMemo, useState } from 'react';
import { MessageCircle, Download, AlertTriangle, Printer } from 'lucide-react';
import type { GymDataPayload, Language } from '../types';
import { useT } from '../i18n/translations';
import {
  addDaysISO,
  buildWhatsAppTemplates,
  diffDaysBetween,
  exportAttendanceCSV,
  exportMembersCSV,
  formatDateShort,
  formatINR,
  getTodayISO,
  openWhatsAppMessage,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface ReportsInactiveViewProps {
  data: GymDataPayload;
  language: Language;
  initialMode?: 'reports' | 'inactive';
}

export const ReportsInactiveView: React.FC<ReportsInactiveViewProps> = ({
  data,
  language,
  initialMode = 'reports',
}) => {
  const t = useT(language);
  const today = getTodayISO();
  const [mode, setMode] = useState<'reports' | 'inactive'>(initialMode);
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('daily');
  const [fromDate, setFromDate] = useState(today);
  const [toDate, setToDate] = useState(today);

  const selectPreset = (p: 'daily' | 'weekly' | 'monthly') => {
    setPeriod(p);
    const start = p === 'daily' ? today : p === 'weekly' ? addDaysISO(today, -6) : addDaysISO(today, -29);
    setFromDate(start);
    setToDate(today);
  };

  const report = useMemo(() => {
    const startDate =
      period === 'custom'
        ? fromDate <= toDate
          ? fromDate
          : toDate
        : period === 'daily'
        ? today
        : period === 'weekly'
        ? addDaysISO(today, -6)
        : addDaysISO(today, -29);
    const endDate =
      period === 'custom' ? (toDate >= fromDate ? toDate : fromDate) : today;

    const monthPrefix = today.slice(0, 7);

    const periodAtt = data.attendance.filter(
      (a) => a.personType === 'member' && a.date >= startDate && a.date <= endDate
    );
    const periodNewMembers = data.members.filter(
      (m) => m.joiningDate >= startDate && m.joiningDate <= endDate
    );
    const periodRenewals = data.membershipHistory.filter((h) => {
      const d = (h.createdAt || '').slice(0, 10);
      return h.actionType === 'renewal' && d >= startDate && d <= endDate;
    });
    const periodPayments = data.payments.filter(
      (p) => p.paymentDate >= startDate && p.paymentDate <= endDate
    );

    const totalFeeCollection = periodPayments.reduce((s, p) => s + p.amount, 0);
    const monthlyRevenue = data.payments
      .filter((p) => (p.paymentDate || '').startsWith(monthPrefix))
      .reduce((s, p) => s + p.amount, 0);
    const cashCollection = periodPayments
      .filter((p) => p.paymentMethod.toLowerCase() === 'cash')
      .reduce((s, p) => s + p.amount, 0);
    const upiCollection = periodPayments
      .filter((p) => p.paymentMethod.toLowerCase() === 'upi')
      .reduce((s, p) => s + p.amount, 0);
    const pendingFees = data.members.reduce((s, m) => s + m.remainingAmount, 0);
    const expiredCount = data.members.filter((m) => diffDaysBetween(today, m.expiryDate) < 0).length;

    return {
      startDate,
      endDate,
      totalMembers: data.members.length,
      expiredCount,
      attendanceCount: periodAtt.length,
      newMembers: periodNewMembers.length,
      renewals: periodRenewals.length,
      totalFeeCollection,
      monthlyRevenue,
      cashCollection,
      upiCollection,
      pendingFees,
      periodPayments,
    };
  }, [data, period, fromDate, toDate, today]);

  const inactiveMembers = useMemo(() => {
    return data.members
      .map((m) => {
        const logs = data.attendance
          .filter((a) => a.personType === 'member' && a.personId === m.id)
          .sort((a, b) => b.date.localeCompare(a.date));
        const lastAttendance = logs[0]?.date || m.joiningDate;
        const daysAbsent = diffDaysBetween(lastAttendance, today);
        return { member: m, lastAttendance, daysAbsent };
      })
      .filter((item) => item.daysAbsent >= 7)
      .sort((a, b) => b.daysAbsent - a.daysAbsent);
  }, [data, today]);

  const exportReportCSV = () => {
    const lines = [
      ['Metric', 'Value'],
      ['Gym Name', data.settings.gymName],
      ['Period', `${period} (${report.startDate} to ${report.endDate})`],
      ['Total Members', String(report.totalMembers)],
      ['Expired Members', String(report.expiredCount)],
      ['Attendance Check-ins', String(report.attendanceCount)],
      ['New Members', String(report.newMembers)],
      ['Renewals', String(report.renewals)],
      ['Period Fee Collection', String(report.totalFeeCollection)],
      ['This Month Revenue', String(report.monthlyRevenue)],
      ['Cash Collection', String(report.cashCollection)],
      ['UPI Collection', String(report.upiCollection)],
      ['Pending Fees', String(report.pendingFees)],
    ];
    const csv = lines.map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `golden-fitness-report-${report.startDate}-to-${report.endDate}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrintPdf = () => {
    document.body.classList.add('printing-gym-report');
    const cleanup = () => {
      document.body.classList.remove('printing-gym-report');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 1500);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-zinc-100 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800">
          <button
            type="button"
            onClick={() => setMode('reports')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
              mode === 'reports' ? 'bg-[#F5B700] text-black' : 'text-zinc-500'
            }`}
          >
            {t('dailyReports')}
          </button>
          <button
            type="button"
            onClick={() => setMode('inactive')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              mode === 'inactive' ? 'bg-[#F5B700] text-black' : 'text-zinc-500'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            {t('inactiveMembers')} ({inactiveMembers.length})
          </button>
        </div>

        {mode === 'reports' && (
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex gap-1 bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-1 rounded-xl">
              {(['daily', 'weekly', 'monthly'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => selectPreset(p)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize cursor-pointer ${
                    period === p
                      ? 'bg-zinc-900 dark:bg-[#F5B700] text-white dark:text-black'
                      : 'text-zinc-500'
                  }`}
                >
                  {t(p)}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5 bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-2.5 py-1 rounded-xl">
              <input
                type="date"
                aria-label="From Date"
                value={fromDate}
                onChange={(e) => {
                  setPeriod('custom');
                  setFromDate(e.target.value);
                }}
                className="bg-transparent text-xs font-mono text-zinc-900 dark:text-white focus:outline-none"
              />
              <span className="text-xs text-zinc-400">→</span>
              <input
                type="date"
                aria-label="To Date"
                value={toDate}
                onChange={(e) => {
                  setPeriod('custom');
                  setToDate(e.target.value);
                }}
                className="bg-transparent text-xs font-mono text-zinc-900 dark:text-white focus:outline-none"
              />
            </div>
            <button
              type="button"
              onClick={handlePrintPdf}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" /> {t('exportPdf')}
            </button>
            <button
              type="button"
              onClick={exportReportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-900 dark:text-white hover:border-[#F5B700] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#F5B700]" /> Report CSV
            </button>
            <button
              type="button"
              onClick={() => exportMembersCSV(data.members, today)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-900 dark:text-white hover:border-[#F5B700] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#F5B700]" /> Members CSV
            </button>
            <button
              type="button"
              onClick={() => exportAttendanceCSV(data.attendance, data.members, data.trainers, today)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-900 dark:text-white hover:border-[#F5B700] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#F5B700]" /> Attendance CSV
            </button>
          </div>
        )}
      </div>

      {mode === 'reports' ? (
        <div className="space-y-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400 font-mono">
            Showing metrics from <strong className="text-zinc-900 dark:text-white">{formatDateShort(report.startDate)}</strong> to{' '}
            <strong className="text-zinc-900 dark:text-white">{formatDateShort(report.endDate)}</strong>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { label: t('totalMembers'), val: String(report.totalMembers) },
              { label: t('expiredMembers'), val: String(report.expiredCount), warn: report.expiredCount > 0 },
              { label: 'Attendance Check-ins', val: String(report.attendanceCount) },
              { label: t('newMembers'), val: String(report.newMembers) },
              { label: 'Renewals', val: String(report.renewals) },
              { label: 'Period Fee Collection', val: formatINR(report.totalFeeCollection), accent: true },
              { label: t('monthlyRevenue'), val: formatINR(report.monthlyRevenue), accent: true },
              { label: t('cashCollection'), val: formatINR(report.cashCollection) },
              { label: t('upiCollection'), val: formatINR(report.upiCollection) },
              { label: t('pendingFees'), val: formatINR(report.pendingFees), warn: report.pendingFees > 0 },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4"
              >
                <div className="text-xs text-zinc-500 dark:text-zinc-400">{item.label}</div>
                <div
                  className={`mt-2 font-display text-2xl font-bold tabular-nums ${
                    item.accent
                      ? 'text-[#B45309] dark:text-[#F5B700]'
                      : item.warn
                      ? 'text-amber-500'
                      : 'text-zinc-900 dark:text-white'
                  }`}
                >
                  {item.val}
                </div>
              </div>
            ))}
          </div>

          {/* Printable PDF Report Layout */}
          <div id="printable-gym-report" className="hidden bg-white text-black p-8" aria-hidden="true">
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="border-b-2 border-zinc-800 pb-4 flex items-center justify-between">
                <div>
                  <h1 className="font-display text-2xl font-bold">{data.settings.gymName}</h1>
                  <p className="text-xs text-zinc-600">{data.settings.gymAddress || data.settings.contactNumber}</p>
                </div>
                <div className="text-right text-xs">
                  <div className="font-bold uppercase">Business Summary Report</div>
                  <div className="font-mono">{formatDateShort(report.startDate)} → {formatDateShort(report.endDate)}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="border border-zinc-300 rounded-lg p-3">Total Members: <strong>{report.totalMembers}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">Expired Members: <strong>{report.expiredCount}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">Attendance Check-ins: <strong>{report.attendanceCount}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">New Members: <strong>{report.newMembers}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">Period Revenue: <strong>{formatINR(report.totalFeeCollection)}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">This Month Revenue: <strong>{formatINR(report.monthlyRevenue)}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">Cash / UPI: <strong>{formatINR(report.cashCollection)} / {formatINR(report.upiCollection)}</strong></div>
                <div className="border border-zinc-300 rounded-lg p-3">Total Pending Fees: <strong>{formatINR(report.pendingFees)}</strong></div>
              </div>
              <p className="text-[11px] text-zinc-500">Generated on {new Date().toLocaleString()} · Powered by Fitness Club House</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-100 dark:divide-zinc-800/80 overflow-hidden">
          {inactiveMembers.length === 0 ? (
            <div className="p-10 text-center text-sm text-zinc-500">
              All members have attended within the last 7 days.
            </div>
          ) : (
            inactiveMembers.map(({ member, lastAttendance, daysAbsent }) => (
              <div key={member.id} className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar src={member.photo} name={member.name} size="md" />
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                      {member.name} <span className="text-xs font-mono text-zinc-400">· {member.id}</span>
                    </div>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                      {member.whatsapp} · Last seen {formatDateShort(lastAttendance)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-xs font-mono font-bold text-amber-500 tabular-nums">
                    {daysAbsent} days absent
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      openWhatsAppMessage(
                        member.whatsapp,
                        buildWhatsAppTemplates(
                          data.settings.gymName,
                          member,
                          { daysAbsent },
                          data.settings.reminderTemplates
                        ).inactiveReminder
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F5B700] text-black text-xs font-bold cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
