import React, { useState } from 'react';
import {
  Mail,
  Lock,
  User as UserIcon,
  Building2,
  ArrowRight,
  Cloud,
  KeyRound,
  CheckCircle2,
  HelpCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { auth, firebaseProjectId } from '../firebase';
import { ensureOwnerDocument } from '../services/firestoreSync';
import type { Language } from '../types';
import { Avatar } from './Avatar';

interface FirebaseAuthGateProps {
  language: Language;
  onToggleLanguage: () => void;
}

type AuthMode = 'login' | 'signup' | 'forgot';

function mapFirebaseAuthError(err: unknown): { message: string; needsConsoleSetup?: boolean } {
  const code = (err as { code?: string })?.code || '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return { message: 'Invalid email or password. Please try again or reset your password.' };
    case 'auth/invalid-email':
      return { message: 'Please enter a valid email address.' };
    case 'auth/email-already-in-use':
      return { message: 'This email is already registered. Please sign in instead.' };
    case 'auth/weak-password':
      return { message: 'Password must be at least 6 characters long.' };
    case 'auth/too-many-requests':
      return { message: 'Too many attempts. Please wait a moment before trying again.' };
    case 'auth/network-request-failed':
      return { message: 'Network error. Please check your internet connection.' };
    case 'auth/operation-not-allowed':
      return {
        message:
          'Email/Password sign-in is not yet enabled in your Firebase Console. Follow the setup guide below to enable it in 30 seconds.',
        needsConsoleSetup: true,
      };
    default:
      return {
        message: err instanceof Error ? err.message : 'Authentication failed. Please try again.',
      };
  }
}

export const FirebaseAuthGate: React.FC<FirebaseAuthGateProps> = ({
  language,
  onToggleLanguage,
}) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [gymName, setGymName] = useState('Golden Fitness Gym');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resetSent, setResetSent] = useState('');
  const [showSetupHelp, setShowSetupHelp] = useState(false);

  const isHi = language === 'hi';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResetSent('');

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setError(isHi ? 'कृपया अपना ईमेल दर्ज करें।' : 'Please enter your email address.');
      return;
    }

    if (mode === 'forgot') {
      setLoading(true);
      try {
        await sendPasswordResetEmail(auth, cleanEmail);
        setResetSent(
          isHi
            ? `${cleanEmail} पर पासवर्ड रीसेट लिंक भेज दिया गया है।`
            : `Password reset link sent to ${cleanEmail}. Check your inbox and spam folder.`
        );
      } catch (err) {
        const mapped = mapFirebaseAuthError(err);
        setError(mapped.message);
        if (mapped.needsConsoleSetup) setShowSetupHelp(true);
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!password || password.length < 6) {
      setError(
        isHi
          ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।'
          : 'Password must be at least 6 characters long.'
      );
      return;
    }

    if (mode === 'signup') {
      if (!ownerName.trim()) {
        setError(isHi ? 'कृपया मालिक का नाम दर्ज करें।' : 'Please enter your full name.');
        return;
      }
      if (password !== confirmPassword) {
        setError(isHi ? 'दोनों पासवर्ड मेल नहीं खाते।' : 'Passwords do not match.');
        return;
      }
    }

    setLoading(true);
    try {
      if (mode === 'login') {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
        await ensureOwnerDocument(cred.user);
      } else {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        await updateProfile(cred.user, { displayName: ownerName.trim() });
        await ensureOwnerDocument(cred.user, {
          displayName: ownerName.trim(),
          gymName: gymName.trim() || 'Golden Fitness Gym',
        });
      }
    } catch (err) {
      const mapped = mapFirebaseAuthError(err);
      setError(mapped.message);
      if (mapped.needsConsoleSetup) setShowSetupHelp(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-[#09090B] text-zinc-900 dark:text-zinc-100 flex flex-col lg:flex-row">
      {/* Left Hero Visual */}
      <div className="relative lg:w-1/2 min-h-[240px] lg:min-h-screen overflow-hidden bg-[#09090B]">
        <img
          src="/src/assets/images/gym_hero_banner_1795080326990.jpg"
          alt="Golden Fitness Gym"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090B] via-[#09090B]/65 to-black/35" />
        <div className="relative z-10 p-6 lg:p-12 h-full flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar
                src="/src/assets/images/gym_club_logo_1795080326591.jpg"
                name="Golden Fitness Gym"
                size="md"
                className="border-[#D4AF37]/60"
              />
              <span className="font-display text-lg font-bold text-white tracking-tight">
                Golden Fitness Gym
              </span>
            </div>
            <button
              type="button"
              onClick={onToggleLanguage}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white backdrop-blur-md transition-colors cursor-pointer"
            >
              {language === 'en' ? 'हिन्दी' : 'English'}
            </button>
          </div>

          <div className="mt-10 lg:mt-0 max-w-lg space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-[#F5B700]/15 border border-[#F5B700]/30 text-[#F5B700] text-xs font-semibold">
              <Cloud className="w-3.5 h-3.5" />
              <span>{isHi ? 'क्लाउड बैकअप और सिंक सुरक्षित' : 'Cloud Backup & Private Sync'}</span>
            </div>
            <h1 className="font-display text-3xl lg:text-5xl font-bold text-white leading-tight">
              Golden Fitness Gym
            </h1>
            <p className="text-sm lg:text-base text-zinc-300 leading-relaxed">
              {isHi
                ? 'आपके सभी सदस्य, कस्टम फीस, उपस्थिति QR कोड और भुगतान रिकॉर्ड क्लाउड में सुरक्षित हैं। फोन बदलने या ऐप रीइंस्टॉल करने पर भी पूरा डेटा तुरंत वापस आ जाता है।'
                : 'Sign in with your gym owner account. Members, custom fees, QR attendance, and receipts stay permanently synced across phones and app reinstalls.'}
            </p>
          </div>
        </div>
      </div>

      {/* Right Auth Form Panel */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-8 lg:p-12">
        <div className="w-full max-w-md space-y-5">
          <div>
            <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">
              {mode === 'login'
                ? isHi
                  ? 'जिम ओनर लॉगिन'
                  : 'Gym Owner Sign In'
                : mode === 'signup'
                ? isHi
                  ? 'नया क्लाउड अकाउंट बनाएं'
                  : 'Create Owner Account'
                : isHi
                ? 'पासवर्ड रीसेट करें'
                : 'Reset Password'}
            </h2>
            <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
              {mode === 'login'
                ? isHi
                  ? 'अपना क्लाउड जिम डेटा एक्सेस करने के लिए लॉगिन करें'
                  : 'Access your private Golden Fitness Gym cloud database'
                : mode === 'signup'
                ? isHi
                  ? 'ऑनलाइन सिंक और स्थायी बैकअप शुरू करें'
                  : 'Start permanent cloud backup with private owner isolation'
                : isHi
                ? 'रीसेट लिंक पाने के लिए अपना ईमेल दर्ज करें'
                : 'Enter your registered email to receive a password reset link'}
            </p>
          </div>

          {mode !== 'forgot' && (
            <div className="grid grid-cols-2 p-1 rounded-2xl bg-zinc-200/70 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                  setResetSent('');
                }}
                className={`py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                  mode === 'login'
                    ? 'bg-[#F5B700] text-black'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                {isHi ? 'लॉगिन' : 'Sign In'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setError('');
                  setResetSent('');
                }}
                className={`py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                  mode === 'signup'
                    ? 'bg-[#F5B700] text-black'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                {isHi ? 'नया अकाउंट' : 'Create Account'}
              </button>
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="space-y-4 bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5"
          >
            {mode === 'signup' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                    {isHi ? 'मालिक का नाम' : 'Owner Full Name'}
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="e.g. Rajesh Sharma"
                      className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-4 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                    {isHi ? 'जिम का नाम' : 'Gym Name'}
                  </label>
                  <div className="relative">
                    <Building2 className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={gymName}
                      onChange={(e) => setGymName(e.target.value)}
                      placeholder="Golden Fitness Gym"
                      className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-4 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                {isHi ? 'ईमेल पता' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="owner@goldenfitnessgym.com"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-4 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                    {isHi ? 'पासवर्ड' : 'Password'}
                  </label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('forgot');
                        setError('');
                        setResetSent('');
                      }}
                      className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] hover:underline cursor-pointer"
                    >
                      {isHi ? 'पासवर्ड भूल गए?' : 'Forgot Password?'}
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-10 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  {isHi ? 'पासवर्ड की पुष्टि करें' : 'Confirm Password'}
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-4 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                  />
                </div>
              </div>
            )}

            {error && (
              <p className="text-xs text-red-500 font-medium bg-red-500/10 border border-red-500/25 rounded-xl px-3 py-2.5">
                {error}
              </p>
            )}

            {resetSent && (
              <div className="flex items-start gap-2 text-xs text-emerald-500 font-medium bg-emerald-500/10 border border-emerald-500/25 rounded-xl px-3 py-2.5">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{resetSent}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 px-5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-50 text-black font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>
                {loading
                  ? isHi
                    ? 'प्रतीक्षा करें...'
                    : 'Please wait...'
                  : mode === 'login'
                  ? isHi
                    ? 'साइन इन करें'
                    : 'Sign In to Cloud Gym'
                  : mode === 'signup'
                  ? isHi
                    ? 'अकाउंट बनाएं'
                    : 'Create Cloud Account'
                  : isHi
                  ? 'रीसेट लिंक भेजें'
                  : 'Send Reset Link'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {mode === 'forgot' && (
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                  setResetSent('');
                }}
                className="w-full py-2 text-xs font-semibold text-zinc-500 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
              >
                {isHi ? 'लॉगिन पर वापस जाएं' : 'Back to Sign In'}
              </button>
            )}
          </form>

          {/* Firebase Console Email/Password Setup Helper */}
          <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4">
            <button
              type="button"
              onClick={() => setShowSetupHelp((s) => !s)}
              className="w-full flex items-center justify-between text-xs font-semibold text-zinc-600 dark:text-zinc-300 cursor-pointer"
            >
              <span className="inline-flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-[#F5B700]" />
                {isHi ? 'Firebase सेटअप निर्देश' : 'Firebase Email/Password Setup Guide'}
              </span>
              <span className="text-[11px] text-zinc-400">{showSetupHelp ? 'Hide' : 'Show'}</span>
            </button>
            {showSetupHelp && (
              <ol className="mt-3 space-y-1.5 text-[11px] text-zinc-500 dark:text-zinc-400 list-decimal list-inside leading-relaxed">
                <li>
                  Open Firebase Console for project{' '}
                  <span className="font-mono text-zinc-800 dark:text-zinc-200">{firebaseProjectId}</span>.
                </li>
                <li>
                  Go to <strong>Authentication &rarr; Sign-in method</strong>.
                </li>
                <li>
                  Click <strong>Add new provider &rarr; Email/Password</strong>, enable it, and save.
                </li>
                <li>
                  Your private Cloud Firestore database is already provisioned and secured per owner UID.
                </li>
              </ol>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
