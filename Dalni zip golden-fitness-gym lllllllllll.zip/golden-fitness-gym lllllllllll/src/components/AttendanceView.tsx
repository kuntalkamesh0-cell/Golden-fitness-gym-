import React, { useEffect, useMemo, useState } from 'react';
import {
  Calendar,
  Camera,
  CheckCircle2,
  Download,
  LogIn,
  LogOut,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import type {
  AttendanceMethod,
  AttendanceRecord,
  AttendanceShift,
  GymSettings,
  Language,
  Member,
  Trainer,
} from '../types';
import { useT } from '../i18n/translations';
import {
  addDaysISO,
  computeLiveDuration,
  exportAttendanceCSV,
  formatDateShort,
  formatDurationMinutes,
  formatTime12h,
  getCurrentTimeHHMMSS,
  getShiftForTime,
  getTodayISO,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';
import { CameraQRScannerModal } from './CameraQRScannerModal';
import { GymAttendanceQRCard } from './GymAttendanceQRCard';

interface AttendanceViewProps {
  members: Member[];
  trainers: Trainer[];
  attendance: AttendanceRecord[];
  settings: GymSettings;
  language: Language;
  onMarkAttendance: (payload: {
    personType: 'member' | 'trainer';
    personIdOrToken: string;
    date: string;
    entryTime: string;
    shift: AttendanceShift;
    method: AttendanceMethod;
    action?: 'auto' | 'entry' | 'exit';
  }) => Promise<void>;
  onMarkExit: (attendanceId: string) => Promise<void>;
  onRegenerateGymQr?: () => Promise<void>;
  onToggleDuplicateRule?: () => Promise<void>;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  members,
  trainers,
  attendance,
  settings,
  language,
  onMarkAttendance,
  onMarkExit,
  onRegenerateGymQr,
  onToggleDuplicateRule,
}) => {
  const t = useT(language);
  const today = getTodayISO();
  const [subTab, setSubTab] = useState<'manual' | 'qr' | 'history'>('manual');
  const [historyRange, setHistoryRange] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [attDate, setAttDate] = useState(today);
  const [entryTime, setEntryTime] = useState(getCurrentTimeHHMMSS());
  const [shift, setShift] = useState<AttendanceShift>(() => getShiftForTime(getCurrentTimeHHMMSS()));
  const [qrInput, setQrInput] = useState('');
  const [search, setSearch] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const memberMap = useMemo(() => new Map(members.map((m) => [m.id, m])), [members]);
  const trainerMap = useMemo(() => new Map(trainers.map((tr) => [tr.id, tr])), [trainers]);

  // Map each person's open visit (INSIDE GYM) and completed daily minutes on attDate
  const personDaySummary = useMemo(() => {
    const openMap = new Map<string, AttendanceRecord>();
    const totalMinutesMap = new Map<string, number>();
    const visitsCountMap = new Map<string, number>();

    for (const a of attendance) {
      if (a.date !== attDate) continue;
      const key = `${a.personType}:${a.personId}`;
      visitsCountMap.set(key, (visitsCountMap.get(key) || 0) + 1);
      if (a.status === 'INSIDE GYM') {
        if (!openMap.has(key)) openMap.set(key, a);
      } else {
        totalMinutesMap.set(key, (totalMinutesMap.get(key) || 0) + (Number(a.durationMinutes) || 0));
      }
    }
    return { openMap, totalMinutesMap, visitsCountMap };
  }, [attendance, attDate]);

  const handleMark = async (
    personType: 'member' | 'trainer',
    personIdOrToken: string,
    method: AttendanceMethod,
    action: 'auto' | 'entry' | 'exit' = 'auto'
  ) => {
    setFeedback(null);
    const liveTime = getCurrentTimeHHMMSS();
    const effectiveTime = attDate === today ? liveTime : entryTime;
    const effectiveShift = attDate === today ? getShiftForTime(liveTime) : shift;
    try {
      await onMarkAttendance({
        personType,
        personIdOrToken,
        date: attDate,
        entryTime: effectiveTime,
        shift: effectiveShift,
        method,
        action,
      });
      setFeedback({
        type: 'ok',
        text: `${action === 'exit' ? 'EXIT' : action === 'entry' ? 'ENTRY' : 'Scan'} recorded (${effectiveShift} · ${method})`,
      });
      setQrInput('');
    } catch (err) {
      setFeedback({ type: 'err', text: (err as Error).message });
    }
  };

  const filteredMembers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return members.filter(
      (m) =>
        !q ||
        m.name.toLowerCase().includes(q) ||
        m.id.toLowerCase().includes(q) ||
        m.whatsapp.includes(q)
    );
  }, [members, search]);

  const historyRecords = useMemo(() => {
    const weekAgo = addDaysISO(today, -6);
    const monthAgo = addDaysISO(today, -29);
    return attendance
      .filter((a) => {
        if (historyRange === 'daily') return a.date === attDate;
        if (historyRange === 'weekly') return a.date >= weekAgo && a.date <= today;
        return a.date >= monthAgo && a.date <= today;
      })
      .sort((a, b) => (b.entryTimestamp || b.createdAt).localeCompare(a.entryTimestamp || a.createdAt));
  }, [attendance, historyRange, attDate, today]);

  const summaryStats = useMemo(() => {
    const weekAgo = addDaysISO(today, -6);
    const monthAgo = addDaysISO(today, -29);
    const memberAtt = attendance.filter((a) => a.personType === 'member');
    const todayCount = new Set(memberAtt.filter((a) => a.date === today).map((a) => a.personId)).size;
    const weeklyCount = memberAtt.filter((a) => a.date >= weekAgo && a.date <= today).length;
    const monthlyCount = memberAtt.filter((a) => a.date >= monthAgo && a.date <= today).length;
    const insideCount = new Set(
      memberAtt.filter((a) => a.date === today && a.status === 'INSIDE GYM').map((a) => a.personId)
    ).size;
    return { todayCount, weeklyCount, monthlyCount, insideCount };
  }, [attendance, today]);

  return (
    <div className="space-y-4">
      {/* Live Attendance Summary Bar & Same-Day Rule Control */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-4 py-3">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Today&apos;s Attendance</div>
          <div className="font-display text-xl font-bold text-[#B45309] dark:text-[#F5B700] tabular-nums">
            {summaryStats.todayCount}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-4 py-3">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Inside Gym Now</div>
          <div className="font-display text-xl font-bold text-emerald-500 tabular-nums">
            {summaryStats.insideCount}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-4 py-3">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Weekly Check-ins (7d)</div>
          <div className="font-display text-xl font-bold text-zinc-900 dark:text-white tabular-nums">
            {summaryStats.weeklyCount}
          </div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-4 py-3">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Monthly Check-ins (30d)</div>
          <div className="font-display text-xl font-bold text-zinc-900 dark:text-white tabular-nums">
            {summaryStats.monthlyCount}
          </div>
        </div>
        <div className="col-span-2 sm:col-span-4 lg:col-span-1 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-3.5 py-2.5 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-[#F5B700]" /> Same-Day Duplicate
            </div>
            <div className="text-xs font-bold text-zinc-900 dark:text-white truncate">
              {settings.preventDuplicateSameDay ? 'Blocked (1/day)' : 'Allow Re-Entry'}
            </div>
          </div>
          {onToggleDuplicateRule && (
            <button
              type="button"
              onClick={onToggleDuplicateRule}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer shrink-0 ${
                settings.preventDuplicateSameDay
                  ? 'bg-[#F5B700] text-black'
                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
              }`}
            >
              {settings.preventDuplicateSameDay ? 'ON' : 'OFF'}
            </button>
          )}
        </div>
      </div>

      {/* Sub-navigation & Date/Session Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1.5 rounded-2xl bg-zinc-100 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800">
          {[
            { id: 'manual', label: 'Entry / Exit Desk' },
            { id: 'qr', label: 'Gym QR & Scanner' },
            { id: 'history', label: 'Attendance History' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSubTab(item.id as typeof subTab)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                subTab === item.id
                  ? 'bg-[#F5B700] text-black'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-1">
            {(['Morning', 'Evening'] as AttendanceShift[]).map((sh) => (
              <button
                key={sh}
                type="button"
                onClick={() => setShift(sh)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  shift === sh
                    ? 'bg-zinc-900 dark:bg-[#F5B700] text-white dark:text-black'
                    : 'text-zinc-500 dark:text-zinc-400'
                }`}
              >
                {sh === 'Morning' ? `${t('morningShift')} (4AM–12PM)` : `${t('eveningShift')} (12PM–12AM)`}
              </button>
            ))}
          </div>
          <input
            type="date"
            value={attDate}
            onChange={(e) => setAttDate(e.target.value)}
            className="rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
          />
          <input
            type="time"
            value={entryTime.slice(0, 5)}
            onChange={(e) => setEntryTime(`${e.target.value}:00`)}
            className="rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
          />
        </div>
      </div>

      {feedback && (
        <div
          className={`px-4 py-3 rounded-2xl text-xs font-semibold border ${
            feedback.type === 'ok'
              ? 'bg-[#F5B700]/15 border-[#F5B700]/40 text-[#B45309] dark:text-[#F5B700]'
              : 'bg-red-500/10 border-red-500/30 text-red-500'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* QR Desk & Reception Scanner */}
      {subTab === 'qr' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Official Secure Gym QR Code for Members */}
          <div className="lg:col-span-6">
            <GymAttendanceQRCard
              gymName={settings.gymName}
              gymAddress={settings.gymAddress}
              gymQrSecret={settings.gymQrSecret}
              canGenerate={Boolean(onRegenerateGymQr)}
              onGenerateQr={onRegenerateGymQr || (async () => {})}
            />
          </div>

          {/* Reception Camera Scanner & Manual ID Entry */}
          <div className="lg:col-span-6 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                  Reception Check-In / Check-Out
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Scan a member card or type Member ID / Mobile for instant Entry or Exit
                </p>
              </div>
              <button
                type="button"
                onClick={() => setScannerOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold cursor-pointer shrink-0"
              >
                <Camera className="w-4 h-4" /> Open Scanner
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (qrInput.trim()) handleMark('member', qrInput.trim(), 'QR', 'auto');
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={qrInput}
                onChange={(e) => setQrInput(e.target.value)}
                placeholder="Type Member ID, Mobile, or Token (e.g. GFG-101)"
                className="flex-1 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-3 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
              <button
                type="submit"
                className="px-5 py-3 rounded-xl bg-[#F5B700] text-black text-sm font-bold cursor-pointer shrink-0"
              >
                Entry / Exit
              </button>
            </form>

            <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800">
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-3">
                Quick-tap member for Entry / Exit toggle:
              </p>
              {members.length === 0 ? (
                <p className="text-xs text-zinc-500 dark:text-zinc-400 py-3">
                  No members registered yet. Add members first.
                </p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {members.slice(0, 6).map((m) => {
                    const isInside = personDaySummary.openMap.has(`member:${m.id}`);
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => handleMark('member', m.id, 'QR', isInside ? 'exit' : 'entry')}
                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                          isInside
                            ? 'bg-emerald-500/10 border-emerald-500/40'
                            : 'bg-zinc-50 dark:bg-[#18181D] border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700]'
                        }`}
                      >
                        <div className="text-xs font-bold text-zinc-900 dark:text-white truncate">{m.name}</div>
                        <div className="text-[11px] font-mono text-zinc-500">
                          {m.id} · {isInside ? 'TAP EXIT' : 'TAP ENTRY'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Manual Entry & Exit Desk */}
      {subTab === 'manual' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Members Entry/Exit List */}
          <div className="lg:col-span-8 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3">
              <div>
                <span className="font-display text-sm font-bold text-zinc-900 dark:text-white">
                  Members Entry &amp; Exit ({members.filter((m) => personDaySummary.openMap.has(`member:${m.id}`)).length} inside now)
                </span>
              </div>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter member..."
                className="w-48 sm:w-64 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-200 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
            </div>
            <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80 max-h-[540px] overflow-y-auto">
              {filteredMembers.length === 0 ? (
                <div className="p-8 text-center text-xs text-zinc-500 dark:text-zinc-400">
                  {members.length === 0
                    ? 'No members registered yet. Add your first member to mark attendance.'
                    : 'No members match your filter.'}
                </div>
              ) : (
                filteredMembers.map((m) => {
                  const key = `member:${m.id}`;
                  const openVisit = personDaySummary.openMap.get(key);
                  const completedMins = personDaySummary.totalMinutesMap.get(key) || 0;
                  const visitCount = personDaySummary.visitsCountMap.get(key) || 0;
                  const live = openVisit
                    ? computeLiveDuration(openVisit.entryTimestamp || openVisit.createdAt, nowMs)
                    : null;

                  return (
                    <div key={m.id} className="px-4 py-3.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar src={m.photo} name={m.name} size="sm" />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                            {m.name}
                          </div>
                          <div className="text-xs font-mono text-zinc-500 truncate tabular-nums">
                            {m.id} ·{' '}
                            {openVisit ? (
                              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                                INSIDE GYM ({formatTime12h(openVisit.entryTime)} · {live?.formatted})
                              </span>
                            ) : visitCount > 0 ? (
                              <span>
                                LEFT GYM · Today {formatDurationMinutes(completedMins)} ({visitCount} visit{visitCount > 1 ? 's' : ''})
                              </span>
                            ) : (
                              m.whatsapp
                            )}
                          </div>
                        </div>
                      </div>

                      {openVisit ? (
                        <button
                          type="button"
                          onClick={() => onMarkExit(openVisit.id)}
                          className="min-h-[42px] px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>EXIT</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleMark('member', m.id, 'Manual', 'entry')}
                          className="min-h-[42px] px-4 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
                        >
                          <LogIn className="w-4 h-4" />
                          <span>ENTRY</span>
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Trainer Attendance */}
          <div className="lg:col-span-4 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden h-fit">
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800">
              <span className="font-display text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#F5B700]" />
                Trainer Attendance
              </span>
            </div>
            <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
              {trainers.length === 0 ? (
                <div className="p-6 text-center text-xs text-zinc-500 dark:text-zinc-400">
                  No trainers added yet.
                </div>
              ) : (
                trainers.map((tr) => {
                  const openVisit = personDaySummary.openMap.get(`trainer:${tr.id}`);
                  return (
                    <div key={tr.id} className="px-4 py-3 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar src={tr.photo} name={tr.name} size="sm" />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                            {tr.name}
                          </div>
                          <div className="text-[11px] text-zinc-500 truncate">
                            {openVisit ? `In ${formatTime12h(openVisit.entryTime)}` : tr.specialization}
                          </div>
                        </div>
                      </div>
                      {openVisit ? (
                        <button
                          type="button"
                          onClick={() => onMarkExit(openVisit.id)}
                          className="px-3 py-2 rounded-xl bg-red-600 text-white text-xs font-bold shrink-0 cursor-pointer"
                        >
                          EXIT
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleMark('trainer', tr.id, 'Manual', 'entry')}
                          className="px-3 py-2 rounded-xl bg-zinc-900 dark:bg-[#F5B700] text-white dark:text-black text-xs font-bold shrink-0 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 inline mr-1" />
                          ENTRY
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Attendance History (Daily / Weekly / Monthly + CSV Export) */}
      {subTab === 'history' && (
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#F5B700]" />
              <span className="font-display text-sm font-bold text-zinc-900 dark:text-white">
                Attendance History ({historyRecords.length})
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex gap-1 bg-zinc-100 dark:bg-zinc-900 p-1 rounded-xl">
                {(['daily', 'weekly', 'monthly'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setHistoryRange(r)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize cursor-pointer ${
                      historyRange === r
                        ? 'bg-white dark:bg-[#18181D] text-zinc-900 dark:text-[#F5B700]'
                        : 'text-zinc-500'
                    }`}
                  >
                    {t(r)}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => exportAttendanceCSV(historyRecords, members, trainers, today)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-xs font-semibold text-zinc-800 dark:text-zinc-200 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#F5B700]" /> Export CSV
              </button>
            </div>
          </div>

          {historyRecords.length === 0 ? (
            <div className="p-10 text-center text-sm text-zinc-500">
              No attendance logs in this period.
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[540px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400">
                    <th className="py-3 px-4 font-semibold">Name</th>
                    <th className="py-3 px-3 font-semibold">Date</th>
                    <th className="py-3 px-3 font-semibold">Entry Time</th>
                    <th className="py-3 px-3 font-semibold">Exit Time</th>
                    <th className="py-3 px-3 font-semibold">Session</th>
                    <th className="py-3 px-3 font-semibold">Total Duration</th>
                    <th className="py-3 px-4 font-semibold text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80 font-mono tabular-nums">
                  {historyRecords.map((a) => {
                    const person =
                      a.personType === 'member'
                        ? memberMap.get(a.personId)
                        : trainerMap.get(a.personId);
                    const isInside = a.status === 'INSIDE GYM';
                    const durationText = isInside
                      ? computeLiveDuration(a.entryTimestamp || a.createdAt, nowMs).formatted
                      : formatDurationMinutes(a.durationMinutes);
                    return (
                      <tr key={a.id} className="hover:bg-zinc-50 dark:hover:bg-[#18181D]">
                        <td className="py-3 px-4 font-sans font-semibold text-zinc-900 dark:text-white whitespace-nowrap">
                          {person?.name || a.personId}
                          <span className="ml-1.5 text-[11px] font-mono font-normal text-zinc-500">
                            {a.personType === 'trainer' ? 'Trainer' : a.personId}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-sans text-zinc-600 dark:text-zinc-300 whitespace-nowrap">
                          {formatDateShort(a.date)}
                        </td>
                        <td className="py-3 px-3 text-zinc-900 dark:text-white whitespace-nowrap">
                          {formatTime12h(a.entryTime)}
                        </td>
                        <td className="py-3 px-3 text-zinc-600 dark:text-zinc-400 whitespace-nowrap">
                          {a.exitTime ? formatTime12h(a.exitTime) : '—'}
                        </td>
                        <td className="py-3 px-3 font-sans text-zinc-600 dark:text-zinc-300 whitespace-nowrap">
                          {a.shift}
                        </td>
                        <td className="py-3 px-3 font-bold text-[#B45309] dark:text-[#F5B700] whitespace-nowrap">
                          {durationText}
                        </td>
                        <td className="py-3 px-4 text-right font-sans whitespace-nowrap">
                          {isInside ? (
                            <button
                              type="button"
                              onClick={() => onMarkExit(a.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-500 hover:bg-red-500/20 hover:text-red-400 font-bold cursor-pointer"
                            >
                              INSIDE GYM · Exit
                            </button>
                          ) : (
                            <span className="font-semibold text-zinc-500 dark:text-zinc-400">
                              LEFT GYM
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <CameraQRScannerModal
        isOpen={scannerOpen}
        modeLabel="Scan Member Badge or ID"
        onClose={() => setScannerOpen(false)}
        onDetected={async (raw) => {
          setScannerOpen(false);
          await handleMark('member', raw, 'QR', 'auto');
        }}
      />
    </div>
  );
};
