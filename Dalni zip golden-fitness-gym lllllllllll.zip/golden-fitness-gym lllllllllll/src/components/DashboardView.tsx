import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  UserPlus,
  QrCode,
  IndianRupee,
  RefreshCw,
  MessageCircle,
  ArrowUpRight,
  Users,
  BarChart3,
  AlertTriangle,
  Download,
  LogOut,
  Bell,
  Receipt,
  X,
} from 'lucide-react';
import type { GymDataPayload, Language, Member } from '../types';
import { useT } from '../i18n/translations';
import {
  addDaysISO,
  buildWhatsAppTemplates,
  computeLiveDuration,
  diffDaysBetween,
  exportAttendanceCSV,
  exportMembersCSV,
  formatDateShort,
  formatDurationMinutes,
  formatINR,
  formatTime12h,
  getFeeStatus,
  getTodayISO,
  isMemberActive,
  openWhatsAppMessage,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';
import { GymAttendanceQRCard } from './GymAttendanceQRCard';

interface DashboardViewProps {
  data: GymDataPayload;
  language: Language;
  onNavigate: (tab: string) => void;
  onOpenNewMember: () => void;
  onSelectMember: (m: Member) => void;
  onQuickCollectFee: (m: Member) => void;
  onMarkExit: (attendanceId: string) => Promise<void>;
  onRegenerateGymQr: () => Promise<void>;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  language,
  onNavigate,
  onOpenNewMember,
  onSelectMember,
  onQuickCollectFee,
  onMarkExit,
  onRegenerateGymQr,
}) => {
  const t = useT(language);
  const today = getTodayISO();
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [generatingTopQr, setGeneratingTopQr] = useState(false);
  const [dismissedBanner, setDismissedBanner] = useState(false);
  const qrCardRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const memberMap = useMemo(() => new Map(data.members.map((m) => [m.id, m])), [data.members]);

  const metrics = useMemo(() => {
    const monthPrefix = today.slice(0, 7);
    const totalMembers = data.members.length;
    const activeMembers = data.members.filter((m) => isMemberActive(m, today)).length;
    const inactiveMembersCount = totalMembers - activeMembers;
    const expiredMembersCount = data.members.filter((m) => diffDaysBetween(today, m.expiryDate) < 0).length;
    const newMembersToday = data.members.filter((m) => m.joiningDate === today).length;
    const newMembersThisMonth = data.members.filter((m) => (m.joiningDate || '').startsWith(monthPrefix)).length;
    const expiringSoonList = data.members.filter((m) => {
      const diff = diffDaysBetween(today, m.expiryDate);
      return diff >= 0 && diff <= 7;
    });

    const feePaidMembers = data.members.filter((m) => getFeeStatus(m) === 'Paid').length;
    const feePendingMembers = data.members.filter((m) => getFeeStatus(m) !== 'Paid');
    const totalPendingFees = feePendingMembers.reduce((sum, m) => sum + (Number(m.remainingAmount) || 0), 0);

    const todaysMemberVisits = data.attendance
      .filter((a) => a.personType === 'member' && a.date === today)
      .sort((a, b) => (b.entryTimestamp || b.createdAt).localeCompare(a.entryTimestamp || a.createdAt));

    const uniqueTodayMembers = new Set(todaysMemberVisits.map((a) => a.personId)).size;
    const currentlyInsideVisits = todaysMemberVisits.filter((a) => a.status === 'INSIDE GYM');
    const currentlyInsideMembers = new Set(currentlyInsideVisits.map((a) => a.personId)).size;

    const morningAttendanceCount = new Set(
      todaysMemberVisits.filter((a) => a.shift === 'Morning').map((a) => a.personId)
    ).size;
    const eveningAttendanceCount = new Set(
      todaysMemberVisits.filter((a) => a.shift === 'Evening').map((a) => a.personId)
    ).size;

    const todaysPayments = data.payments.filter((p) => p.paymentDate === today);
    const todaysCollection = todaysPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const monthlyRevenue = data.payments
      .filter((p) => (p.paymentDate || '').startsWith(monthPrefix))
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const cashCollection = todaysPayments
      .filter((p) => p.paymentMethod.toLowerCase() === 'cash')
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const upiCollection = todaysPayments
      .filter((p) => p.paymentMethod.toLowerCase() === 'upi')
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const recentPayments = data.payments.slice(0, 6);

    // 7-day attendance graph (unique visits per day)
    const weeklyBars = Array.from({ length: 7 }, (_, i) => {
      const offset = i - 6;
      const dISO = addDaysISO(today, offset);
      const dayRecords = data.attendance.filter((a) => a.personType === 'member' && a.date === dISO);
      const morning = dayRecords.filter((a) => a.shift === 'Morning').length;
      const evening = dayRecords.filter((a) => a.shift === 'Evening').length;
      const dt = new Date(dISO + 'T00:00:00');
      const shortDay = dt.toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-IN', { weekday: 'short' });
      return { date: dISO, label: shortDay, total: dayRecords.length, morning, evening };
    });

    const inactive7DaysCount = data.members.filter((m) => {
      if (!isMemberActive(m, today)) return false;
      const memberAtt = data.attendance
        .filter((a) => a.personType === 'member' && a.personId === m.id)
        .sort((a, b) => b.date.localeCompare(a.date));
      const lastDate = memberAtt[0]?.date || m.joiningDate;
      return diffDaysBetween(lastDate, today) >= 7;
    }).length;

    return {
      totalMembers,
      activeMembers,
      inactiveMembersCount,
      expiredMembersCount,
      newMembersToday,
      newMembersThisMonth,
      expiringSoonList,
      feePaidMembers,
      feePendingMembers,
      totalPendingFees,
      todaysMemberVisits,
      uniqueTodayMembers,
      currentlyInsideMembers,
      morningAttendanceCount,
      eveningAttendanceCount,
      todaysCollection,
      monthlyRevenue,
      cashCollection,
      upiCollection,
      recentPayments,
      weeklyBars,
      inactive7DaysCount,
    };
  }, [data, today, language]);

  const maxWeekly = Math.max(1, ...metrics.weeklyBars.map((b) => b.total));

  const handleQuickGenerateQr = async () => {
    setGeneratingTopQr(true);
    try {
      await onRegenerateGymQr();
      qrCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } finally {
      setGeneratingTopQr(false);
    }
  };

  const kpiCards = [
    {
      label: t('totalMembers'),
      value: String(metrics.totalMembers),
      sub: `${metrics.newMembersToday} today · ${metrics.newMembersThisMonth} this month`,
      action: () => onNavigate('members'),
    },
    {
      label: t('activeMembers'),
      value: String(metrics.activeMembers),
      sub: 'Active memberships',
      highlight: true,
      action: () => onNavigate('members'),
    },
    {
      label: t('expiredMembers'),
      value: String(metrics.expiredMembersCount),
      sub: `${metrics.inactiveMembersCount} inactive / expired`,
      warn: metrics.expiredMembersCount > 0,
      action: () => onNavigate('renewals'),
    },
    {
      label: t('newThisMonth'),
      value: String(metrics.newMembersThisMonth),
      sub: `${metrics.newMembersToday} joined today`,
      action: () => onNavigate('members'),
    },
    {
      label: t('todaysAttendance'),
      value: String(metrics.uniqueTodayMembers),
      sub: `${metrics.todaysMemberVisits.length} entry/exit logs`,
      action: () => onNavigate('attendance'),
    },
    {
      label: 'Currently Inside Gym',
      value: String(metrics.currentlyInsideMembers),
      sub: 'Active inside now',
      highlight: metrics.currentlyInsideMembers > 0,
      action: () => onNavigate('attendance'),
    },
    {
      label: 'Morning Attendance',
      value: String(metrics.morningAttendanceCount),
      sub: '4:00 AM – 12:00 PM',
      action: () => onNavigate('attendance'),
    },
    {
      label: 'Evening Attendance',
      value: String(metrics.eveningAttendanceCount),
      sub: '12:00 PM – 11:59 PM',
      action: () => onNavigate('attendance'),
    },
    {
      label: t('monthlyRevenue'),
      value: formatINR(metrics.monthlyRevenue),
      sub: `Today: ${formatINR(metrics.todaysCollection)}`,
      highlight: true,
      action: () => onNavigate('reports'),
    },
    {
      label: 'Fee Paid Members',
      value: String(metrics.feePaidMembers),
      sub: `Cash ${formatINR(metrics.cashCollection)} · UPI ${formatINR(metrics.upiCollection)}`,
      action: () => onNavigate('fees'),
    },
    {
      label: 'Fee Pending Members',
      value: String(metrics.feePendingMembers.length),
      sub: `Due: ${formatINR(metrics.totalPendingFees)}`,
      warn: metrics.feePendingMembers.length > 0,
      action: () => onNavigate('fees'),
    },
    {
      label: "Today's Entry & Exit",
      value: String(metrics.todaysMemberVisits.length),
      sub: `${metrics.expiringSoonList.length} expiring in 7d`,
      action: () => onNavigate('attendance'),
    },
  ];

  const hasAlerts =
    !dismissedBanner &&
    (metrics.expiredMembersCount > 0 ||
      metrics.expiringSoonList.length > 0 ||
      metrics.feePendingMembers.length > 0);

  return (
    <div className="space-y-6">
      {/* Upcoming Expiry & Overdue Payment Alert Banner */}
      {hasAlerts && (
        <div className="rounded-2xl bg-amber-500/10 border border-amber-500/35 px-4 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <Bell className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-xs text-zinc-800 dark:text-zinc-200 leading-relaxed">
              <strong className="text-amber-600 dark:text-amber-400">Alerts: </strong>
              {metrics.expiredMembersCount > 0 && (
                <span>{metrics.expiredMembersCount} expired membership(s) · </span>
              )}
              {metrics.expiringSoonList.length > 0 && (
                <span>{metrics.expiringSoonList.length} expiring within 7 days · </span>
              )}
              {metrics.feePendingMembers.length > 0 && (
                <span>
                  {metrics.feePendingMembers.length} pending fee due ({formatINR(metrics.totalPendingFees)})
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {metrics.feePendingMembers.length > 0 && (
              <button
                type="button"
                onClick={() => onNavigate('fees')}
                className="px-3 py-1.5 rounded-xl bg-[#F5B700] text-black text-xs font-bold cursor-pointer"
              >
                Remind Fees
              </button>
            )}
            {(metrics.expiredMembersCount > 0 || metrics.expiringSoonList.length > 0) && (
              <button
                type="button"
                onClick={() => onNavigate('renewals')}
                className="px-3 py-1.5 rounded-xl bg-zinc-900 dark:bg-zinc-800 text-white text-xs font-semibold cursor-pointer"
              >
                Renewals
              </button>
            )}
            <button
              type="button"
              onClick={() => setDismissedBanner(true)}
              aria-label="Dismiss alert"
              className="p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
      {/* Quick Actions Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={onOpenNewMember}
          className="flex items-center justify-center gap-2 rounded-2xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <UserPlus className="w-4 h-4 shrink-0" />
          <span className="truncate">{t('addMember')}</span>
        </button>
        <button
          type="button"
          disabled={generatingTopQr}
          onClick={handleQuickGenerateQr}
          className="col-span-2 sm:col-span-1 flex items-center justify-center gap-2 rounded-2xl bg-[#18181D] border border-[#D4AF37]/60 hover:bg-[#F5B700] hover:text-black text-[#F5B700] font-bold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50"
        >
          <QrCode className="w-4 h-4 shrink-0" />
          <span>{generatingTopQr ? 'Generating...' : 'Generate Gym QR Code'}</span>
        </button>
        <button
          type="button"
          onClick={() => onNavigate('attendance')}
          className="flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <QrCode className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] shrink-0" />
          <span className="truncate">{t('markAttendance')}</span>
        </button>
        <button
          type="button"
          onClick={() => onNavigate('fees')}
          className="flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <IndianRupee className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] shrink-0" />
          <span className="truncate">{t('collectFee')}</span>
        </button>
        <button
          type="button"
          onClick={() => onNavigate('renewals')}
          className="flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <RefreshCw className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] shrink-0" />
          <span className="truncate">{t('viewRenewals')}</span>
        </button>
        <button
          type="button"
          onClick={() => exportMembersCSV(data.members, today)}
          className="flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <Download className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] shrink-0" />
          <span className="truncate">Export Members</span>
        </button>
        <button
          type="button"
          onClick={() => exportAttendanceCSV(data.attendance, data.members, data.trainers, today)}
          className="flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3.5 text-sm transition-colors cursor-pointer whitespace-nowrap"
        >
          <BarChart3 className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] shrink-0" />
          <span className="truncate">Export Attendance</span>
        </button>
      </div>

      {/* 12-Card Admin KPI Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {kpiCards.map((card) => (
          <button
            key={card.label}
            type="button"
            onClick={card.action}
            className="text-left rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#D4AF37]/60 p-4 transition-colors cursor-pointer"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-medium text-zinc-500 dark:text-zinc-400 truncate">
                {card.label}
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
            </div>
            <div
              className={`mt-2 font-display text-2xl font-bold tabular-nums ${
                card.highlight
                  ? 'text-[#B45309] dark:text-[#F5B700]'
                  : card.warn
                  ? 'text-amber-500 dark:text-amber-400'
                  : 'text-zinc-900 dark:text-white'
              }`}
            >
              {card.value}
            </div>
            <div className="mt-1 text-xs text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
              {card.sub}
            </div>
          </button>
        ))}
      </div>

      {/* Secure Gym Attendance QR + Weekly Attendance Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-5">
          <GymAttendanceQRCard
            cardRef={qrCardRef}
            gymName={data.settings.gymName}
            gymAddress={data.settings.gymAddress}
            gymQrSecret={data.settings.gymQrSecret}
            onGenerateQr={onRegenerateGymQr}
          />
        </div>

        {/* Weekly Attendance Graph */}
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                {t('weeklyAttendance')}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                Last 7 days · Morning (4AM–12PM) & Evening (12PM–11:59PM)
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs text-zinc-500 dark:text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#F5B700]" />
                Morning
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-zinc-400 dark:bg-zinc-600" />
                Evening
              </span>
            </div>
          </div>

          <div className="h-52 flex items-end justify-between gap-2 sm:gap-4 pt-6">
            {metrics.weeklyBars.map((bar) => {
              const totalPct = Math.round((bar.total / maxWeekly) * 100);
              const morningPct = bar.total > 0 ? Math.round((bar.morning / bar.total) * 100) : 0;
              const isHovered = hoveredDay === bar.date;
              return (
                <button
                  key={bar.date}
                  type="button"
                  onMouseEnter={() => setHoveredDay(bar.date)}
                  onMouseLeave={() => setHoveredDay(null)}
                  onClick={() => setHoveredDay(isHovered ? null : bar.date)}
                  className="flex-1 h-full flex flex-col items-center justify-end gap-2 group cursor-pointer"
                >
                  <span className="text-xs font-mono font-semibold text-zinc-700 dark:text-zinc-300 tabular-nums">
                    {bar.total}
                  </span>
                  <div className="w-full max-w-[44px] h-32 bg-zinc-100 dark:bg-zinc-900 rounded-xl overflow-hidden flex flex-col justify-end relative">
                    <div
                      style={{ height: `${Math.max(bar.total > 0 ? 12 : 0, totalPct)}%` }}
                      className="w-full flex flex-col justify-end transition-all duration-200 rounded-t-lg overflow-hidden"
                    >
                      <div
                        style={{ height: `${100 - morningPct}%` }}
                        className="w-full bg-zinc-400 dark:bg-zinc-600"
                      />
                      <div
                        style={{ height: `${morningPct}%` }}
                        className="w-full bg-[#F5B700]"
                      />
                    </div>
                  </div>
                  <span className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                    {bar.label}
                  </span>
                </button>
              );
            })}
          </div>

          {hoveredDay && (() => {
            const info = metrics.weeklyBars.find((b) => b.date === hoveredDay);
            if (!info) return null;
            return (
              <div className="mt-4 pt-3 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                <span>{formatDateShort(info.date)}</span>
                <span>
                  Morning: <strong className="text-zinc-900 dark:text-white">{info.morning}</strong> · Evening:{' '}
                  <strong className="text-zinc-900 dark:text-white">{info.evening}</strong> · Total:{' '}
                  <strong className="text-[#B45309] dark:text-[#F5B700]">{info.total}</strong>
                </span>
              </div>
            );
          })()}
        </div>
      </div>

      {/* Today's Entry & Exit Records + Follow-Ups Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Today's Entry & Exit Live Feed */}
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <div>
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                Today&apos;s Entry &amp; Exit Records ({metrics.todaysMemberVisits.length})
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                {metrics.currentlyInsideMembers} currently INSIDE GYM
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('attendance')}
              className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] hover:underline cursor-pointer"
            >
              Full History
            </button>
          </div>

          {metrics.todaysMemberVisits.length === 0 ? (
            <div className="p-10 text-center text-sm text-zinc-500 dark:text-zinc-400">
              No Entry or Exit scans recorded today.
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[340px] overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400">
                    <th className="py-2.5 px-4 font-semibold">Member</th>
                    <th className="py-2.5 px-3 font-semibold">Session</th>
                    <th className="py-2.5 px-3 font-semibold">Entry</th>
                    <th className="py-2.5 px-3 font-semibold">Exit</th>
                    <th className="py-2.5 px-3 font-semibold">Duration</th>
                    <th className="py-2.5 px-4 font-semibold text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80 font-mono tabular-nums">
                  {metrics.todaysMemberVisits.map((v) => {
                    const member = memberMap.get(v.personId);
                    const isInside = v.status === 'INSIDE GYM';
                    const durationText = isInside
                      ? computeLiveDuration(v.entryTimestamp || v.createdAt, nowMs).formatted
                      : formatDurationMinutes(v.durationMinutes);
                    return (
                      <tr key={v.id} className="hover:bg-zinc-50 dark:hover:bg-[#18181D]">
                        <td className="py-2.5 px-4 font-sans font-semibold text-zinc-900 dark:text-white whitespace-nowrap">
                          {member ? (
                            <button
                              type="button"
                              onClick={() => onSelectMember(member)}
                              className="hover:text-[#F5B700] cursor-pointer text-left"
                            >
                              {member.name}
                            </button>
                          ) : (
                            v.personId
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-zinc-500 dark:text-zinc-400">
                          {v.shift}
                        </td>
                        <td className="py-2.5 px-3 text-zinc-900 dark:text-white whitespace-nowrap">
                          {formatTime12h(v.entryTime)}
                        </td>
                        <td className="py-2.5 px-3 text-zinc-500 dark:text-zinc-400 whitespace-nowrap">
                          {v.exitTime ? formatTime12h(v.exitTime) : '—'}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-[#B45309] dark:text-[#F5B700] whitespace-nowrap">
                          {durationText}
                        </td>
                        <td className="py-2.5 px-4 text-right font-sans whitespace-nowrap">
                          {isInside ? (
                            <button
                              type="button"
                              onClick={() => onMarkExit(v.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-500 hover:bg-red-500/20 hover:text-red-400 font-bold cursor-pointer"
                            >
                              INSIDE GYM · <LogOut className="w-3 h-3" /> Exit
                            </button>
                          ) : (
                            <span className="text-zinc-500 dark:text-zinc-400 font-semibold">
                              LEFT GYM
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Actionable Expiring & Pending Fees Queue */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                Follow-Ups Today ({metrics.inactive7DaysCount} absent 7d+)
              </h3>
              <button
                type="button"
                onClick={() => onNavigate('renewals')}
                className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] hover:underline cursor-pointer"
              >
                View all
              </button>
            </div>

            {metrics.expiringSoonList.length === 0 && metrics.feePendingMembers.length === 0 ? (
              <div className="py-10 text-center text-sm text-zinc-500 dark:text-zinc-400">
                <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
                All memberships &amp; fees are up to date.
              </div>
            ) : (
              <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
                {[
                  ...metrics.expiringSoonList.slice(0, 3),
                  ...metrics.feePendingMembers
                    .filter((p) => !metrics.expiringSoonList.some((e) => e.id === p.id))
                    .slice(0, 2),
                ].map((m) => {
                  const daysLeft = diffDaysBetween(today, m.expiryDate);
                  const templates = buildWhatsAppTemplates(
                    data.settings.gymName,
                    m,
                    undefined,
                    data.settings.reminderTemplates
                  );
                  const isDue = m.remainingAmount > 0;
                  return (
                    <div key={m.id} className="py-3 flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => onSelectMember(m)}
                        className="flex items-center gap-3 min-w-0 text-left cursor-pointer"
                      >
                        <Avatar src={m.photo} name={m.name} size="sm" />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                            {m.name}
                          </div>
                          <div className="text-xs text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
                            {daysLeft === 0
                              ? 'Expires today'
                              : daysLeft === 1
                              ? 'Expires tomorrow'
                              : daysLeft > 1 && daysLeft <= 7
                              ? `Expires in ${daysLeft}d`
                              : m.id}
                            {isDue ? ` · Due ${formatINR(m.remainingAmount)}` : ''}
                          </div>
                        </div>
                      </button>

                      <div className="flex items-center gap-2 shrink-0">
                        {isDue && (
                          <button
                            type="button"
                            onClick={() => onQuickCollectFee(m)}
                            className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-[#F5B700] hover:text-black text-xs font-semibold text-zinc-900 dark:text-white transition-colors cursor-pointer"
                          >
                            Pay
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            openWhatsAppMessage(
                              m.whatsapp,
                              isDue ? templates.pendingPayment : templates.renewalReminder
                            )
                          }
                          title="Send WhatsApp Reminder"
                          className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl bg-[#F5B700]/15 text-[#B45309] dark:text-[#F5B700] hover:bg-[#F5B700] hover:text-black transition-colors cursor-pointer"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {metrics.inactive7DaysCount > 0 && (
            <button
              type="button"
              onClick={() => onNavigate('inactive')}
              className="mt-4 w-full py-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-500 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <AlertTriangle className="w-3.5 h-3.5" /> Review {metrics.inactive7DaysCount} Absent Members (7+ Days)
            </button>
          )}
        </div>
      </div>

      {/* Recent Payments Feed */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div>
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#F5B700]" />
              {t('recentPayments')} ({metrics.recentPayments.length})
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {t('monthlyRevenue')}: {formatINR(metrics.monthlyRevenue)} · Today: {formatINR(metrics.todaysCollection)}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('fees')}
            className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] hover:underline cursor-pointer"
          >
            All Receipts
          </button>
        </div>

        {metrics.recentPayments.length === 0 ? (
          <div className="p-8 text-center text-sm text-zinc-500 dark:text-zinc-400">
            No fee payments recorded yet.
          </div>
        ) : (
          <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
            {metrics.recentPayments.map((p) => {
              const member = memberMap.get(p.memberId);
              return (
                <div key={p.id} className="px-4 py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => member && onSelectMember(member)}
                      className="text-sm font-semibold text-zinc-900 dark:text-white hover:text-[#F5B700] truncate text-left cursor-pointer"
                    >
                      {p.memberName || member?.name || p.memberId}{' '}
                      <span className="text-xs font-mono text-zinc-400">· {p.receiptNumber}</span>
                    </button>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                      {formatDateShort(p.paymentDate)} · {p.paymentMethod} · {p.notes || p.type}
                    </div>
                  </div>
                  <span className="text-sm font-mono font-bold text-[#B45309] dark:text-[#F5B700] tabular-nums shrink-0">
                    +{formatINR(p.amount)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
