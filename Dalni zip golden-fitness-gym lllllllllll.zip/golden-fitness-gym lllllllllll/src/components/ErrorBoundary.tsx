import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';
import type { FirestoreErrorInfo } from '../firebase';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
  detailMessage: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: '',
      detailMessage: '',
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    let errorMessage = error.message || 'An unexpected error occurred.';
    let detailMessage = '';

    try {
      const parsed = JSON.parse(errorMessage) as FirestoreErrorInfo;
      if (parsed && parsed.operationType) {
        errorMessage = `Cloud sync permission or validation error during ${parsed.operationType}.`;
        detailMessage = parsed.error || '';
      }
    } catch {
      // Not a JSON FirestoreErrorInfo payload
    }

    return {
      hasError: true,
      errorMessage,
      detailMessage,
    };
  }

  componentDidCatch(error: Error) {
    console.error('App ErrorBoundary caught error:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#09090B] text-white flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-3xl bg-[#121216] border border-red-500/30 p-6 space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h2 className="font-display text-lg font-bold">Something went wrong</h2>
            <p className="text-sm text-zinc-300">{this.state.errorMessage}</p>
            {this.state.detailMessage && (
              <p className="text-xs font-mono text-zinc-500 break-words bg-black/40 rounded-xl p-3">
                {this.state.detailMessage}
              </p>
            )}
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full py-3 px-4 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-sm inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" /> Reload App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
