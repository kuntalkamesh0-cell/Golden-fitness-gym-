import React, { useEffect, useMemo, useState } from 'react';
import {
  CalendarCheck,
  Camera,
  Clock,
  Dumbbell,
  IndianRupee,
  LogIn,
  LogOut,
  QrCode,
  Utensils,
} from 'lucide-react';
import type { GymDataPayload, Language } from '../types';
import {
  computeLiveDuration,
  diffDaysBetween,
  formatDateShort,
  formatDurationMinutes,
  formatINR,
  formatTime12h,
  getCurrentTimeHHMMSS,
  getFeeStatus,
  getTodayISO,
  isMemberActive,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';
import { CameraQRScannerModal } from './CameraQRScannerModal';

interface MemberPortalViewProps {
  data: GymDataPayload;
  memberId: string;
  language: Language;
  onScanGymQR: (payload: {
    memberId: string;
    qrCode: string;
    action: 'auto' | 'entry' | 'exit';
    clientDate: string;
    clientTime: string;
  }) => Promise<{ actionTaken: string; message: string }>;
}

export const MemberPortalView: React.FC<MemberPortalViewProps> = ({
  data,
  memberId,
  onScanGymQR,
}) => {
  const member = data.members.find((m) => m.id === memberId) || data.members[0];
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scanAction, setScanAction] = useState<'auto' | 'entry' | 'exit'>('auto');
  const [scanFeedback, setScanFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const today = getTodayISO();

  const myAttendance = useMemo(
    () =>
      member
        ? data.attendance
            .filter((a) => a.personType === 'member' && a.personId === member.id)
            .sort((a, b) =>
              (b.entryTimestamp || b.createdAt).localeCompare(a.entryTimestamp || a.createdAt)
            )
        : [],
    [data.attendance, member]
  );

  const todaysVisits = useMemo(
    () => myAttendance.filter((a) => a.date === today),
    [myAttendance, today]
  );

  if (!member) {
    return (
      <div className="p-8 text-center text-sm text-zinc-500 dark:text-zinc-400">
        Member profile not found.
      </div>
    );
  }

  const daysLeft = diffDaysBetween(today, member.expiryDate);
  const activeStatus = isMemberActive(member, today);
  const feeStatus = getFeeStatus(member);

  const activeVisit = todaysVisits.find((a) => a.status === 'INSIDE GYM');
  const currentGymStatus: 'INSIDE GYM' | 'LEFT GYM' = activeVisit ? 'INSIDE GYM' : 'LEFT GYM';
  const liveSession = activeVisit
    ? computeLiveDuration(activeVisit.entryTimestamp || activeVisit.createdAt, nowMs)
    : null;

  const todayCompletedMinutes = todaysVisits
    .filter((a) => a.status === 'LEFT GYM')
    .reduce((sum, a) => sum + (Number(a.durationMinutes) || 0), 0);
  const todayTotalMinutes = todayCompletedMinutes + (liveSession ? liveSession.minutes : 0);

  const myPayments = data.payments.filter((p) => p.memberId === member.id);
  const myWorkouts = data.workoutPlans.filter((w) => w.memberId === member.id);
  const myDiet = data.dietPlans.find((d) => d.memberId === member.id);

  const openScanner = (action: 'auto' | 'entry' | 'exit') => {
    setScanFeedback(null);
    setScanAction(action);
    setScannerOpen(true);
  };

  const handleDetected = async (rawQr: string) => {
    setScannerOpen(false);
    try {
      const res = await onScanGymQR({
        memberId: member.id,
        qrCode: rawQr,
        action: scanAction,
        clientDate: getTodayISO(),
        clientTime: getCurrentTimeHHMMSS(),
      });
      setScanFeedback({ type: 'ok', text: res.message });
    } catch (err) {
      setScanFeedback({ type: 'err', text: (err as Error).message });
    }
  };

  return (
    <div className="space-y-5">
      {/* Member Identity & Live Gym Status Card (NO QR code shown on Member screen) */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-[#D4AF37]/30 p-5 flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="flex items-center gap-4 min-w-0">
          <Avatar src={member.photo} name={member.name} size="xl" />
          <div className="min-w-0">
            <div className="text-xs font-mono font-bold text-[#B45309] dark:text-[#F5B700] truncate">
              {member.id} · {activeStatus ? 'Active Membership' : 'Inactive / Expired'} ·{' '}
              {daysLeft < 0 ? 'Expired' : `${daysLeft}d left`}
            </div>
            <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white truncate">
              {member.name}
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 tabular-nums">
              Joined {formatDateShort(member.joiningDate)} · Valid until {formatDateShort(member.expiryDate)}
            </p>
            <p className="text-xs font-mono text-zinc-600 dark:text-zinc-300 mt-1 tabular-nums">
              Status:{' '}
              <strong className={currentGymStatus === 'INSIDE GYM' ? 'text-emerald-500' : 'text-zinc-500 dark:text-zinc-400'}>
                {currentGymStatus}
              </strong>
              {liveSession ? ` · Live: ${liveSession.formatted}` : ''}
            </p>
          </div>
        </div>

        {/* Clear ENTRY, EXIT, and QR SCANNER Buttons */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => openScanner('entry')}
            className="flex-1 sm:flex-initial min-h-[48px] inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs tracking-wide transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogIn className="w-4 h-4" /> ENTRY
          </button>
          <button
            type="button"
            onClick={() => openScanner('exit')}
            className="flex-1 sm:flex-initial min-h-[48px] inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-zinc-900 dark:bg-[#1C1C22] border border-zinc-700 hover:border-[#F5B700] text-white font-bold text-xs tracking-wide transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogOut className="w-4 h-4 text-[#F5B700]" /> EXIT
          </button>
          <button
            type="button"
            onClick={() => openScanner('auto')}
            className="w-full sm:w-auto min-h-[48px] inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-xs tracking-wide transition-colors cursor-pointer whitespace-nowrap"
          >
            <Camera className="w-4 h-4" /> QR SCANNER
          </button>
        </div>
      </div>

      {scanFeedback && (
        <div
          className={`px-4 py-3 rounded-2xl text-xs font-semibold border ${
            scanFeedback.type === 'ok'
              ? 'bg-[#F5B700]/15 border-[#F5B700]/40 text-[#B45309] dark:text-[#F5B700]'
              : 'bg-red-500/10 border-red-500/30 text-red-500'
          }`}
        >
          {scanFeedback.text}
        </div>
      )}

      {/* Member Summary KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Gym Status</div>
          <div
            className={`mt-1.5 font-display text-lg font-bold ${
              currentGymStatus === 'INSIDE GYM'
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-zinc-800 dark:text-zinc-200'
            }`}
          >
            {currentGymStatus}
          </div>
          <div className="mt-1 text-xs font-mono text-zinc-500 tabular-nums">
            {activeVisit ? `In since ${formatTime12h(activeVisit.entryTime)}` : 'Scan ENTRY to check in'}
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-[#F5B700]" /> Today&apos;s Gym Time
          </div>
          <div className="mt-1.5 font-display text-xl font-bold text-[#B45309] dark:text-[#F5B700] tabular-nums">
            {liveSession ? liveSession.formatted : formatDurationMinutes(todayTotalMinutes)}
          </div>
          <div className="mt-1 text-xs font-mono text-zinc-500 tabular-nums">
            Total today: {formatDurationMinutes(todayTotalMinutes)} ({todaysVisits.length} visits)
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
            <IndianRupee className="w-3.5 h-3.5 text-[#F5B700]" /> Fee Status
          </div>
          <div
            className={`mt-1.5 font-display text-xl font-bold ${
              feeStatus === 'Paid'
                ? 'text-emerald-600 dark:text-emerald-400'
                : feeStatus === 'Partially Paid'
                ? 'text-amber-500'
                : 'text-red-500'
            }`}
          >
            {feeStatus}
          </div>
          <div className="mt-1 text-xs font-mono text-zinc-500 tabular-nums">
            Fee {formatINR(member.membershipFee)} · Due {formatINR(member.remainingAmount)}
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4">
          <div className="text-xs text-zinc-500 dark:text-zinc-400">Amount Paid</div>
          <div className="mt-1.5 font-display text-xl font-bold text-zinc-900 dark:text-white tabular-nums">
            {formatINR(member.amountPaid)}
          </div>
          <div className="mt-1 text-xs text-zinc-500 truncate">
            {myPayments.length} payment receipt(s)
          </div>
        </div>
      </div>

      {/* Attendance History (Own Entry, Exit, Session, Duration, Status) */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-4 h-4 text-[#F5B700]" />
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              My Attendance History ({myAttendance.length})
            </h3>
          </div>
          <span className="text-xs text-zinc-500 dark:text-zinc-400">
            Morning (4AM–12PM) · Evening (12PM–12AM)
          </span>
        </div>

        {myAttendance.length === 0 ? (
          <div className="p-8 text-center text-sm text-zinc-500 dark:text-zinc-400">
            No gym visits recorded yet. Tap <strong className="text-[#F5B700]">QR SCANNER</strong> at the gym entrance to log your Entry.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400">
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold">Session</th>
                  <th className="py-3 px-4 font-semibold">Entry Time</th>
                  <th className="py-3 px-4 font-semibold">Exit Time</th>
                  <th className="py-3 px-4 font-semibold">Total Duration</th>
                  <th className="py-3 px-4 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80 font-mono tabular-nums">
                {myAttendance.map((a) => {
                  const isInside = a.status === 'INSIDE GYM';
                  const live = isInside
                    ? computeLiveDuration(a.entryTimestamp || a.createdAt, nowMs).formatted
                    : formatDurationMinutes(a.durationMinutes);
                  return (
                    <tr key={a.id} className="hover:bg-zinc-50 dark:hover:bg-[#18181D]">
                      <td className="py-3 px-4 font-sans font-medium text-zinc-900 dark:text-white whitespace-nowrap">
                        {formatDateShort(a.date)}
                      </td>
                      <td className="py-3 px-4 font-sans text-zinc-600 dark:text-zinc-300">
                        {a.shift}
                      </td>
                      <td className="py-3 px-4 text-zinc-900 dark:text-white whitespace-nowrap">
                        {formatTime12h(a.entryTime)}
                      </td>
                      <td className="py-3 px-4 text-zinc-600 dark:text-zinc-400 whitespace-nowrap">
                        {a.exitTime ? formatTime12h(a.exitTime) : '—'}
                      </td>
                      <td className="py-3 px-4 font-bold text-[#B45309] dark:text-[#F5B700] whitespace-nowrap">
                        {live}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-sans font-bold whitespace-nowrap ${
                          isInside
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-zinc-500 dark:text-zinc-400'
                        }`}
                      >
                        {a.status || (a.exitTime ? 'LEFT GYM' : 'INSIDE GYM')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Workout Plan + Diet Plan + Fee History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2">
            <Dumbbell className="w-4 h-4 text-[#F5B700]" />
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              My Workout Plan
            </h3>
          </div>
          <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
            {myWorkouts.length === 0 ? (
              <p className="p-6 text-sm text-zinc-500">Ask your trainer to assign your workout split.</p>
            ) : (
              myWorkouts.map((w) => (
                <div key={w.id} className="p-4">
                  <div className="text-sm font-bold text-zinc-900 dark:text-white">
                    {w.exerciseName}{' '}
                    <span className="text-xs text-[#B45309] dark:text-[#F5B700]">· {w.muscleGroup}</span>
                  </div>
                  <div className="text-xs font-mono text-zinc-500 mt-0.5 tabular-nums">
                    {w.sets} sets × {w.reps} · Rest {w.restTime} · {w.workoutDays}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="space-y-5">
          <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-3">
            <div className="flex items-center gap-2">
              <Utensils className="w-4 h-4 text-[#F5B700]" />
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                My Diet Plan
              </h3>
            </div>
            {!myDiet ? (
              <p className="text-sm text-zinc-500">No diet chart assigned yet.</p>
            ) : (
              <div className="space-y-2 text-xs text-zinc-700 dark:text-zinc-300">
                <div><strong className="text-zinc-900 dark:text-white">Breakfast:</strong> {myDiet.breakfast}</div>
                <div><strong className="text-zinc-900 dark:text-white">Lunch:</strong> {myDiet.lunch}</div>
                <div><strong className="text-zinc-900 dark:text-white">Snacks:</strong> {myDiet.snacks}</div>
                <div><strong className="text-zinc-900 dark:text-white">Dinner:</strong> {myDiet.dinner}</div>
                {myDiet.mealDetails && (
                  <div className="text-[#B45309] dark:text-[#F5B700] pt-1">{myDiet.mealDetails}</div>
                )}
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
            <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2">
              <QrCode className="w-4 h-4 text-[#F5B700]" />
              <h3 className="font-display text-sm font-bold text-zinc-900 dark:text-white">
                My Fee Payments ({myPayments.length})
              </h3>
            </div>
            <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80 max-h-56 overflow-y-auto">
              {myPayments.length === 0 ? (
                <p className="p-5 text-xs text-zinc-500">No payment receipts yet.</p>
              ) : (
                myPayments.map((p) => (
                  <div key={p.id} className="px-4 py-2.5 flex items-center justify-between text-xs font-mono tabular-nums">
                    <span className="text-zinc-900 dark:text-white">
                      {formatDateShort(p.paymentDate)} · {p.paymentMethod}
                    </span>
                    <span className="font-bold text-[#B45309] dark:text-[#F5B700]">
                      {formatINR(p.amount)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Phone Camera QR Scanner Modal (NO QR Code rendered inside) */}
      <CameraQRScannerModal
        isOpen={scannerOpen}
        modeLabel={
          scanAction === 'entry'
            ? 'Scan Gym QR for ENTRY'
            : scanAction === 'exit'
            ? 'Scan Gym QR for EXIT'
            : 'QR Attendance Scanner'
        }
        onClose={() => setScannerOpen(false)}
        onDetected={handleDetected}
      />
    </div>
  );
};
