import React, { useState } from 'react';
import { Dumbbell, KeyRound, ShieldCheck, UserCheck, Users, ArrowRight, LogOut, Cloud } from 'lucide-react';
import type { AuthSession, CloudSyncStatus, GymSettings, Language, Member, Trainer, UserRole } from '../types';
import { useT } from '../i18n/translations';
import { Avatar } from './Avatar';
import { CloudSyncBadge } from './CloudSyncBadge';

interface LoginGateProps {
  settings: GymSettings;
  trainers: Trainer[];
  members: Member[];
  cloudEmail: string;
  syncStatus: CloudSyncStatus;
  language: Language;
  onToggleLanguage: () => void;
  onLoginSuccess: (session: AuthSession) => void;
  onCloudSignOut: () => void;
}

export const LoginGate: React.FC<LoginGateProps> = ({
  settings,
  trainers,
  members,
  cloudEmail,
  syncStatus,
  language,
  onToggleLanguage,
  onLoginSuccess,
  onCloudSignOut,
}) => {
  const t = useT(language);
  const [selectedRole, setSelectedRole] = useState<UserRole>('owner');
  const [pin, setPin] = useState('');
  const [selectedTrainerId, setSelectedTrainerId] = useState(trainers[0]?.id || '');
  const [memberIdentifier, setMemberIdentifier] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const roles: Array<{ id: UserRole; label: string; desc: string; icon: React.ReactNode }> = [
    {
      id: 'owner',
      label: t('ownerRole'),
      desc: 'PIN Required',
      icon: <ShieldCheck className="w-5 h-5" />,
    },
    {
      id: 'reception',
      label: t('receptionRole'),
      desc: 'PIN Required',
      icon: <UserCheck className="w-5 h-5" />,
    },
    {
      id: 'trainer',
      label: t('trainerRole'),
      desc: 'PIN Required',
      icon: <Dumbbell className="w-5 h-5" />,
    },
    {
      id: 'member',
      label: t('memberRole'),
      desc: 'Member ID or Mobile',
      icon: <Users className="w-5 h-5" />,
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (selectedRole !== 'member' && !pin.trim()) {
      setError('Please enter your PIN to log in.');
      return;
    }
    if (selectedRole === 'member' && !memberIdentifier.trim()) {
      setError('Enter your Member ID or Mobile Number.');
      return;
    }

    setLoading(true);
    try {
      const cleanPin = pin.trim();

      if (selectedRole === 'owner') {
        const expectedPin = settings.ownerPin || '1234';
        if (cleanPin !== expectedPin) {
          setError('Invalid Admin PIN');
          return;
        }
        onLoginSuccess({
          role: 'owner',
          userId: 'owner',
          displayName: settings.ownerName || 'Admin',
        });
        return;
      }

      if (selectedRole === 'reception') {
        const expectedPin = settings.receptionPin || '2222';
        if (cleanPin !== expectedPin) {
          setError('Invalid Reception PIN');
          return;
        }
        onLoginSuccess({
          role: 'reception',
          userId: 'reception',
          displayName: 'Reception Desk',
        });
        return;
      }

      if (selectedRole === 'trainer') {
        const chosenId = selectedTrainerId || trainers[0]?.id;
        const trainer = trainers.find((tr) => tr.id === chosenId) || trainers[0];
        if (!trainer) {
          setError('Trainer not found');
          return;
        }
        if (cleanPin !== trainer.pin && cleanPin !== (settings.trainerPin || '3333')) {
          setError('Invalid Trainer PIN');
          return;
        }
        onLoginSuccess({
          role: 'trainer',
          userId: trainer.id,
          trainerId: trainer.id,
          displayName: trainer.name,
        });
        return;
      }

      if (selectedRole === 'member') {
        const lookup = memberIdentifier.trim();
        const found = members.find(
          (m) =>
            m.id.toUpperCase() === lookup.toUpperCase() ||
            m.whatsapp.trim() === lookup
        );
        if (!found) {
          setError('Member ID or Mobile Number not found');
          return;
        }
        onLoginSuccess({
          role: 'member',
          userId: found.id,
          memberId: found.id,
          displayName: found.name,
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-[#09090B] text-zinc-900 dark:text-zinc-100 flex flex-col lg:flex-row">
      {/* Left Hero Visual */}
      <div className="relative lg:w-1/2 min-h-[240px] lg:min-h-screen overflow-hidden bg-[#09090B]">
        <img
          src="/src/assets/images/gym_hero_banner_1795080326990.jpg"
          alt={settings.gymName}
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090B] via-[#09090B]/65 to-black/35" />
        <div className="relative z-10 p-6 lg:p-12 h-full flex flex-col justify-between">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <Avatar src={settings.gymLogo} name={settings.gymName} size="md" className="border-[#D4AF37]/60" />
              <span className="font-display text-lg font-bold text-white tracking-tight truncate">
                {settings.gymName}
              </span>
            </div>
            <button
              type="button"
              onClick={onToggleLanguage}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white backdrop-blur-md transition-colors cursor-pointer shrink-0"
            >
              {language === 'en' ? 'हिन्दी' : 'English'}
            </button>
          </div>

          <div className="mt-10 lg:mt-0 max-w-lg">
            <p className="text-xs font-semibold tracking-wider text-[#F5B700] uppercase">
              Gold &amp; Black Gym Management
            </p>
            <h1 className="mt-2 font-display text-3xl lg:text-5xl font-bold text-white leading-tight">
              {settings.gymName}
            </h1>
            <p className="mt-3 text-sm lg:text-base text-zinc-300 leading-relaxed">
              Secure QR Entry &amp; Exit attendance, Morning &amp; Evening session tracking, live gym duration timers, custom monthly fees, and synced cloud records.
            </p>
          </div>
        </div>
      </div>

      {/* Right Role Selection Panel */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-8 lg:p-12">
        <div className="w-full max-w-md space-y-5">
          {/* Cloud Session Bar */}
          <div className="flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center gap-2 min-w-0">
              <Cloud className="w-4 h-4 text-[#F5B700] shrink-0" />
              <span className="text-xs font-medium text-zinc-600 dark:text-zinc-300 truncate">
                {cloudEmail}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <CloudSyncBadge status={syncStatus} />
              <button
                type="button"
                onClick={onCloudSignOut}
                title="Sign out of Cloud Account"
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-700 text-[11px] font-semibold text-zinc-600 dark:text-zinc-300 hover:text-red-500 cursor-pointer"
              >
                <LogOut className="w-3 h-3" />
                <span>Account</span>
              </button>
            </div>
          </div>

          <div>
            <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white">
              {t('loginTitle')}
            </h2>
            <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
              Select your workspace role to continue
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {roles.map((r) => {
              const active = selectedRole === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => {
                    setSelectedRole(r.id);
                    setError('');
                    setPin('');
                  }}
                  className={`text-left p-4 rounded-2xl border transition-all cursor-pointer min-h-[92px] ${
                    active
                      ? 'bg-[#F5B700]/12 border-[#F5B700] text-zinc-900 dark:text-white'
                      : 'bg-white dark:bg-[#121216] border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400 dark:hover:border-zinc-700'
                  }`}
                >
                  <div className={`mb-2 ${active ? 'text-[#B45309] dark:text-[#F5B700]' : 'text-zinc-400'}`}>
                    {r.icon}
                  </div>
                  <div className="font-display font-bold text-sm">{r.label}</div>
                  <div className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">{r.desc}</div>
                </button>
              );
            })}
          </div>

          <form
            onSubmit={handleSubmit}
            className="space-y-4 bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5"
          >
            {selectedRole === 'trainer' && (
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  Select Trainer Profile
                </label>
                {trainers.length === 0 ? (
                  <p className="rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-200 dark:border-zinc-700 px-3.5 py-3 text-xs text-zinc-500 dark:text-zinc-400">
                    No trainers registered yet. Log in as Admin to add trainers first.
                  </p>
                ) : (
                  <select
                    value={selectedTrainerId || trainers[0]?.id || ''}
                    onChange={(e) => setSelectedTrainerId(e.target.value)}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                  >
                    {trainers.map((tr) => (
                      <option key={tr.id} value={tr.id}>
                        {tr.name} ({tr.specialization})
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}

            {selectedRole === 'member' ? (
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  Member ID or Registered Mobile Number
                </label>
                <input
                  type="text"
                  value={memberIdentifier}
                  onChange={(e) => setMemberIdentifier(e.target.value)}
                  placeholder="Enter Member ID (e.g. GFG-101) or Mobile"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-3 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
                <p className="mt-1.5 text-[11px] text-zinc-500 dark:text-zinc-400">
                  Members can view only their own attendance, gym duration, fee status, and scan the gym QR code.
                </p>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  Security PIN
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    inputMode="numeric"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="Enter security PIN"
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 pl-10 pr-4 py-3 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                  />
                </div>
              </div>
            )}

            {error && <p className="text-xs text-red-500 font-medium">{error}</p>}

            <button
              type="submit"
              disabled={loading || (selectedRole === 'trainer' && trainers.length === 0)}
              className="w-full py-3.5 px-5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-40 disabled:cursor-not-allowed text-black font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>
                {loading
                  ? 'Verifying...'
                  : `Sign In as ${roles.find((r) => r.id === selectedRole)?.label}`}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
