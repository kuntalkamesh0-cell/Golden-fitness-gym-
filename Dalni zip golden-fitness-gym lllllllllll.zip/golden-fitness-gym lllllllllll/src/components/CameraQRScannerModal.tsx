import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, QrCode, X } from 'lucide-react';

interface CameraQRScannerModalProps {
  isOpen: boolean;
  modeLabel?: string;
  onClose: () => void;
  onDetected: (rawValue: string) => Promise<void> | void;
}

export const CameraQRScannerModal: React.FC<CameraQRScannerModalProps> = ({
  isOpen,
  modeLabel = 'Scan Gym Attendance QR',
  onClose,
  onDetected,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const handledRef = useRef(false);

  const [cameraError, setCameraError] = useState('');
  const [cameraReady, setCameraReady] = useState(false);
  const [manualToken, setManualToken] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const stopCamera = () => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraReady(false);
  };

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    handledRef.current = false;
    setCameraError('');
    setManualToken('');

    let active = true;

    const start = async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Camera API unavailable in this browser context. Enter the gym QR code below if needed.');
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: false,
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (!video) return;
        video.srcObject = stream;
        video.setAttribute('playsinline', 'true');
        await video.play();
        setCameraReady(true);

        const BD = (
          window as unknown as {
            BarcodeDetector?: new (opts: { formats: string[] }) => {
              detect: (src: HTMLVideoElement) => Promise<Array<{ rawValue: string }>>;
            };
          }
        ).BarcodeDetector;
        const nativeDetector = BD ? new BD({ formats: ['qr_code'] }) : null;

        const scanFrame = async () => {
          if (!active || !videoRef.current || handledRef.current) return;
          const v = videoRef.current;

          if (v.readyState >= 2 && v.videoWidth > 0 && v.videoHeight > 0) {
            // Fast path: native Android BarcodeDetector
            if (nativeDetector) {
              try {
                const found = await nativeDetector.detect(v);
                if (found.length > 0 && found[0].rawValue) {
                  handledRef.current = true;
                  stopCamera();
                  await onDetected(found[0].rawValue);
                  return;
                }
              } catch {
                // fall back to jsQR below
              }
            }

            // Universal path: jsQR canvas frame decoding (Android WebView, Safari, Firefox, Desktop)
            const canvas = canvasRef.current;
            if (canvas) {
              const w = Math.min(640, v.videoWidth);
              const h = Math.round((v.videoHeight / v.videoWidth) * w);
              if (canvas.width !== w) canvas.width = w;
              if (canvas.height !== h) canvas.height = h;
              const ctx = canvas.getContext('2d', { willReadFrequently: true });
              if (ctx) {
                ctx.drawImage(v, 0, 0, w, h);
                const imgData = ctx.getImageData(0, 0, w, h);
                const code = jsQR(imgData.data, w, h, { inversionAttempts: 'attemptBoth' });
                if (code && code.data) {
                  handledRef.current = true;
                  stopCamera();
                  await onDetected(code.data);
                  return;
                }
              }
            }
          }

          if (active && !handledRef.current) {
            rafRef.current = requestAnimationFrame(scanFrame);
          }
        };

        rafRef.current = requestAnimationFrame(scanFrame);
      } catch {
        if (active) {
          setCameraError(
            'Camera permission denied or no rear camera available. Allow camera access on Android or enter the gym QR token manually below.'
          );
        }
      }
    };

    start();

    return () => {
      active = false;
      stopCamera();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualToken.trim()) return;
    setSubmitting(true);
    try {
      stopCamera();
      await onDetected(manualToken.trim());
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm sm:p-4">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-[#121216] border border-[#D4AF37]/30 shadow-2xl overflow-hidden text-white">
        <div className="px-5 py-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Camera className="w-5 h-5 text-[#F5B700]" />
            <div>
              <h3 className="font-display text-base font-bold text-white">{modeLabel}</h3>
              <p className="text-xs text-zinc-400">Point camera at the Golden Fitness Gym QR code</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:bg-zinc-800 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="relative rounded-2xl overflow-hidden bg-black aspect-[4/3] border border-zinc-800 flex items-center justify-center">
            <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
            <canvas ref={canvasRef} className="hidden" />

            {cameraReady && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="w-48 h-48 rounded-2xl border-2 border-[#F5B700] shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]" />
              </div>
            )}

            {!cameraReady && !cameraError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-xs text-zinc-400">
                <div className="w-8 h-8 rounded-full border-2 border-[#F5B700] border-t-transparent animate-spin" />
                <span>Starting rear camera...</span>
              </div>
            )}
          </div>

          {cameraError && (
            <p className="text-xs text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded-xl p-3">
              {cameraError}
            </p>
          )}

          <form onSubmit={handleManualSubmit} className="space-y-2 pt-1 border-t border-zinc-800">
            <label className="block text-[11px] font-semibold text-zinc-400">
              Manual Gym QR Token (if camera is blocked)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                placeholder="Paste GFG-CHECKIN:... code"
                className="flex-1 rounded-xl bg-[#18181D] border border-zinc-700 px-3 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-[#F5B700]"
              />
              <button
                type="submit"
                disabled={submitting || !manualToken.trim()}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-40 text-black text-xs font-bold cursor-pointer shrink-0"
              >
                <QrCode className="w-4 h-4" /> Verify
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
