import React, { useEffect, useMemo, useState } from 'react';
import { Dumbbell, Utensils, Plus, Trash2 } from 'lucide-react';
import type { DietPlan, Language, Member, MuscleGroup, Trainer, WorkoutPlanItem } from '../types';
import { useT } from '../i18n/translations';

interface WorkoutsDietViewProps {
  members: Member[];
  trainers: Trainer[];
  workoutPlans: WorkoutPlanItem[];
  dietPlans: DietPlan[];
  language: Language;
  editable?: boolean;
  lockedMemberId?: string;
  activeTrainerId?: string;
  onAddWorkout: (payload: Omit<WorkoutPlanItem, 'id' | 'updatedAt'>) => Promise<void>;
  onDeleteWorkout: (id: string) => Promise<void>;
  onSaveDiet: (payload: Omit<DietPlan, 'id' | 'updatedAt'>) => Promise<void>;
}

const MUSCLE_GROUPS: MuscleGroup[] = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Cardio'];

export const WorkoutsDietView: React.FC<WorkoutsDietViewProps> = ({
  members,
  trainers,
  workoutPlans,
  dietPlans,
  language,
  editable = true,
  lockedMemberId,
  activeTrainerId,
  onAddWorkout,
  onDeleteWorkout,
  onSaveDiet,
}) => {
  const t = useT(language);
  const [section, setSection] = useState<'workout' | 'diet'>('workout');
  const [selectedMemberId, setSelectedMemberId] = useState(
    lockedMemberId || members[0]?.id || ''
  );
  const [muscleFilter, setMuscleFilter] = useState<'All' | MuscleGroup>('All');

  // New exercise state
  const [muscleGroup, setMuscleGroup] = useState<MuscleGroup>('Chest');
  const [exerciseName, setExerciseName] = useState('');
  const [sets, setSets] = useState('4');
  const [reps, setReps] = useState('10-12');
  const [restTime, setRestTime] = useState('60s');
  const [workoutDays, setWorkoutDays] = useState('Mon / Thu');
  const [wNotes, setWNotes] = useState('');

  // Diet state
  const currentDiet = useMemo(
    () => dietPlans.find((d) => d.memberId === selectedMemberId),
    [dietPlans, selectedMemberId]
  );
  const [breakfast, setBreakfast] = useState('');
  const [lunch, setLunch] = useState('');
  const [dinner, setDinner] = useState('');
  const [snacks, setSnacks] = useState('');
  const [mealDetails, setMealDetails] = useState('');
  const [trainerNotes, setTrainerNotes] = useState('');
  const [dietSavedMsg, setDietSavedMsg] = useState('');

  useEffect(() => {
    if (lockedMemberId) setSelectedMemberId(lockedMemberId);
  }, [lockedMemberId]);

  useEffect(() => {
    setBreakfast(currentDiet?.breakfast || '');
    setLunch(currentDiet?.lunch || '');
    setDinner(currentDiet?.dinner || '');
    setSnacks(currentDiet?.snacks || '');
    setMealDetails(currentDiet?.mealDetails || '');
    setTrainerNotes(currentDiet?.trainerNotes || '');
    setDietSavedMsg('');
  }, [currentDiet, selectedMemberId]);

  const memberWorkouts = useMemo(() => {
    return workoutPlans.filter((w) => {
      if (w.memberId !== selectedMemberId) return false;
      if (muscleFilter !== 'All' && w.muscleGroup !== muscleFilter) return false;
      return true;
    });
  }, [workoutPlans, selectedMemberId, muscleFilter]);

  const handleAddExercise = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!exerciseName.trim() || !selectedMemberId) return;
    await onAddWorkout({
      memberId: selectedMemberId,
      trainerId: activeTrainerId || trainers[0]?.id || '',
      muscleGroup,
      exerciseName: exerciseName.trim(),
      sets: sets.trim() || '3',
      reps: reps.trim() || '12',
      restTime: restTime.trim() || '60s',
      workoutDays: workoutDays.trim() || 'Mon / Thu',
      notes: wNotes.trim(),
    });
    setExerciseName('');
    setWNotes('');
  };

  const handleSaveDiet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMemberId) return;
    await onSaveDiet({
      memberId: selectedMemberId,
      trainerId: activeTrainerId || trainers[0]?.id || '',
      breakfast,
      lunch,
      dinner,
      snacks,
      mealDetails,
      trainerNotes,
    });
    setDietSavedMsg('Diet plan saved for member');
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-zinc-100 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800">
          <button
            type="button"
            onClick={() => setSection('workout')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              section === 'workout'
                ? 'bg-[#F5B700] text-black'
                : 'text-zinc-600 dark:text-zinc-400'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5" /> {t('workoutPlans')}
          </button>
          <button
            type="button"
            onClick={() => setSection('diet')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              section === 'diet'
                ? 'bg-[#F5B700] text-black'
                : 'text-zinc-600 dark:text-zinc-400'
            }`}
          >
            <Utensils className="w-3.5 h-3.5" /> {t('dietPlans')}
          </button>
        </div>

        {!lockedMemberId && (
          <select
            value={selectedMemberId}
            onChange={(e) => setSelectedMemberId(e.target.value)}
            className="rounded-xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
          >
            {members.length === 0 ? (
              <option value="">No members registered yet</option>
            ) : (
              members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.id} — {m.name}
                </option>
              ))
            )}
          </select>
        )}
      </div>

      {section === 'workout' ? (
        <div className="space-y-4">
          {/* Muscle Group Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {(['All', ...MUSCLE_GROUPS] as const).map((grp) => (
              <button
                key={grp}
                type="button"
                onClick={() => setMuscleFilter(grp)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border whitespace-nowrap cursor-pointer ${
                  muscleFilter === grp
                    ? 'bg-zinc-900 dark:bg-[#F5B700] border-transparent text-white dark:text-black'
                    : 'bg-white dark:bg-[#121216] border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                {grp}
              </button>
            ))}
          </div>

          {editable && (
            <form
              onSubmit={handleAddExercise}
              className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-4 space-y-3"
            >
              <div className="text-xs font-bold text-zinc-900 dark:text-white uppercase tracking-wider">
                Assign Exercise
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5">
                <select
                  value={muscleGroup}
                  onChange={(e) => setMuscleGroup(e.target.value as MuscleGroup)}
                  className="rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
                >
                  {MUSCLE_GROUPS.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={exerciseName}
                  onChange={(e) => setExerciseName(e.target.value)}
                  placeholder="Exercise Name"
                  className="col-span-2 sm:col-span-2 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
                />
                <input
                  type="text"
                  value={sets}
                  onChange={(e) => setSets(e.target.value)}
                  placeholder="Sets (4)"
                  className="rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
                />
                <input
                  type="text"
                  value={reps}
                  onChange={(e) => setReps(e.target.value)}
                  placeholder="Reps (10-12)"
                  className="rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
                />
                <input
                  type="text"
                  value={restTime}
                  onChange={(e) => setRestTime(e.target.value)}
                  placeholder="Rest (60s)"
                  className="rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={workoutDays}
                  onChange={(e) => setWorkoutDays(e.target.value)}
                  placeholder="Workout Days (e.g. Mon / Thu)"
                  className="flex-1 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
                />
                <input
                  type="text"
                  value={wNotes}
                  onChange={(e) => setWNotes(e.target.value)}
                  placeholder="Coaching cue / note"
                  className="flex-1 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" /> Add Exercise
                </button>
              </div>
            </form>
          )}

          {/* Exercise List */}
          <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-100 dark:divide-zinc-800/80">
            {memberWorkouts.length === 0 ? (
              <div className="p-10 text-center text-sm text-zinc-500">
                No exercises assigned for this filter yet.
              </div>
            ) : (
              memberWorkouts.map((w) => (
                <div key={w.id} className="p-4 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-bold text-zinc-900 dark:text-white">
                      {w.exerciseName}{' '}
                      <span className="text-xs font-medium text-[#B45309] dark:text-[#F5B700]">
                        · {w.muscleGroup}
                      </span>
                    </div>
                    <div className="text-xs font-mono text-zinc-500 dark:text-zinc-400 mt-0.5 tabular-nums">
                      {w.sets} sets × {w.reps} reps · Rest {w.restTime} · {w.workoutDays}
                    </div>
                    {w.notes && <div className="text-xs text-zinc-400 mt-0.5">{w.notes}</div>}
                  </div>
                  {editable && (
                    <button
                      type="button"
                      onClick={() => onDeleteWorkout(w.id)}
                      className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-red-500 hover:bg-red-500/10 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <form
          onSubmit={handleSaveDiet}
          className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { label: 'Breakfast', val: breakfast, set: setBreakfast },
              { label: 'Lunch', val: lunch, set: setLunch },
              { label: 'Snacks', val: snacks, set: setSnacks },
              { label: 'Dinner', val: dinner, set: setDinner },
            ].map((meal) => (
              <div key={meal.label}>
                <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
                  {meal.label}
                </label>
                <textarea
                  rows={2}
                  readOnly={!editable}
                  value={meal.val}
                  onChange={(e) => meal.set(e.target.value)}
                  placeholder={`Enter ${meal.label.toLowerCase()} plan...`}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
            ))}
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Meal Details & Macros
            </label>
            <input
              type="text"
              readOnly={!editable}
              value={mealDetails}
              onChange={(e) => setMealDetails(e.target.value)}
              placeholder="Calories, protein target, hydration..."
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Trainer Notes
            </label>
            <input
              type="text"
              readOnly={!editable}
              value={trainerNotes}
              onChange={(e) => setTrainerNotes(e.target.value)}
              placeholder="Special dietary instructions"
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
            />
          </div>

          {dietSavedMsg && (
            <p className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700]">{dietSavedMsg}</p>
          )}

          {editable && (
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-sm cursor-pointer"
            >
              Save Diet Plan
            </button>
          )}
        </form>
      )}
    </div>
  );
};
