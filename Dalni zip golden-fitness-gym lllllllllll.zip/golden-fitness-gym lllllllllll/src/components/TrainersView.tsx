import React, { useState } from 'react';
import { Plus, Trash2, CheckCircle2, Edit3, X, Camera } from 'lucide-react';
import type { AttendanceRecord, Language, Member, Trainer } from '../types';
import { auth, uploadImageWithStorageFallback } from '../firebase';
import { getCurrentTimeHHMM, getTodayISO } from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface TrainersViewProps {
  trainers: Trainer[];
  members: Member[];
  attendance: AttendanceRecord[];
  language: Language;
  onSaveTrainer: (payload: Partial<Trainer>, id?: string) => Promise<void>;
  onDeleteTrainer: (id: string) => Promise<void>;
  onMarkTrainerAttendance: (trainerId: string) => Promise<void>;
}

export const TrainersView: React.FC<TrainersViewProps> = ({
  trainers,
  members,
  attendance,
  onSaveTrainer,
  onDeleteTrainer,
  onMarkTrainerAttendance,
}) => {
  const today = getTodayISO();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Trainer | null>(null);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [photo, setPhoto] = useState('');
  const [pin, setPin] = useState('3333');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const openModal = (tr?: Trainer) => {
    if (tr) {
      setEditing(tr);
      setName(tr.name);
      setMobile(tr.mobile);
      setSpecialization(tr.specialization);
      setPhoto(tr.photo);
      setPin(tr.pin || '3333');
    } else {
      setEditing(null);
      setName('');
      setMobile('');
      setSpecialization('');
      setPhoto('');
      setPin('3333');
    }
    setModalOpen(true);
  };

  const handlePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { url } = await uploadImageWithStorageFallback(
        auth.currentUser?.uid,
        'trainers',
        editing?.id || 'trainer',
        file,
        420
      );
      if (url) setPhoto(url);
    } catch {
      // ignore failed read
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await onSaveTrainer(
      { name: name.trim(), mobile: mobile.trim(), specialization: specialization.trim(), photo, pin },
      editing?.id
    );
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-white">
          Trainers ({trainers.length})
        </h3>
        <button
          type="button"
          onClick={() => openModal()}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Trainer
        </button>
      </div>

      {trainers.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-10 text-center text-sm text-zinc-500 dark:text-zinc-400">
          No trainers added yet. Click &ldquo;Add Trainer&rdquo; to create your first trainer profile.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {trainers.map((tr) => {
          const assigned = members.filter((m) => m.trainerId === tr.id);
          const todayLog = attendance.find(
            (a) => a.personType === 'trainer' && a.personId === tr.id && a.date === today
          );
          return (
            <div
              key={tr.id}
              className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 flex flex-col justify-between gap-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar src={tr.photo} name={tr.name} size="lg" />
                  <div className="min-w-0">
                    <div className="font-display font-bold text-base text-zinc-900 dark:text-white truncate">
                      {tr.name}
                    </div>
                    <div className="text-xs text-[#B45309] dark:text-[#F5B700] font-medium truncate">
                      {tr.specialization}
                    </div>
                    <div className="text-xs font-mono text-zinc-500 mt-0.5">{tr.mobile}</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => openModal(tr)}
                    className="p-2 rounded-lg text-zinc-400 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteId(tr.id)}
                    className="p-2 rounded-lg text-zinc-400 hover:text-red-500 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {confirmDeleteId === tr.id && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-between text-xs">
                  <span className="text-red-400 font-semibold">Remove trainer?</span>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setConfirmDeleteId(null)} className="px-2 py-1 rounded bg-zinc-800 text-white cursor-pointer">
                      No
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await onDeleteTrainer(tr.id);
                        setConfirmDeleteId(null);
                      }}
                      className="px-2 py-1 rounded bg-red-600 text-white font-bold cursor-pointer"
                    >
                      Yes
                    </button>
                  </div>
                </div>
              )}

              <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between gap-2 text-xs">
                <span className="text-zinc-500 dark:text-zinc-400 tabular-nums">
                  Assigned Members: <strong className="text-zinc-900 dark:text-white">{assigned.length}</strong>
                </span>
                <button
                  type="button"
                  disabled={!!todayLog}
                  onClick={() => onMarkTrainerAttendance(tr.id)}
                  className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1 ${
                    todayLog
                      ? 'bg-[#F5B700]/15 text-[#B45309] dark:text-[#F5B700]'
                      : 'bg-zinc-900 dark:bg-[#F5B700] text-white dark:text-black cursor-pointer'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {todayLog ? `In ${todayLog.entryTime}` : `Mark (${getCurrentTimeHHMM()})`}
                </button>
              </div>
            </div>
          );
        })}
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                {editing ? 'Edit Trainer' : 'Add Trainer'}
              </h3>
              <button type="button" onClick={() => setModalOpen(false)} className="text-zinc-500 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={submit} className="space-y-3">
              <div className="flex items-center gap-3">
                <Avatar src={photo} name={name || 'TR'} size="lg" />
                <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-xs font-semibold cursor-pointer">
                  <Camera className="w-4 h-4 text-[#F5B700]" /> Photo
                  <input type="file" accept="image/*" onChange={handlePhoto} className="hidden" />
                </label>
              </div>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Trainer Name"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
              />
              <input
                type="tel"
                required
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="Mobile Number"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
              />
              <input
                type="text"
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                placeholder="Specialization (e.g. Strength & Fat Loss)"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
              />
              <input
                type="text"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Login PIN (e.g. 3333)"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
              />
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#F5B700] text-black font-bold text-sm cursor-pointer"
              >
                Save Trainer
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
