import React, { useRef, useState } from 'react';
import {
  X,
  Edit3,
  Trash2,
  MessageCircle,
  RefreshCw,
  IndianRupee,
  History,
  CalendarCheck,
  QrCode,
  Download,
  Printer,
} from 'lucide-react';
import { QRCodeCanvas, QRCodeSVG } from 'qrcode.react';
import type {
  AttendanceRecord,
  GymSettings,
  Language,
  Member,
  MembershipHistoryRecord,
  PaymentRecord,
} from '../types';
import { useT } from '../i18n/translations';
import {
  buildWhatsAppTemplates,
  diffDaysBetween,
  formatDateShort,
  formatDurationMinutes,
  formatINR,
  formatTime12h,
  getFeeStatus,
  getTodayISO,
  isMemberActive,
  openWhatsAppMessage,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface MemberProfileModalProps {
  member: Member | null;
  settings: GymSettings;
  payments: PaymentRecord[];
  history: MembershipHistoryRecord[];
  attendance: AttendanceRecord[];
  language: Language;
  canDelete?: boolean;
  onClose: () => void;
  onEdit: (m: Member) => void;
  onDelete: (id: string) => Promise<void>;
  onRenew: (m: Member) => void;
  onCollectFee: (m: Member) => void;
}

export const MemberProfileModal: React.FC<MemberProfileModalProps> = ({
  member,
  settings,
  payments,
  history,
  attendance,
  language,
  canDelete = true,
  onClose,
  onEdit,
  onDelete,
  onRenew,
  onCollectFee,
}) => {
  const t = useT(language);
  const [tab, setTab] = useState<'overview' | 'payments' | 'history' | 'attendance'>('overview');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [printingPayment, setPrintingPayment] = useState<PaymentRecord | null>(null);
  const memberQrCanvasRef = useRef<HTMLDivElement | null>(null);

  if (!member) return null;

  const today = getTodayISO();
  const daysLeft = diffDaysBetween(today, member.expiryDate);
  const memberPayments = payments.filter((p) => p.memberId === member.id);
  const memberHistory = history.filter((h) => h.memberId === member.id);
  const memberAttendance = attendance.filter(
    (a) => a.personType === 'member' && a.personId === member.id
  );
  const templates = buildWhatsAppTemplates(
    settings.gymName,
    member,
    {
      receiptNumber: memberPayments[0]?.receiptNumber,
      paymentDate: memberPayments[0]?.paymentDate,
      amountPaid: memberPayments[0]?.amount ?? member.amountPaid,
    },
    settings.reminderTemplates
  );

  const handleDownloadMemberQr = () => {
    const srcCanvas = memberQrCanvasRef.current?.querySelector('canvas');
    if (!srcCanvas) return;
    const width = 640;
    const height = 820;
    const poster = document.createElement('canvas');
    poster.width = width;
    poster.height = height;
    const ctx = poster.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 8;
    ctx.strokeRect(18, 18, width - 36, height - 36);

    ctx.fillStyle = '#09090B';
    ctx.fillRect(18, 18, width - 36, 110);
    ctx.fillStyle = '#F5B700';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText((settings.gymName || 'Golden Fitness Gym').toUpperCase(), width / 2, 72);
    ctx.fillStyle = '#E4E4E7';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('MEMBER ID BADGE', width / 2, 106);

    ctx.drawImage(srcCanvas, 120, 165, 400, 400);

    ctx.fillStyle = '#09090B';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(member.name, width / 2, 625);
    ctx.fillStyle = '#B45309';
    ctx.font = 'bold 22px monospace';
    ctx.fillText(member.qrToken, width / 2, 668);
    ctx.fillStyle = '#52525B';
    ctx.font = '18px sans-serif';
    ctx.fillText(`Valid until ${formatDateShort(member.expiryDate)}`, width / 2, 712);

    const url = poster.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${member.id}-member-qr.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrintMemberQr = () => {
    document.body.classList.add('printing-member-qr');
    const cleanup = () => {
      document.body.classList.remove('printing-member-qr');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 1500);
  };

  const handlePrintReceipt = (payment: PaymentRecord) => {
    setPrintingPayment(payment);
    setTimeout(() => {
      document.body.classList.add('printing-fee-receipt');
      const cleanup = () => {
        document.body.classList.remove('printing-fee-receipt');
        window.removeEventListener('afterprint', cleanup);
      };
      window.addEventListener('afterprint', cleanup);
      window.print();
      setTimeout(cleanup, 1500);
    }, 60);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm sm:p-4">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden">
        {/* Top Bar */}
        <div className="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <Avatar src={member.photo} name={member.name} size="md" />
            <div className="min-w-0">
              <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white truncate">
                {member.name}
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono truncate">
                {member.id} · {member.whatsapp}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-5 py-2.5 border-b border-zinc-200 dark:border-zinc-800 flex gap-1.5 overflow-x-auto shrink-0">
          {[
            { id: 'overview', label: 'Profile & QR' },
            { id: 'payments', label: `Payments (${memberPayments.length})` },
            { id: 'history', label: `Membership (${memberHistory.length})` },
            { id: 'attendance', label: `Attendance (${memberAttendance.length})` },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                tab === item.id
                  ? 'bg-[#F5B700] text-black'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-5 space-y-5 flex-1">
          {tab === 'overview' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                <div className="sm:col-span-2 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Custom Fee</span>
                    <div className="font-mono font-bold text-zinc-900 dark:text-white tabular-nums">
                      {formatINR(member.membershipFee)}
                      {member.discount > 0 ? ` (-${formatINR(member.discount)})` : ''}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Paid / Remaining</span>
                    <div className="font-mono font-bold tabular-nums">
                      <span className="text-[#B45309] dark:text-[#F5B700]">{formatINR(member.amountPaid)}</span>
                      <span className="text-zinc-400"> / </span>
                      <span className={member.remainingAmount > 0 ? 'text-amber-500' : 'text-zinc-500'}>
                        {formatINR(member.remainingAmount)}
                      </span>
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Duration</span>
                    <div className="font-semibold text-zinc-900 dark:text-white">
                      {member.durationValue} {member.durationUnit}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Validity &amp; Status</span>
                    <div className={`font-mono font-semibold tabular-nums ${!isMemberActive(member, today) ? 'text-red-500' : daysLeft <= 7 ? 'text-amber-500' : 'text-[#B45309] dark:text-[#F5B700]'}`}>
                      {member.membershipStatus || 'Active'} · {formatDateShort(member.expiryDate)} ({daysLeft < 0 ? 'Expired' : `${daysLeft}d left`})
                    </div>
                    <div className="text-[11px] font-mono text-zinc-500 mt-0.5">
                      Fee Status: {getFeeStatus(member)}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Joining / Start Date</span>
                    <div className="font-mono text-xs font-semibold text-zinc-900 dark:text-white tabular-nums">
                      {formatDateShort(member.joiningDate)} → {formatDateShort(member.startDate || member.joiningDate)}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Trainer</span>
                    <div className="font-medium text-zinc-900 dark:text-white">
                      {member.trainerName || 'Unassigned'}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Age / Gender</span>
                    <div className="font-medium text-zinc-900 dark:text-white">
                      {member.age} yrs · {member.gender}
                    </div>
                  </div>
                  <div className="col-span-2">
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">Address &amp; Notes</span>
                    <div className="text-xs text-zinc-700 dark:text-zinc-300 mt-0.5">
                      {member.address || 'No address'} {member.notes ? `· ${member.notes}` : ''}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-white border border-zinc-200 dark:border-zinc-800">
                  <QRCodeSVG value={member.qrToken} size={112} level="M" />
                  <div ref={memberQrCanvasRef} className="hidden" aria-hidden="true">
                    <QRCodeCanvas value={member.qrToken} size={400} level="M" marginSize={3} />
                  </div>
                  <span className="mt-2 text-[11px] font-mono font-bold text-zinc-900 flex items-center gap-1">
                    <QrCode className="w-3 h-3" /> {member.qrToken}
                  </span>
                  <div className="mt-2.5 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleDownloadMemberQr}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-100 hover:bg-[#F5B700] text-zinc-900 text-[11px] font-semibold cursor-pointer"
                    >
                      <Download className="w-3 h-3" /> Save
                    </button>
                    <button
                      type="button"
                      onClick={handlePrintMemberQr}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-100 hover:bg-[#F5B700] text-zinc-900 text-[11px] font-semibold cursor-pointer"
                    >
                      <Printer className="w-3 h-3" /> Print
                    </button>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => onEdit(member)}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" /> Edit
                </button>
                <button
                  type="button"
                  onClick={() => onCollectFee(member)}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-[#F5B700] hover:text-black text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer"
                >
                  <IndianRupee className="w-3.5 h-3.5" /> Collect Fee
                </button>
                <button
                  type="button"
                  onClick={() => onRenew(member)}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> {t('renewNow')}
                </button>
                {canDelete && (
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(true)}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 text-xs font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete
                  </button>
                )}
              </div>

              {confirmDelete && (
                <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-red-400">
                    Permanently delete {member.name} and all records?
                  </span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(false)}
                      className="px-3 py-1.5 rounded-lg bg-zinc-800 text-xs text-white cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await onDelete(member.id);
                        onClose();
                      }}
                      className="px-3 py-1.5 rounded-lg bg-red-600 text-xs font-bold text-white cursor-pointer"
                    >
                      Confirm Delete
                    </button>
                  </div>
                </div>
              )}

              {/* WhatsApp Direct Actions */}
              <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800">
                <div className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-2.5">
                  WhatsApp Direct Messages
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => openWhatsAppMessage(member.whatsapp, templates.feeReminder)}
                    className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-xs font-medium text-zinc-800 dark:text-zinc-200 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F5B700]" /> {t('feeReminder')}
                  </button>
                  <button
                    type="button"
                    onClick={() => openWhatsAppMessage(member.whatsapp, templates.renewalReminder)}
                    className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-xs font-medium text-zinc-800 dark:text-zinc-200 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F5B700]" /> {t('renewalReminder')}
                  </button>
                  <button
                    type="button"
                    onClick={() => openWhatsAppMessage(member.whatsapp, templates.pendingPayment)}
                    className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-xs font-medium text-zinc-800 dark:text-zinc-200 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-amber-400" /> {t('pendingReminder')}
                  </button>
                  <button
                    type="button"
                    onClick={() => openWhatsAppMessage(member.whatsapp, templates.paymentReceipt)}
                    className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-xs font-medium text-zinc-800 dark:text-zinc-200 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F5B700]" /> {t('sendReceipt')}
                  </button>
                </div>
              </div>
            </>
          )}

          {tab === 'payments' && (
            <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {memberPayments.length === 0 ? (
                <p className="py-8 text-center text-sm text-zinc-500">No payments recorded yet.</p>
              ) : (
                memberPayments.map((p) => (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold font-mono text-zinc-900 dark:text-white tabular-nums">
                        {formatINR(p.amount)} · {p.paymentMethod}
                      </div>
                      <div className="text-xs text-zinc-500 dark:text-zinc-400">
                        {formatDateShort(p.paymentDate)} · {p.receiptNumber} · {p.notes || p.type}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handlePrintReceipt(p)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-zinc-300 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:border-[#F5B700] cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" /> PDF
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          openWhatsAppMessage(
                            member.whatsapp,
                            buildWhatsAppTemplates(
                              settings.gymName,
                              member,
                              {
                                amountPaid: p.amount,
                                receiptNumber: p.receiptNumber,
                                paymentDate: p.paymentDate,
                              },
                              settings.reminderTemplates
                            ).paymentReceipt
                          )
                        }
                        className="px-3 py-1.5 rounded-xl bg-[#F5B700]/15 text-[#B45309] dark:text-[#F5B700] text-xs font-semibold cursor-pointer"
                      >
                        WhatsApp
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'history' && (
            <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {memberHistory.length === 0 ? (
                <p className="py-8 text-center text-sm text-zinc-500">No membership history yet.</p>
              ) : (
                memberHistory.map((h) => (
                  <div key={h.id} className="py-3 flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <History className="w-4 h-4 text-[#B45309] dark:text-[#F5B700] mt-0.5 shrink-0" />
                      <div>
                        <div className="text-sm font-semibold text-zinc-900 dark:text-white capitalize">
                          {h.actionType.replace('_', ' ')} · {h.durationValue} {h.durationUnit}
                        </div>
                        <div className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                          {formatDateShort(h.startDate)} → {formatDateShort(h.expiryDate)}
                        </div>
                        {h.notes && <div className="text-xs text-zinc-400 mt-0.5">{h.notes}</div>}
                      </div>
                    </div>
                    <div className="text-right font-mono text-xs tabular-nums">
                      <div className="font-bold text-zinc-900 dark:text-white">{formatINR(h.fee)}</div>
                      <div className="text-zinc-500">Paid {formatINR(h.amountPaid)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'attendance' && (
            <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {memberAttendance.length === 0 ? (
                <p className="py-8 text-center text-sm text-zinc-500">No attendance logged yet.</p>
              ) : (
                memberAttendance.map((a) => (
                  <div key={a.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <CalendarCheck className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
                      <div>
                        <div className="text-sm font-medium text-zinc-900 dark:text-white tabular-nums">
                          {formatDateShort(a.date)} · {a.shift}
                        </div>
                        <div className="text-xs font-mono text-zinc-500 dark:text-zinc-400 tabular-nums">
                          In: {formatTime12h(a.entryTime)} · Out: {a.exitTime ? formatTime12h(a.exitTime) : 'Still Inside'}
                        </div>
                      </div>
                    </div>
                    <div className="text-right font-mono text-xs tabular-nums">
                      <div className="font-bold text-[#B45309] dark:text-[#F5B700]">
                        {a.status === 'INSIDE GYM' ? 'Live' : formatDurationMinutes(a.durationMinutes)}
                      </div>
                      <div className={a.status === 'INSIDE GYM' ? 'text-emerald-500 font-semibold' : 'text-zinc-500'}>
                        {a.status || (a.exitTime ? 'LEFT GYM' : 'INSIDE GYM')}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* Printable Member QR Badge */}
      <div id="printable-member-qr" className="hidden bg-white text-black p-8 text-center" aria-hidden="true">
        <div className="border-4 border-[#D4AF37] rounded-3xl p-8 max-w-md mx-auto bg-white flex flex-col items-center gap-4">
          <div className="bg-[#09090B] text-[#F5B700] px-5 py-2.5 rounded-xl font-display font-bold text-xl uppercase">
            {settings.gymName || 'Golden Fitness Gym'}
          </div>
          <div className="text-xs font-bold tracking-widest uppercase text-zinc-600">
            Personal Member Attendance QR
          </div>
          <QRCodeSVG value={member.qrToken} size={240} level="M" marginSize={3} />
          <div className="text-xl font-bold text-zinc-900">{member.name}</div>
          <div className="text-sm font-mono font-bold text-[#B45309]">{member.qrToken}</div>
          <div className="text-xs text-zinc-600">
            Valid Until: {formatDateShort(member.expiryDate)}
          </div>
        </div>
      </div>

      {/* Printable Fee Receipt */}
      {printingPayment && (
        <div id="printable-fee-receipt" className="hidden bg-white text-black p-8" aria-hidden="true">
          <div className="max-w-lg mx-auto border-2 border-zinc-800 rounded-2xl p-6 space-y-4">
            <div className="border-b border-zinc-300 pb-3 flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl font-bold">{settings.gymName}</h2>
                <p className="text-xs text-zinc-600">{settings.gymAddress || settings.contactNumber}</p>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold uppercase text-zinc-500">Payment Receipt</div>
                <div className="text-sm font-mono font-bold">{printingPayment.receiptNumber}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-zinc-500 text-xs block">Member</span><strong>{member.name} ({member.id})</strong></div>
              <div><span className="text-zinc-500 text-xs block">Date</span><strong>{formatDateShort(printingPayment.paymentDate)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Amount Paid</span><strong className="font-mono">{formatINR(printingPayment.amount)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Payment Method</span><strong>{printingPayment.paymentMethod}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Remaining Due</span><strong className="font-mono">{formatINR(member.remainingAmount)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Valid Until</span><strong>{formatDateShort(member.expiryDate)}</strong></div>
            </div>
            {printingPayment.notes && (
              <div className="text-xs text-zinc-600 border-t border-zinc-200 pt-2">
                Notes: {printingPayment.notes}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
