import React from 'react';
import { Cloud, CloudOff, RefreshCw } from 'lucide-react';
import type { CloudSyncStatus } from '../types';

interface CloudSyncBadgeProps {
  status: CloudSyncStatus;
  onClick?: () => void;
}

export const CloudSyncBadge: React.FC<CloudSyncBadgeProps> = ({ status, onClick }) => {
  const config =
    status === 'offline'
      ? {
          label: 'Offline',
          icon: <CloudOff className="w-3.5 h-3.5" />,
          classes:
            'bg-amber-500/15 border-amber-500/40 text-amber-600 dark:text-amber-400',
        }
      : status === 'syncing'
      ? {
          label: 'Syncing',
          icon: <RefreshCw className="w-3.5 h-3.5 animate-spin" />,
          classes:
            'bg-[#F5B700]/15 border-[#F5B700]/40 text-[#B45309] dark:text-[#F5B700]',
        }
      : {
          label: 'Synced',
          icon: <Cloud className="w-3.5 h-3.5" />,
          classes:
            'bg-emerald-500/15 border-emerald-500/35 text-emerald-700 dark:text-emerald-400',
        };

  return (
    <button
      type="button"
      onClick={onClick}
      title={`Cloud status: ${config.label}`}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[11px] font-bold whitespace-nowrap transition-colors cursor-pointer ${config.classes}`}
    >
      {config.icon}
      <span>{config.label}</span>
    </button>
  );
};
