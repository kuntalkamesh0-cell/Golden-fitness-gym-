import React, { useEffect, useState } from 'react';
import { Camera, X, Calendar, IndianRupee } from 'lucide-react';
import type { DurationUnit, Language, Member, MembershipStatus, Trainer } from '../types';
import { useT } from '../i18n/translations';
import { auth, uploadImageWithStorageFallback } from '../firebase';
import {
  calculateExpiryDate,
  computeRemainingBalance,
  formatINR,
  getTodayISO,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface MemberFormModalProps {
  isOpen: boolean;
  editingMember?: Member | null;
  trainers: Trainer[];
  paymentMethods: string[];
  language: Language;
  onClose: () => void;
  onSave: (payload: Partial<Member>, editingId?: string) => Promise<void>;
}

export const MemberFormModal: React.FC<MemberFormModalProps> = ({
  isOpen,
  editingMember,
  trainers,
  paymentMethods,
  language,
  onClose,
  onSave,
}) => {
  const t = useT(language);
  const today = getTodayISO();

  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [age, setAge] = useState('24');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [address, setAddress] = useState('');
  const [joiningDate, setJoiningDate] = useState(today);
  const [photo, setPhoto] = useState('');
  const [durationValue, setDurationValue] = useState('1');
  const [durationUnit, setDurationUnit] = useState<DurationUnit>('months');
  const [startDate, setStartDate] = useState(today);
  const [expiryDate, setExpiryDate] = useState(calculateExpiryDate(today, 1, 'months'));
  const [manualExpiryOverride, setManualExpiryOverride] = useState(false);

  // Completely custom pricing — no fixed plans!
  const [membershipFee, setMembershipFee] = useState('');
  const [discount, setDiscount] = useState('0');
  const [amountPaid, setAmountPaid] = useState('');
  const [paymentMethod, setPaymentMethod] = useState(paymentMethods[0] || 'Cash');
  const [membershipStatus, setMembershipStatus] = useState<MembershipStatus>('Active');
  const [trainerId, setTrainerId] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (editingMember) {
      setName(editingMember.name);
      setWhatsapp(editingMember.whatsapp);
      setAge(String(editingMember.age));
      setGender(editingMember.gender);
      setAddress(editingMember.address);
      setJoiningDate(editingMember.joiningDate);
      setPhoto(editingMember.photo);
      setDurationValue(String(editingMember.durationValue));
      setDurationUnit(editingMember.durationUnit);
      setStartDate(editingMember.startDate);
      setExpiryDate(editingMember.expiryDate);
      setManualExpiryOverride(true);
      setMembershipFee(String(editingMember.membershipFee));
      setDiscount(String(editingMember.discount));
      setAmountPaid(String(editingMember.amountPaid));
      setPaymentMethod(editingMember.paymentMethod || paymentMethods[0] || 'Cash');
      setMembershipStatus(editingMember.membershipStatus || 'Active');
      setTrainerId(editingMember.trainerId || '');
      setNotes(editingMember.notes || '');
    } else {
      setName('');
      setWhatsapp('');
      setAge('24');
      setGender('Male');
      setAddress('');
      setJoiningDate(today);
      setPhoto('');
      setDurationValue('1');
      setDurationUnit('months');
      setStartDate(today);
      setExpiryDate(calculateExpiryDate(today, 1, 'months'));
      setManualExpiryOverride(false);
      setMembershipFee('');
      setDiscount('0');
      setAmountPaid('');
      setPaymentMethod(paymentMethods[0] || 'Cash');
      setMembershipStatus('Active');
      setTrainerId(trainers[0]?.id || '');
      setNotes('');
    }
    setError('');
  }, [isOpen, editingMember, today, paymentMethods, trainers]);

  // Auto-calculate expiry date whenever duration or start date changes (unless manually adjusted)
  useEffect(() => {
    if (manualExpiryOverride) return;
    const val = Number(durationValue) || 0;
    if (val > 0 && startDate) {
      setExpiryDate(calculateExpiryDate(startDate, val, durationUnit));
    }
  }, [durationValue, durationUnit, startDate, manualExpiryOverride]);

  if (!isOpen) return null;

  const feeNum = Number(membershipFee) || 0;
  const discountNum = Number(discount) || 0;
  const paidNum = Number(amountPaid) || 0;
  const remainingNum = computeRemainingBalance(feeNum, discountNum, paidNum);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { url } = await uploadImageWithStorageFallback(
        auth.currentUser?.uid,
        'members',
        editingMember?.id || 'member',
        file,
        420
      );
      if (url) setPhoto(url);
    } catch {
      setError('Could not process selected photo');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter member name');
      return;
    }
    if (!whatsapp.trim()) {
      setError('Please enter WhatsApp mobile number');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const chosenTrainer = trainers.find((tr) => tr.id === trainerId);
      await onSave(
        {
          name: name.trim(),
          whatsapp: whatsapp.trim(),
          age: Number(age) || 24,
          gender,
          address: address.trim(),
          joiningDate,
          photo,
          durationValue: Number(durationValue) || 1,
          durationUnit,
          startDate,
          expiryDate,
          membershipFee: feeNum,
          discount: discountNum,
          amountPaid: paidNum,
          remainingAmount: remainingNum,
          paymentMethod,
          membershipStatus,
          trainerId: chosenTrainer?.id || '',
          trainerName: chosenTrainer?.name || '',
          notes: notes.trim(),
        },
        editingMember?.id
      );
      onClose();
    } catch (err) {
      setError((err as Error).message || 'Failed to save member');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm sm:p-4">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between shrink-0">
          <div>
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">
              {editingMember ? `${t('updateMember')} · ${editingMember.id}` : t('addMember')}
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {t('customFeeNotice')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-5">
          {/* Photo & Primary Info */}
          <div className="flex items-center gap-4">
            <Avatar src={photo} name={name || 'Member'} size="xl" />
            <div className="flex-1 space-y-2">
              <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-xs font-semibold text-zinc-800 dark:text-zinc-200 cursor-pointer">
                <Camera className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
                <span>{t('memberPhoto')}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
              {photo && (
                <button
                  type="button"
                  onClick={() => setPhoto('')}
                  className="ml-3 text-xs text-red-500 hover:underline cursor-pointer"
                >
                  Remove
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                {t('memberName')} *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Aarav Mehta"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                {t('whatsappNumber')} *
              </label>
              <input
                type="tel"
                required
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                placeholder="e.g. 9876543210"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  {t('age')}
                </label>
                <input
                  type="number"
                  min={10}
                  max={100}
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                  {t('gender')}
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'Male' | 'Female' | 'Other')}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                {t('joiningDate')}
              </label>
              <input
                type="date"
                value={joiningDate}
                onChange={(e) => setJoiningDate(e.target.value)}
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                Membership Status
              </label>
              <select
                value={membershipStatus}
                onChange={(e) => setMembershipStatus(e.target.value as MembershipStatus)}
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-semibold text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                {t('address')}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Street, sector, city"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              />
            </div>
          </div>

          {/* Custom Duration & Dates */}
          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="text-xs font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
                {t('membershipDuration')}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { v: '15', u: 'days' as DurationUnit, label: '15d' },
                  { v: '1', u: 'months' as DurationUnit, label: '1m' },
                  { v: '3', u: 'months' as DurationUnit, label: '3m' },
                  { v: '6', u: 'months' as DurationUnit, label: '6m' },
                  { v: '1', u: 'years' as DurationUnit, label: '1y' },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setManualExpiryOverride(false);
                      setDurationValue(preset.v);
                      setDurationUnit(preset.u);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-[#F5B700] hover:text-black text-xs font-semibold text-zinc-700 dark:text-zinc-300 transition-colors cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Duration
                </label>
                <input
                  type="number"
                  min={1}
                  value={durationValue}
                  onChange={(e) => {
                    setManualExpiryOverride(false);
                    setDurationValue(e.target.value);
                  }}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Unit
                </label>
                <select
                  value={durationUnit}
                  onChange={(e) => {
                    setManualExpiryOverride(false);
                    setDurationUnit(e.target.value as DurationUnit);
                  }}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                >
                  <option value="days">Days</option>
                  <option value="months">Months</option>
                  <option value="years">Years</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('startDate')}
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => {
                    setManualExpiryOverride(false);
                    setStartDate(e.target.value);
                  }}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('expiryDate')}
                </label>
                <input
                  type="date"
                  value={expiryDate}
                  onChange={(e) => {
                    setManualExpiryOverride(true);
                    setExpiryDate(e.target.value);
                  }}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-[#F5B700]/60 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('customExpiryHint')}</p>
          </div>

          {/* 100% Custom Membership Fee Section */}
          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="text-xs font-bold text-zinc-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <IndianRupee className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
                Custom Fee & Payment (No Fixed Plans)
              </span>
              <span className="text-xs font-mono font-bold text-amber-500 dark:text-amber-400 tabular-nums">
                {t('remainingBalance')}: {formatINR(remainingNum)}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('membershipFee')} *
                </label>
                <input
                  type="number"
                  min={0}
                  required
                  value={membershipFee}
                  onChange={(e) => setMembershipFee(e.target.value)}
                  placeholder="e.g. 500 or 700"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono font-bold text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('discount')}
                </label>
                <input
                  type="number"
                  min={0}
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                  placeholder="0"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('amountPaid')}
                </label>
                <input
                  type="number"
                  min={0}
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  placeholder="0"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono font-bold text-[#B45309] dark:text-[#F5B700] focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('paymentMethod')}
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                >
                  {paymentMethods.map((pm) => (
                    <option key={pm} value={pm}>
                      {pm}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('trainerName')}
                </label>
                <select
                  value={trainerId}
                  onChange={(e) => setTrainerId(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                >
                  <option value="">No Trainer Assigned</option>
                  {trainers.map((tr) => (
                    <option key={tr.id} value={tr.id}>
                      {tr.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('notes')}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Custom timing, goal, or fee note"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
            </div>
          </div>

          {error && <p className="text-xs font-semibold text-red-500">{error}</p>}

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 rounded-xl border border-zinc-300 dark:border-zinc-700 text-sm font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-sm transition-colors cursor-pointer"
            >
              {saving ? 'Saving...' : editingMember ? t('updateMember') : t('saveMember')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
