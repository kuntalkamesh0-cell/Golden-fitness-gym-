import React, { useMemo, useState } from 'react';
import { Search, UserPlus, ChevronRight, Download } from 'lucide-react';
import type { Language, Member } from '../types';
import { useT } from '../i18n/translations';
import {
  diffDaysBetween,
  exportMembersCSV,
  formatDateShort,
  formatINR,
  getFeeStatus,
  getTodayISO,
  isMemberActive,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface MembersViewProps {
  members: Member[];
  language: Language;
  onAddMember: () => void;
  onSelectMember: (m: Member) => void;
}

export const MembersView: React.FC<MembersViewProps> = ({
  members,
  language,
  onAddMember,
  onSelectMember,
}) => {
  const t = useT(language);
  const today = getTodayISO();
  const [filter, setFilter] = useState<'all' | 'active' | 'expired' | 'inactive' | 'pending'>('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return members.filter((m) => {
      const active = isMemberActive(m, today);
      const isExpired = diffDaysBetween(today, m.expiryDate) < 0;
      if (filter === 'active' && !active) return false;
      if (filter === 'expired' && !isExpired) return false;
      if (filter === 'inactive' && active) return false;
      if (filter === 'pending' && m.remainingAmount <= 0) return false;
      if (!q) return true;
      return (
        m.name.toLowerCase().includes(q) ||
        m.whatsapp.toLowerCase().includes(q) ||
        m.id.toLowerCase().includes(q)
      );
    });
  }, [members, filter, query, today]);

  const counts = useMemo(() => {
    const active = members.filter((m) => isMemberActive(m, today)).length;
    const expired = members.filter((m) => diffDaysBetween(today, m.expiryDate) < 0).length;
    const inactive = members.length - active;
    const pending = members.filter((m) => m.remainingAmount > 0).length;
    return { all: members.length, active, expired, inactive, pending };
  }, [members, today]);

  return (
    <div className="space-y-4">
      {/* Search, Export & Register Header */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('searchPlaceholder')}
            className="w-full rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 pl-10 pr-4 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
          />
        </div>
        <div className="flex gap-2 shrink-0">
          <button
            type="button"
            onClick={() => exportMembersCSV(members, today)}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 hover:border-[#F5B700] text-zinc-900 dark:text-white font-semibold px-4 py-3 text-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#F5B700]" />
            <span>CSV</span>
          </button>
          <button
            type="button"
            onClick={onAddMember}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 rounded-2xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold px-5 py-3 text-sm transition-colors whitespace-nowrap cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t('addMember')}</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-zinc-100 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
        {[
          { id: 'all', label: `${t('allMembers')} (${counts.all})` },
          { id: 'active', label: `${t('active')} (${counts.active})` },
          { id: 'expired', label: `${t('expired')} (${counts.expired})` },
          { id: 'inactive', label: `Inactive (${counts.inactive})` },
          { id: 'pending', label: `${t('pendingPayment')} (${counts.pending})` },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id as typeof filter)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              filter === item.id
                ? 'bg-white dark:bg-[#18181D] text-zinc-900 dark:text-[#F5B700] shadow-sm'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Member Directory List */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-100 dark:divide-zinc-800/80 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-sm text-zinc-500 dark:text-zinc-400">
            {members.length === 0
              ? 'No members registered yet. Click "Register Member" to add your first member.'
              : 'No members match your filter.'}
          </div>
        ) : (
          filtered.map((m) => {
            const active = isMemberActive(m, today);
            const daysLeft = diffDaysBetween(today, m.expiryDate);
            const feeStatus = getFeeStatus(m);
            const statusText = !active
              ? m.membershipStatus === 'Inactive'
                ? 'Inactive'
                : 'Expired'
              : daysLeft <= 7
              ? `Expiring in ${daysLeft}d`
              : 'Active';
            const statusColor = !active
              ? 'text-red-500'
              : daysLeft <= 7
              ? 'text-amber-500'
              : 'text-emerald-600 dark:text-emerald-400';

            return (
              <button
                key={m.id}
                type="button"
                onClick={() => onSelectMember(m)}
                className="w-full p-4 flex items-center justify-between gap-3 hover:bg-zinc-50 dark:hover:bg-[#18181D] transition-colors text-left cursor-pointer"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <Avatar src={m.photo} name={m.name} size="md" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-zinc-900 dark:text-white truncate">
                        {m.name}
                      </span>
                      <span className="text-xs font-mono text-zinc-400 shrink-0">{m.id}</span>
                    </div>
                    <div className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
                      {m.whatsapp} · Fee {formatINR(m.membershipFee)} · Joined {formatDateShort(m.joiningDate)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <div className={`text-xs font-semibold ${statusColor}`}>{statusText}</div>
                    <div
                      className={`text-xs font-mono font-bold tabular-nums ${
                        feeStatus === 'Paid'
                          ? 'text-[#B45309] dark:text-[#F5B700]'
                          : feeStatus === 'Partially Paid'
                          ? 'text-amber-500'
                          : 'text-red-500'
                      }`}
                    >
                      {feeStatus === 'Paid'
                        ? 'Fee Paid'
                        : `${feeStatus} · ${formatINR(m.remainingAmount)}`}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-400" />
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
};
