import React, { useEffect, useState } from 'react';
import {
  Download,
  Upload,
  Sun,
  Moon,
  Plus,
  X,
  LogOut,
  Camera,
  Trash2,
  AlertTriangle,
  Cloud,
  CheckCircle2,
  RefreshCw,
  Shield,
  HelpCircle,
  KeyRound,
  Info,
  MessageCircle,
} from 'lucide-react';
import { sendPasswordResetEmail } from 'firebase/auth';
import type { CloudSyncMeta, GymDataPayload, GymSettings, Language } from '../types';
import { useT } from '../i18n/translations';
import { DEFAULT_REMINDER_TEMPLATES } from '../utils/gymHelpers';
import { auth, firebaseProjectId, uploadImageWithStorageFallback } from '../firebase';
import { Avatar } from './Avatar';
import { PWAInstallButton } from './PWAInstallButton';
import { CloudSyncBadge } from './CloudSyncBadge';

interface SettingsViewProps {
  data: GymDataPayload;
  settings: GymSettings;
  language: Language;
  cloudAccount: {
    uid: string;
    email: string;
    displayName: string;
  };
  syncMeta: CloudSyncMeta;
  onSaveSettings: (next: GymSettings) => Promise<void>;
  onRestoreBackup: (json: unknown) => Promise<void>;
  onResetAllData: () => Promise<void>;
  onTriggerBackupNow: () => Promise<{ lastBackupAt: string; offlineQueued: boolean }>;
  onSwitchRole: () => void;
  onCloudSignOut: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  data,
  settings,
  language,
  cloudAccount,
  syncMeta,
  onSaveSettings,
  onRestoreBackup,
  onResetAllData,
  onTriggerBackupNow,
  onSwitchRole,
  onCloudSignOut,
}) => {
  const t = useT(language);
  const [form, setForm] = useState<GymSettings>(settings);
  const [newMethod, setNewMethod] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [backupNotice, setBackupNotice] = useState<{ text: string; offline?: boolean } | null>(null);
  const [backingUp, setBackingUp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [showSetupGuide, setShowSetupGuide] = useState(false);

  const [resetEmailSent, setResetEmailSent] = useState('');
  const [sendingReset, setSendingReset] = useState(false);
  const [downloadingSource, setDownloadingSource] = useState(false);
  const [sourceDownloadMsg, setSourceDownloadMsg] = useState('');

  useEffect(() => {
    setForm({
      ...settings,
      reminderTemplates: settings.reminderTemplates || { ...DEFAULT_REMINDER_TEMPLATES },
    });
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStatusMsg('');
    try {
      await onSaveSettings(form);
      setStatusMsg('Settings saved permanently to Cloud Firestore');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordReset = async () => {
    if (!cloudAccount.email) return;
    setSendingReset(true);
    setResetEmailSent('');
    try {
      await sendPasswordResetEmail(auth, cloudAccount.email);
      setResetEmailSent(`Password reset link sent to ${cloudAccount.email}`);
    } catch (err) {
      setResetEmailSent(err instanceof Error ? err.message : 'Could not send reset email.');
    } finally {
      setSendingReset(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { url } = await uploadImageWithStorageFallback(
        cloudAccount.uid,
        'logos',
        'gym-logo',
        file,
        360
      );
      if (url) setForm({ ...form, gymLogo: url });
    } catch {
      setStatusMsg('Failed to process logo image');
    }
  };

  const handleBackupNow = async () => {
    setBackingUp(true);
    setBackupNotice(null);
    try {
      const result = await onTriggerBackupNow();
      if (result.offlineQueued) {
        setBackupNotice({
          offline: true,
          text: 'You are currently offline. Changes are saved locally and will automatically sync to Cloud Firestore when internet returns.',
        });
      } else {
        setBackupNotice({
          text: `Cloud backup successful! All gym data is safely backed up (${new Date(result.lastBackupAt).toLocaleString()}).`,
        });
      }
    } catch (err) {
      setBackupNotice({
        offline: true,
        text: err instanceof Error ? err.message : 'Cloud backup could not complete right now.',
      });
    } finally {
      setBackingUp(false);
    }
  };

  const handleExportBackup = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      app: settings.gymName || 'Golden Fitness Gym',
      ownerEmail: cloudAccount.email,
      data,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `golden-fitness-gym-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const handleDownloadSourceZip = async () => {
    setDownloadingSource(true);
    setSourceDownloadMsg('');
    try {
      const response = await fetch('/api/export-source', {
        method: 'GET',
        cache: 'no-store',
      });
      const contentType = response.headers.get('content-type') || '';
      if (!response.ok || !contentType.includes('zip')) {
        throw new Error('Source ZIP export requires the web server connection (or run npm run export:source locally).');
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = url;
      link.setAttribute('download', 'golden-fitness-gym-android-source.zip');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      setSourceDownloadMsg('Android APK Source ZIP download started (contains source code & Android project only — zero customer or payment data).');
    } catch (err) {
      setSourceDownloadMsg(
        err instanceof Error
          ? err.message
          : 'Could not download source ZIP from this device.'
      );
    } finally {
      setDownloadingSource(false);
    }
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        await onRestoreBackup(parsed);
        setStatusMsg('Backup restored and synced to Cloud Firestore');
      } catch {
        setStatusMsg('Invalid backup JSON file');
      }
    };
    reader.readAsText(file);
  };

  const formattedLastBackup = syncMeta.lastBackupAt
    ? new Date(syncMeta.lastBackupAt).toLocaleString()
    : 'Auto-sync active';

  return (
    <div className="space-y-5 max-w-3xl">
      {/* Cloud Account Profile & Sync Card */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-[#F5B700]/15 border border-[#F5B700]/40 flex items-center justify-center text-[#B45309] dark:text-[#F5B700] shrink-0">
              <Cloud className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white truncate">
                  {cloudAccount.displayName || settings.ownerName || 'Gym Owner'}
                </h3>
                <CloudSyncBadge status={syncMeta.status} />
              </div>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                {cloudAccount.email}
              </p>
              <p className="text-[11px] font-mono text-zinc-400 dark:text-zinc-500 mt-0.5 truncate">
                Private Cloud ID: {cloudAccount.uid}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleBackupNow}
              disabled={backingUp}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-50 text-black text-xs font-bold cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${backingUp ? 'animate-spin' : ''}`} />
              <span>{backingUp ? 'Syncing...' : 'Backup Now'}</span>
            </button>
            <button
              type="button"
              onClick={handlePasswordReset}
              disabled={sendingReset}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:border-[#F5B700] cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-[#F5B700]" />
              <span>{sendingReset ? 'Sending...' : 'Reset Password'}</span>
            </button>
            <button
              type="button"
              onClick={onCloudSignOut}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-red-500/40 text-xs font-semibold text-red-500 hover:bg-red-500/10 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out Cloud
            </button>
          </div>
        </div>

        {resetEmailSent && (
          <div className="rounded-xl bg-[#F5B700]/15 border border-[#F5B700]/40 px-3.5 py-2.5 text-xs font-semibold text-[#B45309] dark:text-[#F5B700]">
            {resetEmailSent}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800 text-xs">
          <div className="rounded-xl bg-zinc-50 dark:bg-[#18181D] px-3.5 py-2.5">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Cloud Sync Status</div>
            <div className="font-bold text-zinc-900 dark:text-white mt-0.5 capitalize">
              {syncMeta.status} {syncMeta.hasPendingWrites ? '(Pending upload)' : ''}
            </div>
          </div>
          <div className="rounded-xl bg-zinc-50 dark:bg-[#18181D] px-3.5 py-2.5">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Last Verified Backup</div>
            <div className="font-semibold text-zinc-900 dark:text-white mt-0.5 truncate">
              {formattedLastBackup}
            </div>
          </div>
          <div className="rounded-xl bg-zinc-50 dark:bg-[#18181D] px-3.5 py-2.5">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Privacy Isolation</div>
            <div className="font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5 flex items-center gap-1">
              <Shield className="w-3.5 h-3.5" /> Owner UID Locked
            </div>
          </div>
        </div>

        {backupNotice && (
          <div
            className={`flex items-start gap-2 rounded-xl px-3.5 py-3 text-xs font-semibold ${
              backupNotice.offline
                ? 'bg-amber-500/15 border border-amber-500/35 text-amber-600 dark:text-amber-300'
                : 'bg-emerald-500/15 border border-emerald-500/35 text-emerald-700 dark:text-emerald-400'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{backupNotice.text}</span>
          </div>
        )}
      </div>

      {/* App Quick Toggles + Install */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Avatar src={form.gymLogo} name={form.gymName} size="lg" />
          <div>
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              {form.gymName}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Android PWA · Firebase Cloud Console
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PWAInstallButton />
          <button
            type="button"
            onClick={onSwitchRole}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" /> {t('logout')} (Role)
          </button>
        </div>
      </div>

      {/* Main Gym Configuration Form */}
      <form
        onSubmit={handleSave}
        className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-5"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Gym Name
            </label>
            <input
              type="text"
              value={form.gymName}
              onChange={(e) => setForm({ ...form, gymName: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Gym Logo
            </label>
            <label className="w-full flex items-center justify-center gap-2 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-700 dark:text-zinc-200 cursor-pointer">
              <Camera className="w-4 h-4 text-[#F5B700]" /> Upload New Logo
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
            </label>
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Gym Address
            </label>
            <input
              type="text"
              value={form.gymAddress}
              onChange={(e) => setForm({ ...form, gymAddress: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Gym Contact Number
            </label>
            <input
              type="tel"
              value={form.contactNumber}
              onChange={(e) => setForm({ ...form, contactNumber: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Owner Name
            </label>
            <input
              type="text"
              value={form.ownerName}
              onChange={(e) => setForm({ ...form, ownerName: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5">
              Owner Personal Phone Number
            </label>
            <input
              type="tel"
              value={form.ownerMobile}
              onChange={(e) => setForm({ ...form, ownerMobile: e.target.value })}
              placeholder="e.g. 9876543210"
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
            />
          </div>
        </div>

        {/* Theme & Language */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-zinc-200 dark:border-zinc-800">
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-2">
              {t('theme')}
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  const next = { ...form, theme: 'dark' as const };
                  setForm(next);
                  void onSaveSettings(next);
                }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold cursor-pointer ${
                  form.theme === 'dark'
                    ? 'bg-[#F5B700] border-[#F5B700] text-black'
                    : 'border-zinc-300 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                <Moon className="w-4 h-4" /> {t('darkTheme')}
              </button>
              <button
                type="button"
                onClick={() => {
                  const next = { ...form, theme: 'light' as const };
                  setForm(next);
                  void onSaveSettings(next);
                }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-semibold cursor-pointer ${
                  form.theme === 'light'
                    ? 'bg-[#F5B700] border-[#F5B700] text-black'
                    : 'border-zinc-300 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                <Sun className="w-4 h-4" /> {t('lightTheme')}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 mb-2">
              {t('language')}
            </label>
            <div className="flex gap-2">
              {[
                { code: 'en' as const, label: 'English' },
                { code: 'hi' as const, label: 'हिन्दी (Hindi)' },
              ].map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => {
                    const next = { ...form, language: l.code };
                    setForm(next);
                    void onSaveSettings(next);
                  }}
                  className={`flex-1 py-2.5 rounded-xl border text-xs font-semibold cursor-pointer ${
                    form.language === l.code
                      ? 'bg-[#F5B700] border-[#F5B700] text-black'
                      : 'border-zinc-300 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 space-y-2.5">
          <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400">
            Payment Methods
          </label>
          <div className="flex flex-wrap gap-2">
            {form.paymentMethods.map((pm) => (
              <div
                key={pm}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-[#18181D] border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-800 dark:text-zinc-200"
              >
                <span>{pm}</span>
                {form.paymentMethods.length > 1 && (
                  <button
                    type="button"
                    onClick={() =>
                      setForm({
                        ...form,
                        paymentMethods: form.paymentMethods.filter((x) => x !== pm),
                      })
                    }
                    className="text-zinc-400 hover:text-red-500 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newMethod}
              onChange={(e) => setNewMethod(e.target.value)}
              placeholder="Add custom method (e.g. PhonePe, GPay)"
              className="flex-1 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
            />
            <button
              type="button"
              onClick={() => {
                const v = newMethod.trim();
                if (v && !form.paymentMethods.includes(v)) {
                  setForm({ ...form, paymentMethods: [...form.paymentMethods, v] });
                  setNewMethod('');
                }
              }}
              className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-800 text-white text-xs font-semibold cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Add
            </button>
          </div>
        </div>

        {/* Access PINs */}
        <div className="grid grid-cols-3 gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Owner PIN</label>
            <input
              type="text"
              value={form.ownerPin}
              onChange={(e) => setForm({ ...form, ownerPin: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Reception PIN</label>
            <input
              type="text"
              value={form.receptionPin}
              onChange={(e) => setForm({ ...form, receptionPin: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-zinc-500 mb-1">Trainer PIN</label>
            <input
              type="text"
              value={form.trainerPin}
              onChange={(e) => setForm({ ...form, trainerPin: e.target.value })}
              className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs font-mono text-zinc-900 dark:text-white"
            />
          </div>
        </div>

        {/* Attendance Rule & Customizable Reminder Message Templates */}
        <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between gap-3 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-200 dark:border-zinc-800 p-3.5">
            <div>
              <div className="text-xs font-bold text-zinc-900 dark:text-white">
                Prevent Same-Day Duplicate Attendance
              </div>
              <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                When ON, members can only record one gym visit per day (blocks a 2nd entry on the same date).
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                setForm({ ...form, preventDuplicateSameDay: !form.preventDuplicateSameDay })
              }
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer shrink-0 ${
                form.preventDuplicateSameDay
                  ? 'bg-[#F5B700] text-black'
                  : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300'
              }`}
            >
              {form.preventDuplicateSameDay ? 'Enabled (1/day)' : 'Off (Allow Re-entry)'}
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-zinc-900 dark:text-white flex items-center gap-1.5">
                <MessageCircle className="w-4 h-4 text-[#F5B700]" />
                Customizable WhatsApp Reminder Templates
              </label>
              <button
                type="button"
                onClick={() =>
                  setForm({ ...form, reminderTemplates: { ...DEFAULT_REMINDER_TEMPLATES } })
                }
                className="text-[11px] font-semibold text-[#B45309] dark:text-[#F5B700] hover:underline cursor-pointer"
              >
                Reset Defaults
              </button>
            </div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 font-mono">
              Variables: {'{name}'}, {'{gymName}'}, {'{memberId}'}, {'{fee}'}, {'{remaining}'}, {'{expiryDate}'}, {'{daysAbsent}'}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { key: 'feeReminder' as const, label: 'Fee Reminder' },
                { key: 'pendingPayment' as const, label: 'Pending Balance Reminder' },
                { key: 'renewalReminder' as const, label: 'Expiry / Renewal Reminder' },
                { key: 'inactiveReminder' as const, label: 'Absent Member Reminder' },
              ].map((item) => (
                <div key={item.key}>
                  <label className="block text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1">
                    {item.label}
                  </label>
                  <textarea
                    rows={3}
                    value={form.reminderTemplates?.[item.key] || ''}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        reminderTemplates: {
                          ...(form.reminderTemplates || DEFAULT_REMINDER_TEMPLATES),
                          [item.key]: e.target.value,
                        },
                      })
                    }
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2 text-xs text-zinc-900 dark:text-white"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {statusMsg && (
          <p className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700]">{statusMsg}</p>
        )}

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-3 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-sm cursor-pointer"
        >
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </form>

      {/* Portable JSON Export & Restore */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-3">
        <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
          {t('backupData')} (JSON Export / Restore)
        </h3>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          All members, payments, attendance, trainers, workouts, and diet charts sync automatically to Cloud Firestore. You can also download or restore a portable JSON snapshot anytime.
        </p>
        <div className="flex flex-wrap gap-3 pt-1">
          <button
            type="button"
            onClick={handleExportBackup}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#F5B700] text-black text-xs font-bold cursor-pointer"
          >
            <Download className="w-4 h-4" /> {t('exportBackup')}
          </button>
          <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 text-xs font-semibold text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer">
            <Upload className="w-4 h-4 text-[#F5B700]" /> {t('restoreBackup')}
            <input type="file" accept="application/json" onChange={handleRestoreFile} className="hidden" />
          </label>
          <button
            type="button"
            onClick={handleDownloadSourceZip}
            disabled={downloadingSource}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#F5B700]/45 bg-[#F5B700]/10 text-xs font-bold text-[#B45309] dark:text-[#F5B700] hover:bg-[#F5B700]/20 disabled:opacity-50 cursor-pointer"
          >
            <Download className={`w-4 h-4 ${downloadingSource ? 'animate-bounce' : ''}`} />
            <span>{downloadingSource ? 'Preparing Source ZIP...' : 'Download Android APK Source ZIP'}</span>
          </button>
        </div>
        {sourceDownloadMsg && (
          <p className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] pt-1">
            {sourceDownloadMsg}
          </p>
        )}
      </div>

      {/* Help & Support + Firebase Setup */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-[#F5B700]" />
            {t('helpSupport')}
          </h3>
          <button
            type="button"
            onClick={() => setShowSetupGuide((s) => !s)}
            className="text-xs font-semibold text-[#B45309] dark:text-[#F5B700] cursor-pointer"
          >
            {showSetupGuide ? 'Hide Technical Info' : 'Firebase Config Info'}
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-zinc-600 dark:text-zinc-400">
          <div className="rounded-xl bg-zinc-50 dark:bg-[#18181D] p-3">
            <strong className="text-zinc-900 dark:text-white block mb-1">QR Attendance Desk</strong>
            Print or download the Official Gym QR from Home/Attendance. Members scan with Phone Camera for timed Entry &amp; Exit.
          </div>
          <div className="rounded-xl bg-zinc-50 dark:bg-[#18181D] p-3">
            <strong className="text-zinc-900 dark:text-white block mb-1">Custom Fees &amp; Cloud Sync</strong>
            All records sync privately to your UID. Offline edits queue in IndexedDB and auto-upload when online.
          </div>
        </div>
        {showSetupGuide && (
          <div className="mt-2 rounded-xl border border-zinc-200 dark:border-zinc-800 p-3 text-xs text-zinc-500 dark:text-zinc-400 space-y-1 leading-relaxed">
            <p>
              Connected Firebase Project ID: <span className="font-mono text-zinc-800 dark:text-zinc-200">{firebaseProjectId}</span>
            </p>
            <p>
              Cloud Database &amp; Auth: Private tenant rules active per owner UID. Member/Trainer photos use Firebase Storage when enabled with automatic compressed fallback.
            </p>
          </div>
        )}
      </div>

      {/* About App with Developer Branding */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-[#D4AF37]/35 p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#F5B700]/15 border border-[#F5B700]/40 flex items-center justify-center text-[#B45309] dark:text-[#F5B700]">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              {settings.gymName || 'Golden Fitness Gym'}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Developed by <strong className="text-[#B45309] dark:text-[#F5B700]">Fitness Club House</strong> · Cloud Gym Management Suite
            </p>
          </div>
        </div>
        <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-[#18181D] text-zinc-700 dark:text-zinc-300">
          v2.0 Cloud
        </span>
      </div>

      {/* Reset All Data */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-red-500/30 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
          <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
            Reset All Data
          </h3>
        </div>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          Permanently clear all members, trainers, attendance logs, fee payments, membership history, workout plans, and diet plans from your cloud database. Your gym settings remain saved.
        </p>

        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 text-xs font-bold cursor-pointer transition-colors"
          >
            <Trash2 className="w-4 h-4" /> Reset All Data
          </button>
        ) : (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 space-y-3">
            <p className="text-xs font-semibold text-red-400">
              Warning: This action cannot be undone. Export a JSON backup first if you want to keep a copy. Are you sure you want to delete all cloud gym records?
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-4 py-2 rounded-xl bg-zinc-200 dark:bg-zinc-800 text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={resetting}
                onClick={async () => {
                  setResetting(true);
                  try {
                    await onResetAllData();
                    setConfirmReset(false);
                    setStatusMsg('All gym data cleared from Cloud Firestore.');
                  } finally {
                    setResetting(false);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-xs font-bold text-white cursor-pointer"
              >
                {resetting ? 'Clearing...' : 'Yes, Reset Everything'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
