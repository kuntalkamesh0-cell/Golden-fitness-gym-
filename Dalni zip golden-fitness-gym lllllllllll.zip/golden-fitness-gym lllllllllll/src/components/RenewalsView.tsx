import React, { useMemo, useState } from 'react';
import { MessageCircle, RefreshCw, X } from 'lucide-react';
import type { DurationUnit, GymSettings, Language, Member } from '../types';
import { useT } from '../i18n/translations';
import {
  buildWhatsAppTemplates,
  calculateExpiryDate,
  computeRemainingBalance,
  diffDaysBetween,
  formatDateShort,
  formatINR,
  getTodayISO,
  openWhatsAppMessage,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface RenewalsViewProps {
  members: Member[];
  settings: GymSettings;
  language: Language;
  onRenewMembership: (
    memberId: string,
    payload: {
      durationValue: number;
      durationUnit: DurationUnit;
      startDate: string;
      expiryDate: string;
      membershipFee: number;
      discount: number;
      amountPaid: number;
      paymentMethod: string;
      paymentDate: string;
      carryPreviousBalance: boolean;
      notes: string;
    }
  ) => Promise<void>;
}

export const RenewalsView: React.FC<RenewalsViewProps> = ({
  members,
  settings,
  language,
  onRenewMembership,
}) => {
  const t = useT(language);
  const today = getTodayISO();
  const [bucket, setBucket] = useState<'today' | 'tomorrow' | 'week' | 'expired'>('week');
  const [renewMember, setRenewMember] = useState<Member | null>(null);

  // Renewal modal form state (100% custom)
  const [durationValue, setDurationValue] = useState('1');
  const [durationUnit, setDurationUnit] = useState<DurationUnit>('months');
  const [startDate, setStartDate] = useState(today);
  const [expiryDate, setExpiryDate] = useState(calculateExpiryDate(today, 1, 'months'));
  const [manualExpiry, setManualExpiry] = useState(false);
  const [customFee, setCustomFee] = useState('');
  const [discount, setDiscount] = useState('0');
  const [amountPaid, setAmountPaid] = useState('');
  const [paymentMethod, setPaymentMethod] = useState(settings.paymentMethods[0] || 'Cash');
  const [carryPreviousBalance, setCarryPreviousBalance] = useState(true);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const buckets = useMemo(() => {
    const expToday: Member[] = [];
    const expTomorrow: Member[] = [];
    const expWeek: Member[] = [];
    const expired: Member[] = [];

    for (const m of members) {
      const diff = diffDaysBetween(today, m.expiryDate);
      if (diff === 0) expToday.push(m);
      if (diff === 1) expTomorrow.push(m);
      if (diff >= 0 && diff <= 7) expWeek.push(m);
      if (diff < 0) expired.push(m);
    }
    return { today: expToday, tomorrow: expTomorrow, week: expWeek, expired };
  }, [members, today]);

  const activeList = buckets[bucket];

  const openRenewModal = (m: Member) => {
    const baseStart = diffDaysBetween(today, m.expiryDate) >= 0 ? m.expiryDate : today;
    setRenewMember(m);
    setDurationValue(String(m.durationValue || 1));
    setDurationUnit(m.durationUnit || 'months');
    setStartDate(baseStart);
    setExpiryDate(calculateExpiryDate(baseStart, m.durationValue || 1, m.durationUnit || 'months'));
    setManualExpiry(false);
    setCustomFee(String(m.membershipFee || ''));
    setDiscount('0');
    setAmountPaid('');
    setCarryPreviousBalance(m.remainingAmount > 0);
    setNotes('');
  };

  const handleDurationChange = (val: string, unit: DurationUnit, start: string) => {
    setDurationValue(val);
    setDurationUnit(unit);
    setStartDate(start);
    if (!manualExpiry) {
      const num = Number(val) || 0;
      if (num > 0 && start) setExpiryDate(calculateExpiryDate(start, num, unit));
    }
  };

  const feeTotal =
    (Number(customFee) || 0) +
    (renewMember && carryPreviousBalance ? renewMember.remainingAmount : 0);
  const remainingAfter = computeRemainingBalance(
    feeTotal,
    Number(discount) || 0,
    Number(amountPaid) || 0
  );

  const submitRenewal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renewMember) return;
    setSaving(true);
    try {
      await onRenewMembership(renewMember.id, {
        durationValue: Number(durationValue) || 1,
        durationUnit,
        startDate,
        expiryDate,
        membershipFee: Number(customFee) || 0,
        discount: Number(discount) || 0,
        amountPaid: Number(amountPaid) || 0,
        paymentMethod,
        paymentDate: today,
        carryPreviousBalance,
        notes: notes.trim() || `Custom renewal (${durationValue} ${durationUnit})`,
      });
      setRenewMember(null);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-zinc-100 dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
        {[
          { id: 'today', label: `${t('expiringToday')} (${buckets.today.length})` },
          { id: 'tomorrow', label: `${t('expiringTomorrow')} (${buckets.tomorrow.length})` },
          { id: 'week', label: `${t('expiring7Days')} (${buckets.week.length})` },
          { id: 'expired', label: `${t('expiredList')} (${buckets.expired.length})` },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setBucket(item.id as typeof bucket)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              bucket === item.id
                ? 'bg-[#F5B700] text-black'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-100 dark:divide-zinc-800/80 overflow-hidden">
        {activeList.length === 0 ? (
          <div className="p-10 text-center text-sm text-zinc-500">
            No memberships in this renewal category.
          </div>
        ) : (
          activeList.map((m) => {
            const diff = diffDaysBetween(today, m.expiryDate);
            return (
              <div key={m.id} className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar src={m.photo} name={m.name} size="md" />
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                      {m.name} <span className="text-xs font-mono text-zinc-400">· {m.id}</span>
                    </div>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                      Expiry: {formatDateShort(m.expiryDate)} (
                      {diff < 0 ? `${Math.abs(diff)}d ago` : diff === 0 ? 'Today' : `in ${diff}d`}) · Last Fee{' '}
                      {formatINR(m.membershipFee)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      openWhatsAppMessage(
                        m.whatsapp,
                        buildWhatsAppTemplates(
                          settings.gymName,
                          m,
                          undefined,
                          settings.reminderTemplates
                        ).renewalReminder
                      )
                    }
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#F5B700]/15 text-[#B45309] dark:text-[#F5B700] cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => openRenewModal(m)}
                    className="min-h-[40px] px-4 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> {t('renewNow')}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Custom Renewal Modal */}
      {renewMember && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm sm:p-4">
          <div className="w-full max-w-lg rounded-t-3xl sm:rounded-3xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                  Renew {renewMember.name}
                </h3>
                <p className="text-xs text-zinc-500">
                  Enter any custom fee, duration & expiry date (history is preserved)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRenewMember(null)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-zinc-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={submitRenewal} className="p-5 space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Duration</label>
                  <input
                    type="number"
                    min={1}
                    value={durationValue}
                    onChange={(e) => {
                      setManualExpiry(false);
                      handleDurationChange(e.target.value, durationUnit, startDate);
                    }}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Unit</label>
                  <select
                    value={durationUnit}
                    onChange={(e) => {
                      setManualExpiry(false);
                      handleDurationChange(durationValue, e.target.value as DurationUnit, startDate);
                    }}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-2.5 py-2.5 text-sm text-zinc-900 dark:text-white"
                  >
                    <option value="days">Days</option>
                    <option value="months">Months</option>
                    <option value="years">Years</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => {
                      setManualExpiry(false);
                      handleDurationChange(durationValue, durationUnit, e.target.value);
                    }}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-2.5 py-2.5 text-xs font-mono text-zinc-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={expiryDate}
                    onChange={(e) => {
                      setManualExpiry(true);
                      setExpiryDate(e.target.value);
                    }}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-[#F5B700]/60 px-2.5 py-2.5 text-xs font-mono text-zinc-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Custom Fee (₹)*</label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={customFee}
                    onChange={(e) => setCustomFee(e.target.value)}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono font-bold text-zinc-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Discount (₹)</label>
                  <input
                    type="number"
                    min={0}
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Amount Paid (₹)</label>
                  <input
                    type="number"
                    min={0}
                    value={amountPaid}
                    onChange={(e) => setAmountPaid(e.target.value)}
                    placeholder="0"
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono font-bold text-[#B45309] dark:text-[#F5B700]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-500 mb-1">Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-2.5 py-2.5 text-sm text-zinc-900 dark:text-white"
                  >
                    {settings.paymentMethods.map((pm) => (
                      <option key={pm} value={pm}>
                        {pm}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {renewMember.remainingAmount > 0 && (
                <label className="flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={carryPreviousBalance}
                    onChange={(e) => setCarryPreviousBalance(e.target.checked)}
                    className="accent-[#F5B700] w-4 h-4"
                  />
                  Include previous unpaid balance ({formatINR(renewMember.remainingAmount)})
                </label>
              )}

              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional renewal note"
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white"
              />

              <div className="p-3 rounded-xl bg-zinc-100 dark:bg-[#18181D] flex items-center justify-between text-xs font-mono tabular-nums">
                <span>Total: {formatINR(feeTotal)}</span>
                <span className="font-bold text-amber-500">Remaining: {formatINR(remainingAfter)}</span>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-3.5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black font-bold text-sm cursor-pointer"
              >
                {saving ? 'Renewing...' : 'Confirm Custom Renewal'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
