import React, { useEffect, useMemo, useState } from 'react';
import { IndianRupee, MessageCircle, Printer, Receipt } from 'lucide-react';
import type { GymSettings, Language, Member, PaymentRecord } from '../types';
import { useT } from '../i18n/translations';
import {
  buildWhatsAppTemplates,
  computeRemainingBalance,
  formatDateShort,
  formatINR,
  getFeeStatus,
  getTodayISO,
  openWhatsAppMessage,
} from '../utils/gymHelpers';
import { Avatar } from './Avatar';

interface FeesViewProps {
  members: Member[];
  payments: PaymentRecord[];
  settings: GymSettings;
  language: Language;
  preselectedMember?: Member | null;
  onCollectPayment: (payload: {
    memberId: string;
    amount: number;
    discount: number;
    paymentMethod: string;
    paymentDate: string;
    notes: string;
    newMembershipFee?: number;
  }) => Promise<{ receiptNumber: string }>;
}

export const FeesView: React.FC<FeesViewProps> = ({
  members,
  payments,
  settings,
  language,
  preselectedMember,
  onCollectPayment,
}) => {
  const t = useT(language);
  const today = getTodayISO();

  const [selectedMemberId, setSelectedMemberId] = useState(
    preselectedMember?.id || members[0]?.id || ''
  );
  const [customTotalFee, setCustomTotalFee] = useState('');
  const [amount, setAmount] = useState('');
  const [extraDiscount, setExtraDiscount] = useState('0');
  const [paymentMethod, setPaymentMethod] = useState(settings.paymentMethods[0] || 'Cash');
  const [paymentDate, setPaymentDate] = useState(today);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<{
    receiptNumber: string;
    member: Member;
    amount: number;
    date: string;
    method: string;
  } | null>(null);
  const [printingReceipt, setPrintingReceipt] = useState<{
    receiptNumber: string;
    memberName: string;
    memberId: string;
    amount: number;
    remainingAmount: number;
    date: string;
    method: string;
    expiryDate: string;
    notes: string;
  } | null>(null);

  const triggerPrintReceipt = (receipt: NonNullable<typeof printingReceipt>) => {
    setPrintingReceipt(receipt);
    setTimeout(() => {
      document.body.classList.add('printing-fee-receipt');
      const cleanup = () => {
        document.body.classList.remove('printing-fee-receipt');
        window.removeEventListener('afterprint', cleanup);
      };
      window.addEventListener('afterprint', cleanup);
      window.print();
      setTimeout(cleanup, 1500);
    }, 60);
  };

  useEffect(() => {
    if (preselectedMember) {
      setSelectedMemberId(preselectedMember.id);
      setCustomTotalFee(String(preselectedMember.membershipFee));
      setAmount(preselectedMember.remainingAmount > 0 ? String(preselectedMember.remainingAmount) : '');
    }
  }, [preselectedMember]);

  const selectedMember = useMemo(
    () => members.find((m) => m.id === selectedMemberId) || members[0],
    [members, selectedMemberId]
  );

  useEffect(() => {
    if (selectedMember && !preselectedMember) {
      setCustomTotalFee(String(selectedMember.membershipFee));
      setAmount(selectedMember.remainingAmount > 0 ? String(selectedMember.remainingAmount) : '');
    }
  }, [selectedMember?.id]);

  const pendingMembers = useMemo(
    () => members.filter((m) => m.remainingAmount > 0),
    [members]
  );

  const memberMap = useMemo(() => new Map(members.map((m) => [m.id, m])), [members]);

  const effectiveTotalFee =
    customTotalFee !== '' ? Number(customTotalFee) || 0 : selectedMember?.membershipFee || 0;
  const totalDiscount = (selectedMember?.discount || 0) + (Number(extraDiscount) || 0);
  const totalPaidAfter = (selectedMember?.amountPaid || 0) + (Number(amount) || 0);
  const projectedRemaining = computeRemainingBalance(
    effectiveTotalFee,
    totalDiscount,
    totalPaidAfter
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;
    setSaving(true);
    try {
      const payAmt = Number(amount) || 0;
      const res = await onCollectPayment({
        memberId: selectedMember.id,
        amount: payAmt,
        discount: Number(extraDiscount) || 0,
        paymentMethod,
        paymentDate,
        notes: notes.trim() || 'Custom fee payment',
        newMembershipFee:
          customTotalFee !== '' && Number(customTotalFee) !== selectedMember.membershipFee
            ? Number(customTotalFee)
            : undefined,
      });
      setLastReceipt({
        receiptNumber: res.receiptNumber,
        member: {
          ...selectedMember,
          membershipFee: effectiveTotalFee,
          discount: totalDiscount,
          amountPaid: totalPaidAfter,
          remainingAmount: projectedRemaining,
        },
        amount: payAmt,
        date: paymentDate,
        method: paymentMethod,
      });
      setAmount('');
      setExtraDiscount('0');
      setNotes('');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Collect Payment / Custom Fee Form */}
        <div className="lg:col-span-6 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white flex items-center gap-2">
              <IndianRupee className="w-4 h-4 text-[#F5B700]" />
              {t('collectFee')} (Any Custom Amount)
            </h3>
            {selectedMember && (
              <span
                className={`text-xs font-mono font-bold tabular-nums ${
                  getFeeStatus(selectedMember) === 'Paid'
                    ? 'text-emerald-500'
                    : getFeeStatus(selectedMember) === 'Partially Paid'
                    ? 'text-amber-500'
                    : 'text-red-500'
                }`}
              >
                {getFeeStatus(selectedMember)} · Due: {formatINR(selectedMember.remainingAmount)}
              </span>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1.5">
                Select Member
              </label>
              <select
                value={selectedMember?.id || ''}
                onChange={(e) => {
                  const next = members.find((m) => m.id === e.target.value);
                  setSelectedMemberId(e.target.value);
                  if (next) {
                    setCustomTotalFee(String(next.membershipFee));
                    setAmount(next.remainingAmount > 0 ? String(next.remainingAmount) : '');
                  }
                }}
                className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3.5 py-3 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
              >
                {members.length === 0 ? (
                  <option value="">No members registered yet</option>
                ) : (
                  members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.id} — {m.name} (Fee: {formatINR(m.membershipFee)} | Due: {formatINR(m.remainingAmount)})
                    </option>
                  ))
                )}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Custom Total Fee (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  value={customTotalFee}
                  onChange={(e) => setCustomTotalFee(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Extra Discount (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  value={extraDiscount}
                  onChange={(e) => setExtraDiscount(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Amount Paying Now (₹) *
                </label>
                <input
                  type="number"
                  min={0}
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter any amount"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-[#F5B700]/60 px-3 py-2.5 text-sm font-mono font-bold text-[#B45309] dark:text-[#F5B700] focus:outline-none focus:border-[#F5B700]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('paymentMethod')}
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-[#F5B700]"
                >
                  {settings.paymentMethods.map((pm) => (
                    <option key={pm} value={pm}>
                      {pm}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  Payment Date
                </label>
                <input
                  type="date"
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm font-mono text-zinc-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('notes')}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Installment / Balance"
                  className="w-full rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 px-3 py-2.5 text-sm text-zinc-900 dark:text-white"
                />
              </div>
            </div>

            {/* Live Calculation Summary */}
            <div className="p-3.5 rounded-xl bg-zinc-50 dark:bg-[#18181D] border border-zinc-200 dark:border-zinc-800 flex items-center justify-between text-xs font-mono tabular-nums">
              <span className="text-zinc-500">
                Net Fee {formatINR(effectiveTotalFee - totalDiscount)} − Paid {formatINR(totalPaidAfter)}
              </span>
              <span className="font-bold text-zinc-900 dark:text-white">
                Balance: {formatINR(projectedRemaining)}
              </span>
            </div>

            <button
              type="submit"
              disabled={saving || !selectedMember}
              className="w-full py-3.5 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-40 disabled:cursor-not-allowed text-black font-bold text-sm transition-colors cursor-pointer"
            >
              {saving ? 'Recording...' : !selectedMember ? 'Register a Member First' : 'Record Payment & Generate Receipt'}
            </button>
          </form>

          {lastReceipt && (
            <div className="p-4 rounded-xl bg-[#F5B700]/10 border border-[#F5B700]/40 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#B45309] dark:text-[#F5B700] flex items-center gap-1.5">
                  <Receipt className="w-4 h-4" /> Receipt {lastReceipt.receiptNumber}
                </div>
                <div className="text-xs text-zinc-700 dark:text-zinc-300 mt-0.5 tabular-nums">
                  {lastReceipt.member.name} · Paid {formatINR(lastReceipt.amount)}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    triggerPrintReceipt({
                      receiptNumber: lastReceipt.receiptNumber,
                      memberName: lastReceipt.member.name,
                      memberId: lastReceipt.member.id,
                      amount: lastReceipt.amount,
                      remainingAmount: lastReceipt.member.remainingAmount,
                      date: lastReceipt.date,
                      method: lastReceipt.method,
                      expiryDate: lastReceipt.member.expiryDate,
                      notes: 'Fee payment receipt',
                    })
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#F5B700]/40 text-xs font-bold text-zinc-900 dark:text-white cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-[#F5B700]" /> Print PDF
                </button>
                <button
                  type="button"
                  onClick={() =>
                    openWhatsAppMessage(
                      lastReceipt.member.whatsapp,
                      buildWhatsAppTemplates(
                        settings.gymName,
                        lastReceipt.member,
                        {
                          amountPaid: lastReceipt.amount,
                          receiptNumber: lastReceipt.receiptNumber,
                          paymentDate: lastReceipt.date,
                        },
                        settings.reminderTemplates
                      ).paymentReceipt
                    )
                  }
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F5B700] text-black text-xs font-bold cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Pending Balances Queue */}
        <div className="lg:col-span-6 rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
              Pending Balances ({pendingMembers.length})
            </h3>
            <span className="text-xs font-mono font-bold text-amber-500 tabular-nums">
              Total Due: {formatINR(pendingMembers.reduce((s, m) => s + m.remainingAmount, 0))}
            </span>
          </div>
          <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80 flex-1 overflow-y-auto max-h-[420px]">
            {pendingMembers.length === 0 ? (
              <div className="p-10 text-center text-sm text-zinc-500">
                Zero pending fee balances.
              </div>
            ) : (
              pendingMembers.map((m) => (
                <div key={m.id} className="p-4 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar src={m.photo} name={m.name} size="sm" />
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                        {m.name}{' '}
                        <span className="text-[11px] font-mono text-amber-500">
                          · {getFeeStatus(m)}
                        </span>
                      </div>
                      <div className="text-xs font-mono text-zinc-500 tabular-nums">
                        Fee {formatINR(m.membershipFee)} · Paid {formatINR(m.amountPaid)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-mono font-bold text-amber-500 tabular-nums">
                      {formatINR(m.remainingAmount)}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedMemberId(m.id);
                        setCustomTotalFee(String(m.membershipFee));
                        setAmount(String(m.remainingAmount));
                      }}
                      className="px-3 py-1.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 hover:bg-[#F5B700] hover:text-black text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer"
                    >
                      Collect
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        openWhatsAppMessage(
                          m.whatsapp,
                          buildWhatsAppTemplates(
                            settings.gymName,
                            m,
                            undefined,
                            settings.reminderTemplates
                          ).pendingPayment
                        )
                      }
                      className="p-2 rounded-xl bg-[#F5B700]/15 text-[#B45309] dark:text-[#F5B700] cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Full Fee & Receipt Ledger */}
      <div className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800">
          <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
            Fee History & Receipts ({payments.length})
          </h3>
        </div>
        <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80 max-h-[380px] overflow-y-auto">
          {payments.length === 0 ? (
            <div className="p-10 text-center text-sm text-zinc-500">
              No fee payments or receipts recorded yet.
            </div>
          ) : (
            payments.map((p) => {
              const m = memberMap.get(p.memberId);
              return (
                <div key={p.id} className="px-4 py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-zinc-900 dark:text-white truncate">
                      {p.memberName || m?.name || p.memberId}{' '}
                      <span className="text-xs font-mono text-zinc-500">· {p.receiptNumber}</span>
                    </div>
                    <div className="text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
                      {formatDateShort(p.paymentDate)} · {p.paymentMethod} · {p.notes || p.type}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-sm font-mono font-bold text-[#B45309] dark:text-[#F5B700] tabular-nums">
                      +{formatINR(p.amount)}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        triggerPrintReceipt({
                          receiptNumber: p.receiptNumber,
                          memberName: p.memberName || m?.name || p.memberId,
                          memberId: p.memberId,
                          amount: p.amount,
                          remainingAmount: m?.remainingAmount ?? 0,
                          date: p.paymentDate,
                          method: p.paymentMethod,
                          expiryDate: m?.expiryDate || p.paymentDate,
                          notes: p.notes || p.type,
                        })
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:border-[#F5B700] cursor-pointer"
                    >
                      <Printer className="w-3 h-3" /> PDF
                    </button>
                    {m && (
                      <button
                        type="button"
                        onClick={() =>
                          openWhatsAppMessage(
                            m.whatsapp,
                            buildWhatsAppTemplates(
                              settings.gymName,
                              m,
                              {
                                amountPaid: p.amount,
                                receiptNumber: p.receiptNumber,
                                paymentDate: p.paymentDate,
                              },
                              settings.reminderTemplates
                            ).paymentReceipt
                          )
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:text-[#F5B700] cursor-pointer"
                      >
                        Send
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Printable Payment Receipt */}
      {printingReceipt && (
        <div id="printable-fee-receipt" className="hidden bg-white text-black p-8" aria-hidden="true">
          <div className="max-w-lg mx-auto border-2 border-zinc-800 rounded-2xl p-6 space-y-4">
            <div className="border-b border-zinc-300 pb-3 flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl font-bold">{settings.gymName}</h2>
                <p className="text-xs text-zinc-600">{settings.gymAddress || settings.contactNumber}</p>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold uppercase text-zinc-500">Payment Receipt</div>
                <div className="text-sm font-mono font-bold">{printingReceipt.receiptNumber}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-zinc-500 text-xs block">Member</span><strong>{printingReceipt.memberName} ({printingReceipt.memberId})</strong></div>
              <div><span className="text-zinc-500 text-xs block">Date</span><strong>{formatDateShort(printingReceipt.date)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Amount Paid</span><strong className="font-mono">{formatINR(printingReceipt.amount)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Method</span><strong>{printingReceipt.method}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Remaining Balance</span><strong className="font-mono">{formatINR(printingReceipt.remainingAmount)}</strong></div>
              <div><span className="text-zinc-500 text-xs block">Valid Until</span><strong>{formatDateShort(printingReceipt.expiryDate)}</strong></div>
            </div>
            {printingReceipt.notes && (
              <div className="text-xs text-zinc-600 border-t border-zinc-200 pt-2">
                Notes: {printingReceipt.notes}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
