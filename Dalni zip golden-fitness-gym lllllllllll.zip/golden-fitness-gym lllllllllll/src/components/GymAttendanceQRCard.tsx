import React, { useRef, useState } from 'react';
import { CheckCircle2, Download, Printer, QrCode } from 'lucide-react';
import { QRCodeCanvas, QRCodeSVG } from 'qrcode.react';
import { buildGymQrPayload } from '../utils/gymHelpers';

interface GymAttendanceQRCardProps {
  gymName: string;
  gymAddress?: string;
  gymQrSecret: string;
  canGenerate?: boolean;
  onGenerateQr: () => Promise<void>;
  cardRef?: React.RefObject<HTMLDivElement | null>;
}

export const GymAttendanceQRCard: React.FC<GymAttendanceQRCardProps> = ({
  gymName,
  gymAddress,
  gymQrSecret,
  canGenerate = true,
  onGenerateQr,
  cardRef,
}) => {
  const [generating, setGenerating] = useState(false);
  const [justGenerated, setJustGenerated] = useState(false);
  const [qrExpanded, setQrExpanded] = useState(false);
  const canvasWrapRef = useRef<HTMLDivElement | null>(null);

  const gymQrPayload = buildGymQrPayload(gymQrSecret || 'GOLDEN-FITNESS-GYM');

  const handleGenerate = async () => {
    setGenerating(true);
    setJustGenerated(false);
    try {
      await onGenerateQr();
      setJustGenerated(true);
      setTimeout(() => setJustGenerated(false), 3000);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadQr = () => {
    const sourceCanvas = canvasWrapRef.current?.querySelector('canvas');
    if (!sourceCanvas) return;

    const width = 920;
    const height = 1140;
    const poster = document.createElement('canvas');
    poster.width = width;
    poster.height = height;
    const ctx = poster.getContext('2d');
    if (!ctx) return;

    // White printable background with gold border frame
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 10;
    ctx.strokeRect(24, 24, width - 48, height - 48);

    // Header banner
    ctx.fillStyle = '#09090B';
    ctx.fillRect(24, 24, width - 48, 150);

    ctx.fillStyle = '#F5B700';
    ctx.font = 'bold 40px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText((gymName || 'GOLDEN FITNESS GYM').toUpperCase(), width / 2, 92);

    ctx.fillStyle = '#E4E4E7';
    ctx.font = 'bold 22px sans-serif';
    ctx.fillText('OFFICIAL GYM ATTENDANCE QR CODE', width / 2, 136);

    // Draw high-res scannable QR code centered with generous white quiet zone
    const qrSize = 620;
    const qrX = (width - qrSize) / 2;
    const qrY = 225;
    ctx.drawImage(sourceCanvas, qrX, qrY, qrSize, qrSize);

    // Entry & Exit instructions footer
    ctx.fillStyle = '#09090B';
    ctx.font = 'bold 30px sans-serif';
    ctx.fillText('SCAN FOR ENTRY & EXIT', width / 2, 915);

    ctx.fillStyle = '#52525B';
    ctx.font = '21px sans-serif';
    ctx.fillText('Open Golden Fitness Gym Member QR Scanner on your phone', width / 2, 960);

    ctx.fillStyle = '#B45309';
    ctx.font = 'bold 18px monospace';
    ctx.fillText(gymQrPayload, width / 2, 1020);

    if (gymAddress) {
      ctx.fillStyle = '#71717A';
      ctx.font = '18px sans-serif';
      ctx.fillText(gymAddress.slice(0, 64), width / 2, 1068);
    }

    const dataUrl = poster.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `golden-fitness-gym-attendance-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintQr = () => {
    document.body.classList.add('printing-gym-qr');
    const cleanup = () => {
      document.body.classList.remove('printing-gym-qr');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 1500);
  };

  return (
    <>
      <div
        ref={cardRef}
        className="rounded-2xl bg-white dark:bg-[#121216] border border-zinc-200 dark:border-[#D4AF37]/40 p-5 flex flex-col items-center justify-between text-center gap-4"
      >
        <div className="w-full flex flex-wrap items-center justify-between gap-2">
          <div className="text-left">
            <div className="flex items-center gap-2">
              <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white">
                Gym Attendance QR Code
              </h3>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
                <CheckCircle2 className="w-3 h-3" /> Active
              </span>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Members scan this with the app QR Scanner for Entry &amp; Exit
            </p>
          </div>

          {canGenerate && (
            <button
              type="button"
              disabled={generating}
              onClick={handleGenerate}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] disabled:opacity-50 text-black text-xs font-bold cursor-pointer transition-colors whitespace-nowrap"
            >
              <QrCode className="w-3.5 h-3.5" />
              {generating ? 'Generating...' : 'Generate Gym QR Code'}
            </button>
          )}
        </div>

        {/* Live Scannable QR Code */}
        <button
          type="button"
          onClick={() => setQrExpanded(!qrExpanded)}
          title="Tap to resize QR code"
          className="p-4 rounded-2xl bg-white border-2 border-[#D4AF37]/70 shadow-sm cursor-pointer transition-transform active:scale-[0.98]"
        >
          <QRCodeSVG
            value={gymQrPayload}
            size={qrExpanded ? 228 : 172}
            level="M"
            marginSize={2}
            bgColor="#FFFFFF"
            fgColor="#000000"
          />
        </button>

        {/* Hidden high-res QRCodeCanvas used for crisp PNG downloads */}
        <div ref={canvasWrapRef} className="hidden" aria-hidden="true">
          <QRCodeCanvas
            value={gymQrPayload}
            size={620}
            level="M"
            marginSize={4}
            bgColor="#FFFFFF"
            fgColor="#000000"
          />
        </div>

        <div className="w-full space-y-2">
          {justGenerated && (
            <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              New valid Gym Attendance QR Code generated and activated.
            </div>
          )}
          <div className="text-[11px] font-mono font-bold text-[#B45309] dark:text-[#F5B700] break-all">
            {gymQrPayload}
          </div>
          <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
            Tap QR to {qrExpanded ? 'shrink' : 'enlarge'} · Entry &amp; Exit recorded automatically
          </p>
        </div>

        {/* Download & Print Controls */}
        <div className="w-full grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            onClick={handleDownloadQr}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-zinc-100 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 hover:border-[#F5B700] text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
            Download QR
          </button>
          <button
            type="button"
            onClick={handlePrintQr}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-zinc-100 dark:bg-[#18181D] border border-zinc-300 dark:border-zinc-700 hover:border-[#F5B700] text-xs font-semibold text-zinc-900 dark:text-white cursor-pointer transition-colors"
          >
            <Printer className="w-4 h-4 text-[#B45309] dark:text-[#F5B700]" />
            Print QR
          </button>
        </div>
      </div>

      {/* Dedicated Clean Printable Poster (visible only during window.print()) */}
      <div
        id="printable-gym-qr-poster"
        className="hidden bg-white text-black p-8 text-center"
        aria-hidden="true"
      >
        <div className="border-4 border-[#D4AF37] rounded-3xl p-10 max-w-lg mx-auto bg-white flex flex-col items-center gap-5">
          <div className="bg-[#09090B] text-[#F5B700] px-6 py-3 rounded-xl font-display font-bold text-2xl tracking-wide uppercase">
            {gymName || 'Golden Fitness Gym'}
          </div>
          <div className="text-sm font-bold tracking-widest uppercase text-zinc-600">
            Official Gym Attendance QR Code
          </div>
          <div className="p-5 bg-white border-2 border-zinc-200 rounded-2xl">
            <QRCodeSVG
              value={gymQrPayload}
              size={300}
              level="M"
              marginSize={4}
              bgColor="#FFFFFF"
              fgColor="#000000"
            />
          </div>
          <div className="space-y-1">
            <div className="text-lg font-bold text-zinc-900">SCAN FOR ENTRY &amp; EXIT</div>
            <p className="text-xs text-zinc-600">
              Open the Golden Fitness Gym app on your phone and tap QR SCANNER.
            </p>
          </div>
          <div className="text-xs font-mono font-bold text-zinc-700 break-all">{gymQrPayload}</div>
          {gymAddress && <div className="text-xs text-zinc-500">{gymAddress}</div>}
        </div>
      </div>
    </>
  );
};
