import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  doc,
  getDocFromServer,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { getDownloadURL, getStorage, ref, uploadBytes } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';
import { compressImageDataUrl } from './utils/gymHelpers';

export const firebaseProjectId = firebaseConfig.projectId;
export const firestoreDatabaseId = firebaseConfig.firestoreDatabaseId;

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Enable IndexedDB offline persistence + multi-tab synchronization on the provisioned Firestore database
export const db = initializeFirestore(
  app,
  {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  },
  firebaseConfig.firestoreDatabaseId
);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: Array<{
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }>;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  const serialized = JSON.stringify(errInfo);
  console.error('Firestore Error: ', serialized);
  throw new Error(serialized);
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration. Firestore client is offline.');
    }
    // Expected PERMISSION_DENIED on /test/connection when rules reject non-owner reads
  }
}

void testConnection();

function dataUrlToBlob(dataUrl: string): Blob {
  const [header, b64] = dataUrl.split(',');
  const mime = /data:(.*?);base64/.exec(header || '')?.[1] || 'image/jpeg';
  const bin = atob(b64 || '');
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) {
    bytes[i] = bin.charCodeAt(i);
  }
  return new Blob([bytes], { type: mime });
}

/**
 * Compresses image and attempts Firebase Storage upload; if offline or Storage rules
 * are not yet enabled in Firebase Console, seamlessly returns the compressed data URL
 * so member/trainer photos and gym logos always persist cleanly in Firestore.
 */
export async function uploadImageWithStorageFallback(
  ownerUid: string | undefined,
  folder: 'members' | 'trainers' | 'logos',
  itemId: string,
  file: File,
  maxDimension = 420
): Promise<{ url: string; usedStorage: boolean }> {
  const compressedDataUrl = await compressImageDataUrl(file, maxDimension, 0.72);
  if (!compressedDataUrl || !ownerUid || (typeof navigator !== 'undefined' && !navigator.onLine)) {
    return { url: compressedDataUrl, usedStorage: false };
  }

  try {
    const blob = dataUrlToBlob(compressedDataUrl);
    const safeId = itemId.replace(/[^a-zA-Z0-9_-]/g, '-');
    const storageRef = ref(storage, `owners/${ownerUid}/${folder}/${safeId}-${Date.now()}.jpg`);
    const downloadUrl = await Promise.race([
      uploadBytes(storageRef, blob, { contentType: 'image/jpeg' }).then((snap) =>
        getDownloadURL(snap.ref)
      ),
      new Promise<string>((_, reject) =>
        setTimeout(() => reject(new Error('Storage upload timeout')), 3500)
      ),
    ]);
    return { url: downloadUrl, usedStorage: true };
  } catch {
    return { url: compressedDataUrl, usedStorage: false };
  }
}
