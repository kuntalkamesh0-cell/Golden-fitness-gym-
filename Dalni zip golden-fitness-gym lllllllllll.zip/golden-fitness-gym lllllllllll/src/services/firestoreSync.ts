import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  waitForPendingWrites,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type {
  AttendanceMethod,
  AttendanceRecord,
  AttendanceShift,
  CloudSyncMeta,
  CloudSyncStatus,
  DietPlan,
  DurationUnit,
  GymDataPayload,
  GymSettings,
  Member,
  MembershipHistoryRecord,
  MuscleGroup,
  PaymentRecord,
  Trainer,
  WorkoutPlanItem,
} from '../types';
import {
  computeRemainingBalance,
  DEFAULT_REMINDER_TEMPLATES,
  getCurrentTimeHHMMSS,
  getShiftForTime,
  getTodayISO,
  sanitizeFirestoreId,
} from '../utils/gymHelpers';

const DEFAULT_GYM_LOGO = '/src/assets/images/gym_club_logo_1795080326591.jpg';
const VALID_MUSCLE_GROUPS: MuscleGroup[] = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Cardio'];

function randomHex(bytes = 8): string {
  const arr = new Uint8Array(bytes);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(arr);
  } else {
    for (let i = 0; i < bytes; i += 1) arr[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}

export function generateGymQrSecret(): string {
  return `GFG-SEC-${randomHex(8)}`;
}

function makeDocId(prefix: string): string {
  return sanitizeFirestoreId(
    `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
    prefix
  );
}

function clamp(val: unknown, maxLen: number, fallback = ''): string {
  const s = typeof val === 'string' ? val : val == null ? fallback : String(val);
  return s.length <= maxLen ? s : s.slice(0, maxLen);
}

function clampPhoto(val: unknown, fallback = ''): string {
  const s = typeof val === 'string' ? val : fallback;
  return s.length <= 350000 ? s : fallback;
}

function nonNeg(val: unknown, fallback = 0): number {
  const n = Number(val);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function sanitizePaymentMethods(methods: unknown): string[] {
  if (!Array.isArray(methods)) return ['Cash', 'UPI', 'Card'];
  const cleaned = methods
    .map((m) => clamp(m, 40).trim())
    .filter((m) => m.length > 0)
    .slice(0, 20);
  return cleaned.length > 0 ? cleaned : ['Cash', 'UPI'];
}

export function buildDefaultSettings(user?: User | null): GymSettings {
  return {
    gymName: 'Golden Fitness Gym',
    gymLogo: DEFAULT_GYM_LOGO,
    gymAddress: '',
    contactNumber: '',
    ownerName: clamp(user?.displayName || 'Admin', 120),
    ownerMobile: '',
    paymentMethods: ['Cash', 'UPI', 'Card'],
    theme: 'dark',
    language: 'en',
    ownerPin: '1234',
    receptionPin: '2222',
    trainerPin: '3333',
    gymQrSecret: generateGymQrSecret(),
    preventDuplicateSameDay: false,
    reminderTemplates: { ...DEFAULT_REMINDER_TEMPLATES },
  };
}

function extractGymQrSecret(rawQr: string): string {
  const trimmed = (rawQr || '').trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('GFG-CHECKIN:')) {
    return trimmed.slice('GFG-CHECKIN:'.length).trim();
  }
  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed) as { token?: string };
      if (parsed.token) return String(parsed.token).trim();
    } catch {
      // ignore invalid JSON
    }
  }
  return trimmed;
}

/**
 * Executes a Firestore write while ensuring offline IndexedDB writes resolve immediately
 * instead of blocking UI interaction until network reconnects.
 */
async function commitWrite<T>(
  writePromise: Promise<T>,
  operationType: OperationType,
  path: string
): Promise<void> {
  const tracked = writePromise.catch((err) => {
    const code = (err as { code?: string })?.code;
    if (code === 'unavailable' || !navigator.onLine) {
      return;
    }
    handleFirestoreError(err, operationType, path);
  });

  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    // persistentLocalCache already persisted locally; return immediately
    return;
  }

  await Promise.race([
    tracked,
    new Promise<void>((resolve) => {
      setTimeout(resolve, 3000);
    }),
  ]);
}

function toFirestoreMember(
  ownerUid: string,
  member: Member,
  includeCreatedTimestamp: boolean
): Record<string, unknown> {
  const id = sanitizeFirestoreId(member.id, 'GFG');
  const fee = nonNeg(member.membershipFee);
  const discount = nonNeg(member.discount);
  const paid = nonNeg(member.amountPaid);
  const remaining = computeRemainingBalance(fee, discount, paid);
  const docData: Record<string, unknown> = {
    ownerUid,
    id,
    name: clamp(member.name || 'Unnamed Member', 140) || 'Unnamed Member',
    whatsapp: clamp(member.whatsapp, 40),
    age: Math.min(130, Math.max(0, Math.round(nonNeg(member.age, 24)))),
    gender: member.gender === 'Female' || member.gender === 'Other' ? member.gender : 'Male',
    address: clamp(member.address, 300),
    joiningDate: clamp(member.joiningDate || getTodayISO(), 32) || getTodayISO(),
    photo: clampPhoto(member.photo, ''),
    durationValue: nonNeg(member.durationValue, 1),
    durationUnit:
      member.durationUnit === 'days' || member.durationUnit === 'years'
        ? member.durationUnit
        : 'months',
    startDate: clamp(member.startDate || getTodayISO(), 32),
    expiryDate: clamp(member.expiryDate || getTodayISO(), 32),
    membershipFee: fee,
    discount,
    amountPaid: paid,
    remainingAmount: remaining,
    paymentMethod: clamp(member.paymentMethod || 'Cash', 64),
    membershipStatus: member.membershipStatus === 'Inactive' ? 'Inactive' : 'Active',
    trainerId: clamp(member.trainerId, 128),
    trainerName: clamp(member.trainerName, 120),
    notes: clamp(member.notes, 1000),
    qrToken: clamp(member.qrToken || `GFG-QR-${id}`, 160),
    createdAt: clamp(member.createdAt || new Date().toISOString(), 64),
    updatedAt: clamp(member.updatedAt || new Date().toISOString(), 64),
    serverUpdatedAt: serverTimestamp(),
  };
  if (includeCreatedTimestamp) {
    docData.serverCreatedAt = serverTimestamp();
  }
  return docData;
}

function toFirestoreTrainer(
  ownerUid: string,
  trainer: Trainer,
  includeCreatedTimestamp: boolean
): Record<string, unknown> {
  const id = sanitizeFirestoreId(trainer.id, 'TRN');
  const docData: Record<string, unknown> = {
    ownerUid,
    id,
    name: clamp(trainer.name || 'Trainer', 140) || 'Trainer',
    mobile: clamp(trainer.mobile, 40),
    photo: clampPhoto(trainer.photo, ''),
    specialization: clamp(trainer.specialization, 160),
    pin: clamp(trainer.pin || '3333', 32),
    createdAt: clamp(trainer.createdAt || new Date().toISOString(), 64),
    serverUpdatedAt: serverTimestamp(),
  };
  if (includeCreatedTimestamp) {
    docData.serverCreatedAt = serverTimestamp();
  }
  return docData;
}

function toFirestorePayment(ownerUid: string, payment: PaymentRecord): Record<string, unknown> {
  const id = sanitizeFirestoreId(payment.id, 'PAY');
  return {
    ownerUid,
    id,
    memberId: clamp(payment.memberId, 128) || 'UNKNOWN',
    memberName: clamp(payment.memberName || '', 140),
    amount: nonNeg(payment.amount),
    discount: nonNeg(payment.discount),
    paymentMethod: clamp(payment.paymentMethod || 'Cash', 64),
    paymentDate: clamp(payment.paymentDate || getTodayISO(), 32) || getTodayISO(),
    type:
      payment.type === 'registration' ||
      payment.type === 'renewal' ||
      payment.type === 'adjustment'
        ? payment.type
        : 'installment',
    notes: clamp(payment.notes, 500),
    receiptNumber: clamp(payment.receiptNumber || 'GFG-REC', 64) || 'GFG-REC',
    createdAt: clamp(payment.createdAt || new Date().toISOString(), 64),
    serverCreatedAt: serverTimestamp(),
    serverUpdatedAt: serverTimestamp(),
  };
}

function toFirestoreHistory(
  ownerUid: string,
  hist: MembershipHistoryRecord
): Record<string, unknown> {
  const id = sanitizeFirestoreId(hist.id, 'HIST');
  return {
    ownerUid,
    id,
    memberId: clamp(hist.memberId, 128) || 'UNKNOWN',
    actionType:
      hist.actionType === 'renewal' ||
      hist.actionType === 'extension' ||
      hist.actionType === 'fee_update'
        ? hist.actionType
        : 'new',
    durationValue: nonNeg(hist.durationValue, 1),
    durationUnit:
      hist.durationUnit === 'days' || hist.durationUnit === 'years'
        ? hist.durationUnit
        : 'months',
    startDate: clamp(hist.startDate, 32),
    expiryDate: clamp(hist.expiryDate, 32),
    fee: nonNeg(hist.fee),
    discount: nonNeg(hist.discount),
    amountPaid: nonNeg(hist.amountPaid),
    notes: clamp(hist.notes, 500),
    createdAt: clamp(hist.createdAt || new Date().toISOString(), 64),
    serverCreatedAt: serverTimestamp(),
    serverUpdatedAt: serverTimestamp(),
  };
}

function toFirestoreAttendance(ownerUid: string, att: AttendanceRecord): Record<string, unknown> {
  const id = sanitizeFirestoreId(att.id, 'ATT');
  return {
    ownerUid,
    id,
    personType: att.personType === 'trainer' ? 'trainer' : 'member',
    personId: clamp(att.personId, 128) || 'UNKNOWN',
    date: clamp(att.date || getTodayISO(), 32) || getTodayISO(),
    entryTime: clamp(att.entryTime || getCurrentTimeHHMMSS(), 32) || '00:00:00',
    exitTime: clamp(att.exitTime, 32),
    entryTimestamp: clamp(att.entryTimestamp, 64),
    exitTimestamp: clamp(att.exitTimestamp, 64),
    durationMinutes: nonNeg(att.durationMinutes),
    status: att.status === 'LEFT GYM' ? 'LEFT GYM' : 'INSIDE GYM',
    shift: att.shift === 'Evening' ? 'Evening' : 'Morning',
    method: att.method === 'QR' ? 'QR' : 'Manual',
    createdAt: clamp(att.createdAt || new Date().toISOString(), 64),
    serverCreatedAt: serverTimestamp(),
    serverUpdatedAt: serverTimestamp(),
  };
}

function toFirestoreWorkout(ownerUid: string, item: WorkoutPlanItem): Record<string, unknown> {
  const id = sanitizeFirestoreId(item.id, 'WP');
  const mg = VALID_MUSCLE_GROUPS.includes(item.muscleGroup) ? item.muscleGroup : 'Chest';
  return {
    ownerUid,
    id,
    memberId: clamp(item.memberId, 128) || 'UNKNOWN',
    trainerId: clamp(item.trainerId, 128),
    muscleGroup: mg,
    exerciseName: clamp(item.exerciseName || 'Exercise', 140) || 'Exercise',
    sets: clamp(item.sets, 32),
    reps: clamp(item.reps, 32),
    restTime: clamp(item.restTime, 32),
    workoutDays: clamp(item.workoutDays, 80),
    notes: clamp(item.notes, 500),
    updatedAt: clamp(item.updatedAt || new Date().toISOString(), 64),
    serverCreatedAt: serverTimestamp(),
    serverUpdatedAt: serverTimestamp(),
  };
}

function toFirestoreDiet(ownerUid: string, diet: DietPlan): Record<string, unknown> {
  const id = sanitizeFirestoreId(diet.id, 'DP');
  return {
    ownerUid,
    id,
    memberId: clamp(diet.memberId, 128) || 'UNKNOWN',
    trainerId: clamp(diet.trainerId, 128),
    breakfast: clamp(diet.breakfast, 1000),
    lunch: clamp(diet.lunch, 1000),
    dinner: clamp(diet.dinner, 1000),
    snacks: clamp(diet.snacks, 1000),
    mealDetails: clamp(diet.mealDetails, 1000),
    trainerNotes: clamp(diet.trainerNotes, 1000),
    updatedAt: clamp(diet.updatedAt || new Date().toISOString(), 64),
    serverCreatedAt: serverTimestamp(),
    serverUpdatedAt: serverTimestamp(),
  };
}

export async function ensureOwnerDocument(
  user: User,
  overrides?: { gymName?: string; displayName?: string }
): Promise<void> {
  const ownerRef = doc(db, 'owners', user.uid);
  const path = `owners/${user.uid}`;
  try {
    const snap = await getDoc(ownerRef);
    if (!snap.exists()) {
      const defaults = buildDefaultSettings(user);
      const nowIso = new Date().toISOString();
      await commitWrite(
        setDoc(ownerRef, {
          ownerUid: user.uid,
          email: clamp(user.email || '', 200),
          displayName: clamp(overrides?.displayName || user.displayName || 'Admin', 120),
          gymName: clamp(overrides?.gymName || defaults.gymName, 120) || 'Golden Fitness Gym',
          gymLogo: clampPhoto(defaults.gymLogo, DEFAULT_GYM_LOGO),
          gymAddress: '',
          contactNumber: '',
          ownerName: clamp(overrides?.displayName || user.displayName || 'Admin', 120),
          ownerMobile: '',
          paymentMethods: defaults.paymentMethods,
          theme: defaults.theme,
          language: defaults.language,
          ownerPin: defaults.ownerPin,
          receptionPin: defaults.receptionPin,
          trainerPin: defaults.trainerPin,
          gymQrSecret: defaults.gymQrSecret,
          lastBackupAt: nowIso,
          createdAt: nowIso,
          updatedAt: nowIso,
          serverCreatedAt: serverTimestamp(),
          serverUpdatedAt: serverTimestamp(),
        }),
        OperationType.CREATE,
        path
      );
    } else if (overrides?.gymName || overrides?.displayName) {
      const existingData = snap.data();
      const updates: Record<string, unknown> = {
        updatedAt: new Date().toISOString(),
        serverUpdatedAt: serverTimestamp(),
      };
      if (overrides.gymName && existingData.gymName === 'Golden Fitness Gym') {
        updates.gymName = clamp(overrides.gymName, 120);
      }
      if (overrides.displayName) {
        updates.displayName = clamp(overrides.displayName, 120);
        if (!existingData.ownerName || existingData.ownerName === 'Admin') {
          updates.ownerName = clamp(overrides.displayName, 120);
        }
      }
      await commitWrite(updateDoc(ownerRef, updates), OperationType.UPDATE, path);
    }
  } catch (err) {
    // Allow offline cached boot if doc already exists offline
    if (typeof navigator !== 'undefined' && !navigator.onLine) return;
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export function subscribeToOwnerCloudData(
  user: User,
  onData: (payload: GymDataPayload, meta: CloudSyncMeta) => void,
  onError?: (err: Error) => void
): () => void {
  const ownerUid = user.uid;
  const fallbackSettings = buildDefaultSettings(user);

  let settings: GymSettings = fallbackSettings;
  let lastBackupAt = '';
  let members: Member[] = [];
  let trainers: Trainer[] = [];
  let payments: PaymentRecord[] = [];
  let membershipHistory: MembershipHistoryRecord[] = [];
  let attendance: AttendanceRecord[] = [];
  let workoutPlans: WorkoutPlanItem[] = [];
  let dietPlans: DietPlan[] = [];

  let ownerLoaded = false;
  const pendingBySlice = new Map<string, boolean>();
  const cacheBySlice = new Map<string, boolean>();

  const emit = () => {
    if (!ownerLoaded) return;
    const isOnline = typeof navigator === 'undefined' ? true : navigator.onLine;
    const hasPendingWrites = Array.from(pendingBySlice.values()).some(Boolean);
    const fromCache = Array.from(cacheBySlice.values()).some(Boolean);

    let status: CloudSyncStatus = 'synced';
    if (!isOnline) status = 'offline';
    else if (hasPendingWrites) status = 'syncing';

    const memberNameMap = new Map(members.map((m) => [m.id, m.name]));
    const enrichedPayments = payments.map((p) => ({
      ...p,
      memberName: p.memberName || memberNameMap.get(p.memberId) || p.memberId,
    }));

    onData(
      {
        settings,
        members: [...members].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')),
        trainers: [...trainers].sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || '')),
        payments: [...enrichedPayments].sort((a, b) =>
          `${b.paymentDate}${b.createdAt}`.localeCompare(`${a.paymentDate}${a.createdAt}`)
        ),
        membershipHistory: [...membershipHistory].sort((a, b) =>
          (b.createdAt || '').localeCompare(a.createdAt || '')
        ),
        attendance: [...attendance].sort((a, b) =>
          (b.createdAt || '').localeCompare(a.createdAt || '')
        ),
        workoutPlans: [...workoutPlans].sort((a, b) =>
          (b.updatedAt || '').localeCompare(a.updatedAt || '')
        ),
        dietPlans: [...dietPlans].sort((a, b) =>
          (b.updatedAt || '').localeCompare(a.updatedAt || '')
        ),
      },
      {
        status,
        lastBackupAt,
        hasPendingWrites,
        fromCache,
      }
    );
  };

  const reportError = (err: unknown, op: OperationType, path: string) => {
    try {
      handleFirestoreError(err, op, path);
    } catch (wrapped) {
      onError?.(wrapped as Error);
    }
  };

  const unsubs: Array<() => void> = [];

  // 1. Owner settings & profile document
  const ownerPath = `owners/${ownerUid}`;
  unsubs.push(
    onSnapshot(
      doc(db, 'owners', ownerUid),
      { includeMetadataChanges: true },
      (snap) => {
        pendingBySlice.set('owner', snap.metadata.hasPendingWrites);
        cacheBySlice.set('owner', snap.metadata.fromCache);
        if (snap.exists()) {
          const d = snap.data();
          const rawTpl = (d.reminderTemplates && typeof d.reminderTemplates === 'object'
            ? d.reminderTemplates
            : {}) as Record<string, unknown>;
          settings = {
            gymName: String(d.gymName || 'Golden Fitness Gym'),
            gymLogo: String(d.gymLogo || DEFAULT_GYM_LOGO),
            gymAddress: String(d.gymAddress || ''),
            contactNumber: String(d.contactNumber || ''),
            ownerName: String(d.ownerName || d.displayName || 'Admin'),
            ownerMobile: String(d.ownerMobile || ''),
            paymentMethods: sanitizePaymentMethods(d.paymentMethods),
            theme: d.theme === 'light' ? 'light' : 'dark',
            language: d.language === 'hi' ? 'hi' : 'en',
            ownerPin: String(d.ownerPin ?? '1234'),
            receptionPin: String(d.receptionPin ?? '2222'),
            trainerPin: String(d.trainerPin ?? '3333'),
            gymQrSecret: String(d.gymQrSecret || fallbackSettings.gymQrSecret),
            preventDuplicateSameDay: Boolean(d.preventDuplicateSameDay),
            reminderTemplates: {
              feeReminder: clamp(rawTpl.feeReminder ?? DEFAULT_REMINDER_TEMPLATES.feeReminder, 600),
              renewalReminder: clamp(rawTpl.renewalReminder ?? DEFAULT_REMINDER_TEMPLATES.renewalReminder, 600),
              pendingPayment: clamp(rawTpl.pendingPayment ?? DEFAULT_REMINDER_TEMPLATES.pendingPayment, 600),
              inactiveReminder: clamp(rawTpl.inactiveReminder ?? DEFAULT_REMINDER_TEMPLATES.inactiveReminder, 600),
            },
          };
          lastBackupAt = String(d.lastBackupAt || d.updatedAt || '');
          ownerLoaded = true;
          emit();
        }
      },
      (err) => reportError(err, OperationType.GET, ownerPath)
    )
  );

  const subCol = <T>(
    name: string,
    assign: (items: T[]) => void
  ) => {
    const colPath = `owners/${ownerUid}/${name}`;
    const q = query(collection(db, 'owners', ownerUid, name), where('ownerUid', '==', ownerUid));
    unsubs.push(
      onSnapshot(
        q,
        { includeMetadataChanges: true },
        (snap) => {
          pendingBySlice.set(name, snap.metadata.hasPendingWrites);
          cacheBySlice.set(name, snap.metadata.fromCache);
          assign(snap.docs.map((d) => d.data() as T));
          emit();
        },
        (err) => reportError(err, OperationType.LIST, colPath)
      )
    );
  };

  subCol<Member>('members', (items) => {
    members = items;
  });
  subCol<Trainer>('trainers', (items) => {
    trainers = items;
  });
  subCol<PaymentRecord>('payments', (items) => {
    payments = items;
  });
  subCol<MembershipHistoryRecord>('membershipHistory', (items) => {
    membershipHistory = items;
  });
  subCol<AttendanceRecord>('attendance', (items) => {
    attendance = items;
  });
  subCol<WorkoutPlanItem>('workoutPlans', (items) => {
    workoutPlans = items;
  });
  subCol<DietPlan>('dietPlans', (items) => {
    dietPlans = items;
  });

  const onNetworkChange = () => emit();
  window.addEventListener('online', onNetworkChange);
  window.addEventListener('offline', onNetworkChange);

  return () => {
    window.removeEventListener('online', onNetworkChange);
    window.removeEventListener('offline', onNetworkChange);
    for (const u of unsubs) u();
  };
}

/**
 * Automatically migrates existing local SQLite (/api/bootstrap) and localStorage cache data
 * into the authenticated owner's private Firestore space without creating duplicates.
 */
export async function migrateLocalDataToCloud(user: User): Promise<{ migratedCount: number }> {
  const ownerUid = user.uid;
  const sources: GymDataPayload[] = [];

  try {
    const cached = localStorage.getItem('gfg_cached_data_v2');
    if (cached) {
      const parsed = JSON.parse(cached) as GymDataPayload;
      if (parsed && Array.isArray(parsed.members)) {
        sources.push(parsed);
      }
    }
  } catch {
    // ignore corrupt cache
  }

  try {
    const res = await fetch('/api/bootstrap');
    if (res.ok) {
      const sqlData = (await res.json()) as GymDataPayload;
      if (sqlData && Array.isArray(sqlData.members)) {
        sources.push(sqlData);
      }
    }
  } catch {
    // local API optional in pure cloud / offline mode
  }

  if (sources.length === 0) return { migratedCount: 0 };

  const mergeById = <T extends { id: string }>(getter: (d: GymDataPayload) => T[] | undefined): T[] => {
    const map = new Map<string, T>();
    for (const src of sources) {
      for (const item of getter(src) || []) {
        const sid = sanitizeFirestoreId(item.id, 'ITEM');
        if (!map.has(sid)) {
          map.set(sid, { ...item, id: sid });
        }
      }
    }
    return Array.from(map.values());
  };

  const localMembers = mergeById((s) => s.members);
  const localTrainers = mergeById((s) => s.trainers);
  const localPayments = mergeById((s) => s.payments);
  const localHistory = mergeById((s) => s.membershipHistory);
  const localAttendance = mergeById((s) => s.attendance);
  const localWorkouts = mergeById((s) => s.workoutPlans);
  const localDiets = mergeById((s) => s.dietPlans);

  const hasAnyRecords =
    localMembers.length > 0 ||
    localTrainers.length > 0 ||
    localPayments.length > 0 ||
    localAttendance.length > 0 ||
    localWorkouts.length > 0 ||
    localDiets.length > 0;

  if (!hasAnyRecords) return { migratedCount: 0 };

  const fetchExistingIds = async (sub: string): Promise<Set<string>> => {
    const q = query(collection(db, 'owners', ownerUid, sub), where('ownerUid', '==', ownerUid));
    const snap = await getDocs(q);
    return new Set(snap.docs.map((d) => d.id));
  };

  const [
    existingMembers,
    existingTrainers,
    existingPayments,
    existingHistory,
    existingAttendance,
    existingWorkouts,
    existingDiets,
  ] = await Promise.all([
    fetchExistingIds('members'),
    fetchExistingIds('trainers'),
    fetchExistingIds('payments'),
    fetchExistingIds('membershipHistory'),
    fetchExistingIds('attendance'),
    fetchExistingIds('workoutPlans'),
    fetchExistingIds('dietPlans'),
  ]);

  const ops: Array<{ ref: ReturnType<typeof doc>; data: Record<string, unknown> }> = [];

  for (const t of localTrainers) {
    if (!existingTrainers.has(t.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'trainers', t.id),
        data: toFirestoreTrainer(ownerUid, t, true),
      });
    }
  }
  for (const m of localMembers) {
    if (!existingMembers.has(m.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'members', m.id),
        data: toFirestoreMember(ownerUid, m, true),
      });
    }
  }
  for (const p of localPayments) {
    if (!existingPayments.has(p.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'payments', p.id),
        data: toFirestorePayment(ownerUid, p),
      });
    }
  }
  for (const h of localHistory) {
    if (!existingHistory.has(h.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'membershipHistory', h.id),
        data: toFirestoreHistory(ownerUid, h),
      });
    }
  }
  for (const a of localAttendance) {
    if (!existingAttendance.has(a.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'attendance', a.id),
        data: toFirestoreAttendance(ownerUid, a),
      });
    }
  }
  for (const w of localWorkouts) {
    if (!existingWorkouts.has(w.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'workoutPlans', w.id),
        data: toFirestoreWorkout(ownerUid, w),
      });
    }
  }
  for (const d of localDiets) {
    if (!existingDiets.has(d.id)) {
      ops.push({
        ref: doc(db, 'owners', ownerUid, 'dietPlans', d.id),
        data: toFirestoreDiet(ownerUid, d),
      });
    }
  }

  // If cloud account was completely empty and local had customized settings (including printed gymQrSecret), preserve them
  if (
    existingMembers.size === 0 &&
    existingAttendance.size === 0 &&
    ops.length > 0
  ) {
    const localSettings = sources.find((s) => s.settings)?.settings;
    if (localSettings) {
      await commitWrite(
        updateDoc(doc(db, 'owners', ownerUid), {
          gymName: clamp(localSettings.gymName || 'Golden Fitness Gym', 120),
          gymLogo: clampPhoto(localSettings.gymLogo, DEFAULT_GYM_LOGO),
          gymAddress: clamp(localSettings.gymAddress, 250),
          contactNumber: clamp(localSettings.contactNumber, 40),
          ownerName: clamp(localSettings.ownerName || user.displayName || 'Admin', 120),
          ownerMobile: clamp(localSettings.ownerMobile, 40),
          paymentMethods: sanitizePaymentMethods(localSettings.paymentMethods),
          theme: localSettings.theme === 'light' ? 'light' : 'dark',
          language: localSettings.language === 'hi' ? 'hi' : 'en',
          ownerPin: clamp(localSettings.ownerPin || '1234', 32),
          receptionPin: clamp(localSettings.receptionPin || '2222', 32),
          trainerPin: clamp(localSettings.trainerPin || '3333', 32),
          ...(localSettings.gymQrSecret ? { gymQrSecret: clamp(localSettings.gymQrSecret, 128) } : {}),
          updatedAt: new Date().toISOString(),
          serverUpdatedAt: serverTimestamp(),
        }),
        OperationType.UPDATE,
        `owners/${ownerUid}`
      );
    }
  }

  for (let i = 0; i < ops.length; i += 400) {
    const chunk = ops.slice(i, i + 400);
    const batch = writeBatch(db);
    for (const op of chunk) {
      batch.set(op.ref, op.data);
    }
    await commitWrite(batch.commit(), OperationType.WRITE, `owners/${ownerUid}`);
  }

  return { migratedCount: ops.length };
}

export async function saveSettingsToCloud(ownerUid: string, next: GymSettings): Promise<void> {
  const path = `owners/${ownerUid}`;
  const tpl = next.reminderTemplates || DEFAULT_REMINDER_TEMPLATES;
  await commitWrite(
    updateDoc(doc(db, 'owners', ownerUid), {
      gymName: clamp(next.gymName || 'Golden Fitness Gym', 120) || 'Golden Fitness Gym',
      gymLogo: clampPhoto(next.gymLogo, DEFAULT_GYM_LOGO),
      gymAddress: clamp(next.gymAddress, 250),
      contactNumber: clamp(next.contactNumber, 40),
      ownerName: clamp(next.ownerName, 120),
      ownerMobile: clamp(next.ownerMobile, 40),
      paymentMethods: sanitizePaymentMethods(next.paymentMethods),
      theme: next.theme === 'light' ? 'light' : 'dark',
      language: next.language === 'hi' ? 'hi' : 'en',
      ownerPin: clamp(next.ownerPin, 32),
      receptionPin: clamp(next.receptionPin, 32),
      trainerPin: clamp(next.trainerPin, 32),
      gymQrSecret: clamp(next.gymQrSecret || generateGymQrSecret(), 128),
      preventDuplicateSameDay: Boolean(next.preventDuplicateSameDay),
      reminderTemplates: {
        feeReminder: clamp(tpl.feeReminder ?? DEFAULT_REMINDER_TEMPLATES.feeReminder, 600),
        renewalReminder: clamp(tpl.renewalReminder ?? DEFAULT_REMINDER_TEMPLATES.renewalReminder, 600),
        pendingPayment: clamp(tpl.pendingPayment ?? DEFAULT_REMINDER_TEMPLATES.pendingPayment, 600),
        inactiveReminder: clamp(tpl.inactiveReminder ?? DEFAULT_REMINDER_TEMPLATES.inactiveReminder, 600),
      },
      updatedAt: new Date().toISOString(),
      serverUpdatedAt: serverTimestamp(),
    }),
    OperationType.UPDATE,
    path
  );
}

export async function regenerateGymQrInCloud(ownerUid: string): Promise<void> {
  const path = `owners/${ownerUid}`;
  await commitWrite(
    updateDoc(doc(db, 'owners', ownerUid), {
      gymQrSecret: generateGymQrSecret(),
      updatedAt: new Date().toISOString(),
      serverUpdatedAt: serverTimestamp(),
    }),
    OperationType.UPDATE,
    path
  );
}

export async function triggerCloudBackupNow(ownerUid: string): Promise<{ lastBackupAt: string; offlineQueued: boolean }> {
  const nowIso = new Date().toISOString();
  const ownerRef = doc(db, 'owners', ownerUid);
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    await commitWrite(
      updateDoc(ownerRef, {
        lastBackupAt: nowIso,
        updatedAt: nowIso,
        serverUpdatedAt: serverTimestamp(),
      }),
      OperationType.UPDATE,
      `owners/${ownerUid}`
    );
    return { lastBackupAt: nowIso, offlineQueued: true };
  }

  await waitForPendingWrites(db);
  await updateDoc(ownerRef, {
    lastBackupAt: nowIso,
    updatedAt: nowIso,
    serverUpdatedAt: serverTimestamp(),
  });
  await waitForPendingWrites(db);
  return { lastBackupAt: nowIso, offlineQueued: false };
}

function getNextMemberId(existingMembers: Member[]): string {
  let maxNum = 100;
  for (const m of existingMembers) {
    const match = /^(?:FCH|GFG)-(\d+)$/.exec(m.id);
    if (match) {
      const n = Number(match[1]);
      if (n > maxNum) maxNum = n;
    }
  }
  return `GFG-${maxNum + 1}`;
}

export async function saveMemberToCloud(
  ownerUid: string,
  payload: Partial<Member>,
  existingMembers: Member[],
  editingId?: string
): Promise<void> {
  const nowISO = new Date().toISOString();
  const batch = writeBatch(db);

  if (editingId) {
    const existing = existingMembers.find((m) => m.id === editingId);
    if (!existing) throw new Error('Member not found');

    const fee = payload.membershipFee !== undefined ? nonNeg(payload.membershipFee) : existing.membershipFee;
    const discount = payload.discount !== undefined ? nonNeg(payload.discount) : existing.discount;
    const paid = payload.amountPaid !== undefined ? nonNeg(payload.amountPaid) : existing.amountPaid;
    const remaining = computeRemainingBalance(fee, discount, paid);
    const updatedMember: Member = {
      ...existing,
      ...payload,
      id: existing.id,
      membershipFee: fee,
      discount,
      amountPaid: paid,
      remainingAmount: remaining,
      membershipStatus:
        payload.membershipStatus !== undefined
          ? payload.membershipStatus === 'Inactive'
            ? 'Inactive'
            : 'Active'
          : existing.membershipStatus,
      updatedAt: nowISO,
    };

    const fullDoc = toFirestoreMember(ownerUid, updatedMember, false);
    delete fullDoc.ownerUid;
    delete fullDoc.id;
    delete fullDoc.createdAt;

    batch.update(doc(db, 'owners', ownerUid, 'members', existing.id), fullDoc);

    if (
      existing.membershipFee !== fee ||
      existing.discount !== discount ||
      existing.expiryDate !== updatedMember.expiryDate
    ) {
      const histId = makeDocId('HIST');
      const histRecord: MembershipHistoryRecord = {
        id: histId,
        memberId: existing.id,
        actionType: existing.expiryDate !== updatedMember.expiryDate ? 'extension' : 'fee_update',
        durationValue: updatedMember.durationValue,
        durationUnit: updatedMember.durationUnit,
        startDate: updatedMember.startDate,
        expiryDate: updatedMember.expiryDate,
        fee,
        discount,
        amountPaid: paid,
        notes: 'Updated custom fee or expiry date',
        createdAt: nowISO,
      };
      batch.set(
        doc(db, 'owners', ownerUid, 'membershipHistory', histId),
        toFirestoreHistory(ownerUid, histRecord)
      );
    }

    await commitWrite(batch.commit(), OperationType.UPDATE, `owners/${ownerUid}/members/${existing.id}`);
    return;
  }

  const newId = getNextMemberId(existingMembers);
  const fee = nonNeg(payload.membershipFee);
  const discount = nonNeg(payload.discount);
  const paid = nonNeg(payload.amountPaid);
  const remaining = computeRemainingBalance(fee, discount, paid);
  const today = getTodayISO();

  const newMember: Member = {
    id: newId,
    name: payload.name || 'Unnamed Member',
    whatsapp: payload.whatsapp || '',
    age: nonNeg(payload.age, 24),
    gender: payload.gender || 'Male',
    address: payload.address || '',
    joiningDate: payload.joiningDate || today,
    photo: payload.photo || '',
    durationValue: nonNeg(payload.durationValue, 1),
    durationUnit: payload.durationUnit || 'months',
    startDate: payload.startDate || today,
    expiryDate: payload.expiryDate || today,
    membershipFee: fee,
    discount,
    amountPaid: paid,
    remainingAmount: remaining,
    paymentMethod: payload.paymentMethod || 'Cash',
    membershipStatus: payload.membershipStatus === 'Inactive' ? 'Inactive' : 'Active',
    trainerId: payload.trainerId || '',
    trainerName: payload.trainerName || '',
    notes: payload.notes || '',
    qrToken: `GFG-QR-${newId}`,
    createdAt: nowISO,
    updatedAt: nowISO,
  };

  batch.set(
    doc(db, 'owners', ownerUid, 'members', newId),
    toFirestoreMember(ownerUid, newMember, true)
  );

  const histId = makeDocId('HIST');
  batch.set(
    doc(db, 'owners', ownerUid, 'membershipHistory', histId),
    toFirestoreHistory(ownerUid, {
      id: histId,
      memberId: newId,
      actionType: 'new',
      durationValue: newMember.durationValue,
      durationUnit: newMember.durationUnit,
      startDate: newMember.startDate,
      expiryDate: newMember.expiryDate,
      fee,
      discount,
      amountPaid: paid,
      notes: newMember.notes || 'New registration',
      createdAt: nowISO,
    })
  );

  if (paid > 0) {
    const payId = makeDocId('PAY');
    batch.set(
      doc(db, 'owners', ownerUid, 'payments', payId),
      toFirestorePayment(ownerUid, {
        id: payId,
        memberId: newId,
        memberName: newMember.name,
        amount: paid,
        discount,
        paymentMethod: newMember.paymentMethod,
        paymentDate: newMember.joiningDate,
        type: 'registration',
        notes: `Registration fee (${newMember.durationValue} ${newMember.durationUnit})`,
        receiptNumber: `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`,
        createdAt: nowISO,
      })
    );
  }

  await commitWrite(batch.commit(), OperationType.CREATE, `owners/${ownerUid}/members/${newId}`);
}

export async function deleteMemberFromCloud(
  ownerUid: string,
  memberId: string,
  data: GymDataPayload
): Promise<void> {
  const ops: Array<ReturnType<typeof doc>> = [
    doc(db, 'owners', ownerUid, 'members', memberId),
    ...data.attendance
      .filter((a) => a.personType === 'member' && a.personId === memberId)
      .map((a) => doc(db, 'owners', ownerUid, 'attendance', a.id)),
    ...data.payments
      .filter((p) => p.memberId === memberId)
      .map((p) => doc(db, 'owners', ownerUid, 'payments', p.id)),
    ...data.membershipHistory
      .filter((h) => h.memberId === memberId)
      .map((h) => doc(db, 'owners', ownerUid, 'membershipHistory', h.id)),
    ...data.workoutPlans
      .filter((w) => w.memberId === memberId)
      .map((w) => doc(db, 'owners', ownerUid, 'workoutPlans', w.id)),
    ...data.dietPlans
      .filter((d) => d.memberId === memberId)
      .map((d) => doc(db, 'owners', ownerUid, 'dietPlans', d.id)),
  ];

  for (let i = 0; i < ops.length; i += 400) {
    const batch = writeBatch(db);
    for (const ref of ops.slice(i, i + 400)) {
      batch.delete(ref);
    }
    await commitWrite(batch.commit(), OperationType.DELETE, `owners/${ownerUid}/members/${memberId}`);
  }
}

export async function collectPaymentInCloud(
  ownerUid: string,
  member: Member,
  payload: {
    memberId: string;
    amount: number;
    discount: number;
    paymentMethod: string;
    paymentDate: string;
    notes: string;
    newMembershipFee?: number;
  }
): Promise<{ receiptNumber: string }> {
  const nowISO = new Date().toISOString();
  const payAmount = nonNeg(payload.amount);
  const extraDiscount = nonNeg(payload.discount);
  const updatedFee =
    payload.newMembershipFee !== undefined
      ? nonNeg(payload.newMembershipFee)
      : member.membershipFee;
  const updatedDiscount = member.discount + extraDiscount;
  const updatedPaid = member.amountPaid + payAmount;
  const remaining = computeRemainingBalance(updatedFee, updatedDiscount, updatedPaid);
  const receiptNumber = `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`;
  const payId = makeDocId('PAY');

  const batch = writeBatch(db);
  batch.update(doc(db, 'owners', ownerUid, 'members', member.id), {
    membershipFee: updatedFee,
    discount: updatedDiscount,
    amountPaid: updatedPaid,
    remainingAmount: remaining,
    paymentMethod: clamp(payload.paymentMethod || member.paymentMethod || 'Cash', 64),
    updatedAt: nowISO,
    serverUpdatedAt: serverTimestamp(),
  });
  batch.set(
    doc(db, 'owners', ownerUid, 'payments', payId),
    toFirestorePayment(ownerUid, {
      id: payId,
      memberId: member.id,
      memberName: member.name,
      amount: payAmount,
      discount: extraDiscount,
      paymentMethod: payload.paymentMethod || 'Cash',
      paymentDate: payload.paymentDate || getTodayISO(),
      type: 'installment',
      notes: payload.notes || 'Fee payment',
      receiptNumber,
      createdAt: nowISO,
    })
  );

  await commitWrite(batch.commit(), OperationType.WRITE, `owners/${ownerUid}/payments/${payId}`);
  return { receiptNumber };
}

export async function renewMembershipInCloud(
  ownerUid: string,
  member: Member,
  payload: {
    durationValue: number;
    durationUnit: DurationUnit;
    startDate: string;
    expiryDate: string;
    membershipFee: number;
    discount: number;
    amountPaid: number;
    paymentMethod: string;
    paymentDate: string;
    carryPreviousBalance: boolean;
    notes: string;
  }
): Promise<{ receiptNumber: string }> {
  const nowISO = new Date().toISOString();
  const prevRemaining = payload.carryPreviousBalance ? nonNeg(member.remainingAmount) : 0;
  const newFee = nonNeg(payload.membershipFee) + prevRemaining;
  const newDiscount = nonNeg(payload.discount);
  const newPaid = nonNeg(payload.amountPaid);
  const remaining = computeRemainingBalance(newFee, newDiscount, newPaid);
  const receiptNumber = `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`;

  const batch = writeBatch(db);
  batch.update(doc(db, 'owners', ownerUid, 'members', member.id), {
    durationValue: nonNeg(payload.durationValue, 1),
    durationUnit: payload.durationUnit || 'months',
    startDate: clamp(payload.startDate, 32),
    expiryDate: clamp(payload.expiryDate, 32),
    membershipFee: newFee,
    discount: newDiscount,
    amountPaid: newPaid,
    remainingAmount: remaining,
    paymentMethod: clamp(payload.paymentMethod || 'Cash', 64),
    membershipStatus: 'Active',
    updatedAt: nowISO,
    serverUpdatedAt: serverTimestamp(),
  });

  const histId = makeDocId('HIST');
  batch.set(
    doc(db, 'owners', ownerUid, 'membershipHistory', histId),
    toFirestoreHistory(ownerUid, {
      id: histId,
      memberId: member.id,
      actionType: 'renewal',
      durationValue: nonNeg(payload.durationValue, 1),
      durationUnit: payload.durationUnit || 'months',
      startDate: payload.startDate,
      expiryDate: payload.expiryDate,
      fee: newFee,
      discount: newDiscount,
      amountPaid: newPaid,
      notes: payload.notes || `Renewed for ${payload.durationValue} ${payload.durationUnit}`,
      createdAt: nowISO,
    })
  );

  if (newPaid > 0) {
    const payId = makeDocId('PAY');
    batch.set(
      doc(db, 'owners', ownerUid, 'payments', payId),
      toFirestorePayment(ownerUid, {
        id: payId,
        memberId: member.id,
        memberName: member.name,
        amount: newPaid,
        discount: newDiscount,
        paymentMethod: payload.paymentMethod || 'Cash',
        paymentDate: payload.paymentDate || getTodayISO(),
        type: 'renewal',
        notes: payload.notes || `Membership renewal (${payload.durationValue} ${payload.durationUnit})`,
        receiptNumber,
        createdAt: nowISO,
      })
    );
  }

  await commitWrite(batch.commit(), OperationType.WRITE, `owners/${ownerUid}/members/${member.id}`);
  return { receiptNumber };
}

export async function markAttendanceInCloud(
  ownerUid: string,
  data: GymDataPayload,
  payload: {
    personType: 'member' | 'trainer';
    personIdOrToken: string;
    date: string;
    entryTime: string;
    shift: AttendanceShift;
    method: AttendanceMethod;
    action?: 'auto' | 'entry' | 'exit';
  }
): Promise<void> {
  const nowMs = Date.now();
  const nowISO = new Date(nowMs).toISOString();
  const token = (payload.personIdOrToken || '').trim();
  let resolvedId = token;

  if (payload.personType === 'member') {
    const found = data.members.find(
      (m) =>
        m.id.toUpperCase() === token.toUpperCase() ||
        m.qrToken === token ||
        m.whatsapp === token
    );
    if (!found) {
      throw new Error('Member ID, mobile, or QR token not recognized');
    }
    resolvedId = found.id;
  } else {
    const foundTrainer = data.trainers.find((t) => t.id === token);
    if (!foundTrainer) {
      throw new Error('Trainer not found');
    }
    resolvedId = foundTrainer.id;
  }

  const attDate = payload.date || getTodayISO();
  const attTime = payload.entryTime || getCurrentTimeHHMMSS();

  // Prevent accidental duplicate clicks/scans within 10 seconds
  const personLogs = data.attendance.filter(
    (a) => a.personType === payload.personType && a.personId === resolvedId
  );
  const latestScan = personLogs[0];
  if (latestScan) {
    const lastTs = Math.max(
      Date.parse(latestScan.entryTimestamp || latestScan.createdAt || '') || 0,
      Date.parse(latestScan.exitTimestamp || '') || 0
    );
    if (lastTs > 0 && nowMs - lastTs < 10000) {
      throw new Error('Duplicate scan ignored. Please wait 10 seconds before scanning again.');
    }
  }

  const openVisit = personLogs.find((a) => a.date === attDate && a.status === 'INSIDE GYM');
  const action = payload.action || 'auto';

  if (openVisit) {
    if (action === 'entry') {
      throw new Error('Already INSIDE GYM. Record EXIT before starting a new visit.');
    }
    const entryMs = Date.parse(openVisit.entryTimestamp || openVisit.createdAt || '') || nowMs;
    const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));
    await commitWrite(
      updateDoc(doc(db, 'owners', ownerUid, 'attendance', openVisit.id), {
        exitTime: clamp(attTime, 32),
        exitTimestamp: nowISO,
        durationMinutes,
        status: 'LEFT GYM',
        serverUpdatedAt: serverTimestamp(),
      }),
      OperationType.UPDATE,
      `owners/${ownerUid}/attendance/${openVisit.id}`
    );
    return;
  }

  if (action === 'exit') {
    throw new Error('No active ENTRY session found to mark EXIT.');
  }

  if (
    payload.personType === 'member' &&
    data.settings.preventDuplicateSameDay &&
    personLogs.some((a) => a.date === attDate)
  ) {
    throw new Error(
      'Duplicate attendance blocked: already checked in today (Same-day limit is active).'
    );
  }

  const attShift = payload.shift || getShiftForTime(attTime);
  const attId = makeDocId('ATT');
  const record: AttendanceRecord = {
    id: attId,
    personType: payload.personType,
    personId: resolvedId,
    date: attDate,
    entryTime: attTime,
    exitTime: '',
    entryTimestamp: nowISO,
    exitTimestamp: '',
    durationMinutes: 0,
    status: 'INSIDE GYM',
    shift: attShift,
    method: payload.method || 'Manual',
    createdAt: nowISO,
  };

  await commitWrite(
    setDoc(doc(db, 'owners', ownerUid, 'attendance', attId), toFirestoreAttendance(ownerUid, record)),
    OperationType.CREATE,
    `owners/${ownerUid}/attendance/${attId}`
  );
}

export async function markExitInCloud(
  ownerUid: string,
  attendanceRecord: AttendanceRecord
): Promise<void> {
  if (attendanceRecord.status === 'LEFT GYM') {
    throw new Error('EXIT already recorded for this session');
  }
  const nowMs = Date.now();
  const nowISO = new Date(nowMs).toISOString();
  const outTime = getCurrentTimeHHMMSS();
  const entryMs =
    Date.parse(attendanceRecord.entryTimestamp || attendanceRecord.createdAt || '') || nowMs;
  const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));

  await commitWrite(
    updateDoc(doc(db, 'owners', ownerUid, 'attendance', attendanceRecord.id), {
      exitTime: clamp(outTime, 32),
      exitTimestamp: nowISO,
      durationMinutes,
      status: 'LEFT GYM',
      serverUpdatedAt: serverTimestamp(),
    }),
    OperationType.UPDATE,
    `owners/${ownerUid}/attendance/${attendanceRecord.id}`
  );
}

export async function scanGymQrInCloud(
  ownerUid: string,
  data: GymDataPayload,
  payload: {
    memberId: string;
    qrCode: string;
    action: 'auto' | 'entry' | 'exit';
    clientDate: string;
    clientTime: string;
  }
): Promise<{ actionTaken: 'ENTRY' | 'EXIT'; message: string }> {
  const member = data.members.find((m) => m.id === payload.memberId);
  if (!member) throw new Error('Member not found');

  const scannedSecret = extractGymQrSecret(payload.qrCode);
  if (!scannedSecret || scannedSecret !== data.settings.gymQrSecret) {
    throw new Error(
      'Invalid gym QR code. Please scan the official Golden Fitness Gym QR code at reception.'
    );
  }

  const nowMs = Date.now();
  const nowISO = new Date(nowMs).toISOString();
  const attDate = payload.clientDate || getTodayISO();
  const attTime = payload.clientTime || getCurrentTimeHHMMSS();

  const memberLogs = data.attendance.filter(
    (a) => a.personType === 'member' && a.personId === member.id
  );
  const latestScan = memberLogs[0];
  if (latestScan) {
    const lastTs = Math.max(
      Date.parse(latestScan.entryTimestamp || latestScan.createdAt || '') || 0,
      Date.parse(latestScan.exitTimestamp || '') || 0
    );
    if (lastTs > 0 && nowMs - lastTs < 10000) {
      throw new Error('Duplicate scan blocked. Please wait 10 seconds before scanning again.');
    }
  }

  const openVisit = memberLogs.find((a) => a.date === attDate && a.status === 'INSIDE GYM');

  if (openVisit) {
    if (payload.action === 'entry') {
      throw new Error('Already checked in (INSIDE GYM). Scan or select EXIT when leaving.');
    }
    const entryMs = Date.parse(openVisit.entryTimestamp || openVisit.createdAt || '') || nowMs;
    const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));
    await commitWrite(
      updateDoc(doc(db, 'owners', ownerUid, 'attendance', openVisit.id), {
        exitTime: clamp(attTime, 32),
        exitTimestamp: nowISO,
        durationMinutes,
        status: 'LEFT GYM',
        serverUpdatedAt: serverTimestamp(),
      }),
      OperationType.UPDATE,
      `owners/${ownerUid}/attendance/${openVisit.id}`
    );
    return {
      actionTaken: 'EXIT',
      message: `EXIT recorded at ${attTime}. Status: LEFT GYM`,
    };
  }

  if (payload.action === 'exit') {
    throw new Error('No active ENTRY found. Scan or select ENTRY first when entering the gym.');
  }

  if (
    data.settings.preventDuplicateSameDay &&
    memberLogs.some((a) => a.date === attDate)
  ) {
    throw new Error(
      'Duplicate attendance blocked: you have already recorded attendance today.'
    );
  }

  const attShift = getShiftForTime(attTime);
  const attId = makeDocId('ATT');
  await commitWrite(
    setDoc(
      doc(db, 'owners', ownerUid, 'attendance', attId),
      toFirestoreAttendance(ownerUid, {
        id: attId,
        personType: 'member',
        personId: member.id,
        date: attDate,
        entryTime: attTime,
        exitTime: '',
        entryTimestamp: nowISO,
        exitTimestamp: '',
        durationMinutes: 0,
        status: 'INSIDE GYM',
        shift: attShift,
        method: 'QR',
        createdAt: nowISO,
      })
    ),
    OperationType.CREATE,
    `owners/${ownerUid}/attendance/${attId}`
  );

  return {
    actionTaken: 'ENTRY',
    message: `ENTRY recorded (${attShift} session) at ${attTime}. Status: INSIDE GYM`,
  };
}

export async function saveTrainerToCloud(
  ownerUid: string,
  payload: Partial<Trainer>,
  members: Member[],
  editingId?: string
): Promise<void> {
  const nowISO = new Date().toISOString();
  if (editingId) {
    const batch = writeBatch(db);
    batch.update(doc(db, 'owners', ownerUid, 'trainers', editingId), {
      name: clamp(payload.name || 'Trainer', 140) || 'Trainer',
      mobile: clamp(payload.mobile, 40),
      photo: clampPhoto(payload.photo, ''),
      specialization: clamp(payload.specialization, 160),
      pin: clamp(payload.pin || '3333', 32),
      serverUpdatedAt: serverTimestamp(),
    });
    for (const m of members) {
      if (m.trainerId === editingId) {
        batch.update(doc(db, 'owners', ownerUid, 'members', m.id), {
          trainerName: clamp(payload.name || '', 120),
          updatedAt: nowISO,
          serverUpdatedAt: serverTimestamp(),
        });
      }
    }
    await commitWrite(batch.commit(), OperationType.UPDATE, `owners/${ownerUid}/trainers/${editingId}`);
    return;
  }

  const id = makeDocId('TRN');
  const trainer: Trainer = {
    id,
    name: payload.name || 'Trainer',
    mobile: payload.mobile || '',
    photo: payload.photo || '',
    specialization: payload.specialization || 'General Fitness',
    pin: payload.pin || '3333',
    createdAt: nowISO,
  };
  await commitWrite(
    setDoc(doc(db, 'owners', ownerUid, 'trainers', id), toFirestoreTrainer(ownerUid, trainer, true)),
    OperationType.CREATE,
    `owners/${ownerUid}/trainers/${id}`
  );
}

export async function deleteTrainerFromCloud(
  ownerUid: string,
  trainerId: string,
  data: GymDataPayload
): Promise<void> {
  const nowISO = new Date().toISOString();
  const batch = writeBatch(db);
  batch.delete(doc(db, 'owners', ownerUid, 'trainers', trainerId));
  for (const m of data.members) {
    if (m.trainerId === trainerId) {
      batch.update(doc(db, 'owners', ownerUid, 'members', m.id), {
        trainerId: '',
        trainerName: '',
        updatedAt: nowISO,
        serverUpdatedAt: serverTimestamp(),
      });
    }
  }
  for (const a of data.attendance) {
    if (a.personType === 'trainer' && a.personId === trainerId) {
      batch.delete(doc(db, 'owners', ownerUid, 'attendance', a.id));
    }
  }
  await commitWrite(batch.commit(), OperationType.DELETE, `owners/${ownerUid}/trainers/${trainerId}`);
}

export async function addWorkoutToCloud(
  ownerUid: string,
  payload: Omit<WorkoutPlanItem, 'id' | 'updatedAt'>
): Promise<void> {
  const id = makeDocId('WP');
  const item: WorkoutPlanItem = {
    ...payload,
    id,
    updatedAt: new Date().toISOString(),
  };
  await commitWrite(
    setDoc(doc(db, 'owners', ownerUid, 'workoutPlans', id), toFirestoreWorkout(ownerUid, item)),
    OperationType.CREATE,
    `owners/${ownerUid}/workoutPlans/${id}`
  );
}

export async function deleteWorkoutFromCloud(ownerUid: string, workoutId: string): Promise<void> {
  await commitWrite(
    writeBatch(db).delete(doc(db, 'owners', ownerUid, 'workoutPlans', workoutId)).commit(),
    OperationType.DELETE,
    `owners/${ownerUid}/workoutPlans/${workoutId}`
  );
}

export async function saveDietToCloud(
  ownerUid: string,
  existingDiets: DietPlan[],
  payload: Omit<DietPlan, 'id' | 'updatedAt'>
): Promise<void> {
  const nowISO = new Date().toISOString();
  const existing = existingDiets.find((d) => d.memberId === payload.memberId);

  if (existing) {
    await commitWrite(
      updateDoc(doc(db, 'owners', ownerUid, 'dietPlans', existing.id), {
        trainerId: clamp(payload.trainerId, 128),
        breakfast: clamp(payload.breakfast, 1000),
        lunch: clamp(payload.lunch, 1000),
        dinner: clamp(payload.dinner, 1000),
        snacks: clamp(payload.snacks, 1000),
        mealDetails: clamp(payload.mealDetails, 1000),
        trainerNotes: clamp(payload.trainerNotes, 1000),
        updatedAt: nowISO,
        serverUpdatedAt: serverTimestamp(),
      }),
      OperationType.UPDATE,
      `owners/${ownerUid}/dietPlans/${existing.id}`
    );
    return;
  }

  const id = makeDocId('DP');
  await commitWrite(
    setDoc(
      doc(db, 'owners', ownerUid, 'dietPlans', id),
      toFirestoreDiet(ownerUid, { ...payload, id, updatedAt: nowISO })
    ),
    OperationType.CREATE,
    `owners/${ownerUid}/dietPlans/${id}`
  );
}

export async function resetAllCloudData(ownerUid: string, data: GymDataPayload): Promise<void> {
  const refs: Array<ReturnType<typeof doc>> = [
    ...data.workoutPlans.map((w) => doc(db, 'owners', ownerUid, 'workoutPlans', w.id)),
    ...data.dietPlans.map((d) => doc(db, 'owners', ownerUid, 'dietPlans', d.id)),
    ...data.attendance.map((a) => doc(db, 'owners', ownerUid, 'attendance', a.id)),
    ...data.payments.map((p) => doc(db, 'owners', ownerUid, 'payments', p.id)),
    ...data.membershipHistory.map((h) => doc(db, 'owners', ownerUid, 'membershipHistory', h.id)),
    ...data.members.map((m) => doc(db, 'owners', ownerUid, 'members', m.id)),
    ...data.trainers.map((t) => doc(db, 'owners', ownerUid, 'trainers', t.id)),
  ];

  for (let i = 0; i < refs.length; i += 400) {
    const batch = writeBatch(db);
    for (const ref of refs.slice(i, i + 400)) {
      batch.delete(ref);
    }
    await commitWrite(batch.commit(), OperationType.DELETE, `owners/${ownerUid}`);
  }
}

export async function restoreBackupToCloud(
  ownerUid: string,
  currentData: GymDataPayload,
  rawJson: unknown
): Promise<void> {
  const body = rawJson as { data?: GymDataPayload } & Partial<GymDataPayload>;
  const payload = body?.data || (body as GymDataPayload);
  if (!payload || !Array.isArray(payload.members)) {
    throw new Error('Invalid backup file format');
  }

  await resetAllCloudData(ownerUid, currentData);

  if (payload.settings) {
    await saveSettingsToCloud(ownerUid, {
      ...currentData.settings,
      ...payload.settings,
      gymQrSecret: payload.settings.gymQrSecret || currentData.settings.gymQrSecret || generateGymQrSecret(),
    });
  }

  const ops: Array<{ ref: ReturnType<typeof doc>; data: Record<string, unknown> }> = [];
  for (const t of payload.trainers || []) {
    const id = sanitizeFirestoreId(t.id, 'TRN');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'trainers', id),
      data: toFirestoreTrainer(ownerUid, { ...t, id }, true),
    });
  }
  for (const m of payload.members || []) {
    const id = sanitizeFirestoreId(m.id, 'GFG');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'members', id),
      data: toFirestoreMember(ownerUid, { ...m, id }, true),
    });
  }
  for (const p of payload.payments || []) {
    const id = sanitizeFirestoreId(p.id, 'PAY');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'payments', id),
      data: toFirestorePayment(ownerUid, { ...p, id }),
    });
  }
  for (const h of payload.membershipHistory || []) {
    const id = sanitizeFirestoreId(h.id, 'HIST');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'membershipHistory', id),
      data: toFirestoreHistory(ownerUid, { ...h, id }),
    });
  }
  for (const a of payload.attendance || []) {
    const id = sanitizeFirestoreId(a.id, 'ATT');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'attendance', id),
      data: toFirestoreAttendance(ownerUid, { ...a, id }),
    });
  }
  for (const w of payload.workoutPlans || []) {
    const id = sanitizeFirestoreId(w.id, 'WP');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'workoutPlans', id),
      data: toFirestoreWorkout(ownerUid, { ...w, id }),
    });
  }
  for (const d of payload.dietPlans || []) {
    const id = sanitizeFirestoreId(d.id, 'DP');
    ops.push({
      ref: doc(db, 'owners', ownerUid, 'dietPlans', id),
      data: toFirestoreDiet(ownerUid, { ...d, id }),
    });
  }

  for (let i = 0; i < ops.length; i += 400) {
    const batch = writeBatch(db);
    for (const op of ops.slice(i, i + 400)) {
      batch.set(op.ref, op.data);
    }
    await commitWrite(batch.commit(), OperationType.WRITE, `owners/${ownerUid}`);
  }
}
