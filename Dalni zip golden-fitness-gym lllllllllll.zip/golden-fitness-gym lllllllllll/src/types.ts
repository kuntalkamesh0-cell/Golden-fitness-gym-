export type UserRole = 'owner' | 'reception' | 'trainer' | 'member';
export type Language = 'en' | 'hi';
export type AppTheme = 'dark' | 'light';
export type DurationUnit = 'days' | 'months' | 'years';
export type AttendanceShift = 'Morning' | 'Evening';
export type AttendanceMethod = 'QR' | 'Manual';
export type AttendanceStatus = 'INSIDE GYM' | 'LEFT GYM';
export type MembershipStatus = 'Active' | 'Inactive';
export type MuscleGroup = 'Chest' | 'Back' | 'Legs' | 'Shoulders' | 'Arms' | 'Cardio';

export interface ReminderTemplates {
  feeReminder: string;
  renewalReminder: string;
  pendingPayment: string;
  inactiveReminder: string;
}

export interface GymSettings {
  gymName: string;
  gymLogo: string;
  gymAddress: string;
  contactNumber: string;
  ownerName: string;
  ownerMobile: string;
  paymentMethods: string[];
  theme: AppTheme;
  language: Language;
  ownerPin: string;
  receptionPin: string;
  trainerPin: string;
  gymQrSecret: string;
  preventDuplicateSameDay?: boolean;
  reminderTemplates?: ReminderTemplates;
}

export interface Trainer {
  id: string;
  name: string;
  mobile: string;
  photo: string;
  specialization: string;
  pin: string;
  createdAt: string;
}

export interface Member {
  id: string;
  name: string;
  whatsapp: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address: string;
  joiningDate: string;
  photo: string;
  durationValue: number;
  durationUnit: DurationUnit;
  startDate: string;
  expiryDate: string;
  membershipFee: number;
  discount: number;
  amountPaid: number;
  remainingAmount: number;
  paymentMethod: string;
  membershipStatus: MembershipStatus;
  trainerId: string;
  trainerName: string;
  notes: string;
  qrToken: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentRecord {
  id: string;
  memberId: string;
  memberName?: string;
  amount: number;
  discount: number;
  paymentMethod: string;
  paymentDate: string;
  type: 'registration' | 'installment' | 'renewal' | 'adjustment';
  notes: string;
  receiptNumber: string;
  createdAt: string;
}

export interface MembershipHistoryRecord {
  id: string;
  memberId: string;
  actionType: 'new' | 'renewal' | 'extension' | 'fee_update';
  durationValue: number;
  durationUnit: DurationUnit;
  startDate: string;
  expiryDate: string;
  fee: number;
  discount: number;
  amountPaid: number;
  notes: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  personType: 'member' | 'trainer';
  personId: string;
  date: string;
  entryTime: string;
  exitTime: string;
  entryTimestamp: string;
  exitTimestamp: string;
  durationMinutes: number;
  status: AttendanceStatus;
  shift: AttendanceShift;
  method: AttendanceMethod;
  createdAt: string;
}

export interface WorkoutPlanItem {
  id: string;
  memberId: string;
  trainerId: string;
  muscleGroup: MuscleGroup;
  exerciseName: string;
  sets: string;
  reps: string;
  restTime: string;
  workoutDays: string;
  notes: string;
  updatedAt: string;
}

export interface DietPlan {
  id: string;
  memberId: string;
  trainerId: string;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
  mealDetails: string;
  trainerNotes: string;
  updatedAt: string;
}

export interface AuthSession {
  role: UserRole;
  userId: string;
  displayName: string;
  memberId?: string;
  trainerId?: string;
}

export interface GymDataPayload {
  settings: GymSettings;
  members: Member[];
  trainers: Trainer[];
  payments: PaymentRecord[];
  membershipHistory: MembershipHistoryRecord[];
  attendance: AttendanceRecord[];
  workoutPlans: WorkoutPlanItem[];
  dietPlans: DietPlan[];
}

export type CloudSyncStatus = 'synced' | 'syncing' | 'offline';

export interface CloudSyncMeta {
  status: CloudSyncStatus;
  lastBackupAt: string;
  hasPendingWrites: boolean;
  fromCache: boolean;
  migratedCount?: number;
}

