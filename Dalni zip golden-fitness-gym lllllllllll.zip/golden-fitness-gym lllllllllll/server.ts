import express from 'express';
import fs from 'fs';
import path from 'path';
import { db, generateGymQrSecret, getAllData, initDatabase, resetAllGymData } from './server/db.ts';
import { buildProjectSourceZip } from './server/sourceExporter.ts';

initDatabase();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

function makeId(prefix: string) {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
}

function getNextMemberId(): string {
  const rows = db.prepare('SELECT id FROM members').all() as Array<{ id: string }>;
  let maxNum = 100;
  for (const r of rows) {
    const match = /^(?:FCH|GFG)-(\d+)$/.exec(r.id);
    if (match) {
      const n = Number(match[1]);
      if (n > maxNum) maxNum = n;
    }
  }
  return `GFG-${maxNum + 1}`;
}

function calcRemaining(fee: number, discount: number, paid: number): number {
  const net = Math.max(0, (Number(fee) || 0) - (Number(discount) || 0));
  return Math.max(0, net - (Number(paid) || 0));
}

function getServerLocalDateISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getServerLocalTimeHHMMSS(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// Morning: 4:00 AM to 12:00 PM (04:00 - 11:59), Evening: 12:00 PM to 11:59 PM (12:00 - 23:59)
function determineShiftFromTime(hhmm: string): 'Morning' | 'Evening' {
  const hour = Number((hhmm || '').split(':')[0]);
  if (!Number.isNaN(hour) && hour >= 4 && hour < 12) {
    return 'Morning';
  }
  return 'Evening';
}

function extractGymQrSecret(rawQr: string): string {
  const trimmed = (rawQr || '').trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('GFG-CHECKIN:')) {
    return trimmed.slice('GFG-CHECKIN:'.length).trim();
  }
  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed) as { app?: string; token?: string };
      if (parsed.token) return String(parsed.token).trim();
    } catch {
      // fall through
    }
  }
  return trimmed;
}

function getMemberPortalData(memberId: string) {
  const settingsRow = db.prepare('SELECT * FROM settings WHERE id = 1').get() as Record<string, unknown>;
  const safeSettings = {
    gymName: settingsRow.gymName,
    gymLogo: settingsRow.gymLogo,
    gymAddress: settingsRow.gymAddress,
    contactNumber: settingsRow.contactNumber,
    ownerName: settingsRow.ownerName,
    ownerMobile: settingsRow.ownerMobile,
    paymentMethods: JSON.parse((settingsRow.paymentMethods as string) || '["Cash","UPI"]'),
    theme: settingsRow.theme,
    language: settingsRow.language,
    ownerPin: '',
    receptionPin: '',
    trainerPin: '',
    gymQrSecret: '',
  };
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(memberId);
  const payments = db
    .prepare('SELECT * FROM payments WHERE memberId = ? ORDER BY paymentDate DESC, createdAt DESC')
    .all(memberId);
  const membershipHistory = db
    .prepare('SELECT * FROM membership_history WHERE memberId = ? ORDER BY createdAt DESC')
    .all(memberId);
  const attendance = db
    .prepare("SELECT * FROM attendance WHERE personType = 'member' AND personId = ? ORDER BY createdAt DESC")
    .all(memberId);
  const workoutPlans = db
    .prepare('SELECT * FROM workout_plans WHERE memberId = ? ORDER BY updatedAt DESC')
    .all(memberId);
  const dietPlans = db
    .prepare('SELECT * FROM diet_plans WHERE memberId = ? ORDER BY updatedAt DESC')
    .all(memberId);

  return {
    settings: safeSettings,
    members: member ? [member] : [],
    trainers: [],
    payments,
    membershipHistory,
    attendance,
    workoutPlans,
    dietPlans,
  };
}

// Public gym branding & theme for Login screen (does not leak member list or PINs)
app.get('/api/public-config', (_req, res) => {
  try {
    const settingsRow = db.prepare('SELECT * FROM settings WHERE id = 1').get() as Record<string, unknown>;
    const trainers = db
      .prepare('SELECT id, name, specialization FROM trainers ORDER BY createdAt ASC')
      .all();
    res.json({
      gymName: settingsRow.gymName,
      gymLogo: settingsRow.gymLogo,
      gymAddress: settingsRow.gymAddress,
      contactNumber: settingsRow.contactNumber,
      theme: settingsRow.theme,
      language: settingsRow.language,
      trainers,
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Bootstrap full state for Admin / Reception / Trainer
app.get('/api/bootstrap', (_req, res) => {
  try {
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Scoped portal data for logged-in Member (members can only view their own data)
app.get('/api/member-portal/:memberId', (req, res) => {
  try {
    const { memberId } = req.params;
    const member = db.prepare('SELECT id FROM members WHERE id = ?').get(memberId);
    if (!member) return res.status(404).json({ error: 'Member not found' });
    res.json(getMemberPortalData(memberId));
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Role-based login validation (strict PIN requirement for Admin/Reception/Trainer)
app.post('/api/auth/login', (req, res) => {
  try {
    const { role, pin, memberId, trainerId } = req.body as {
      role: 'owner' | 'reception' | 'trainer' | 'member';
      pin?: string;
      memberId?: string;
      trainerId?: string;
    };
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get() as Record<string, string>;

    if (role === 'owner') {
      if (!pin || pin.trim() !== settings.ownerPin) {
        return res.status(401).json({ error: 'Invalid Admin PIN' });
      }
      return res.json({ role: 'owner', userId: 'owner', displayName: settings.ownerName || 'Admin' });
    }
    if (role === 'reception') {
      if (!pin || pin.trim() !== settings.receptionPin) {
        return res.status(401).json({ error: 'Invalid Reception PIN' });
      }
      return res.json({ role: 'reception', userId: 'reception', displayName: 'Reception Desk' });
    }
    if (role === 'trainer') {
      const trainer = trainerId
        ? (db.prepare('SELECT * FROM trainers WHERE id = ?').get(trainerId) as Record<string, string> | undefined)
        : (db.prepare('SELECT * FROM trainers LIMIT 1').get() as Record<string, string> | undefined);
      if (!trainer) return res.status(404).json({ error: 'Trainer not found' });
      if (!pin || (pin.trim() !== trainer.pin && pin.trim() !== settings.trainerPin)) {
        return res.status(401).json({ error: 'Invalid Trainer PIN' });
      }
      return res.json({
        role: 'trainer',
        userId: trainer.id,
        trainerId: trainer.id,
        displayName: trainer.name,
      });
    }
    if (role === 'member') {
      const lookup = (memberId || '').trim();
      if (!lookup) {
        return res.status(400).json({ error: 'Enter your Member ID or Mobile Number' });
      }
      const member = db
        .prepare('SELECT id, name FROM members WHERE UPPER(id) = UPPER(?) OR whatsapp = ?')
        .get(lookup, lookup) as { id: string; name: string } | undefined;
      if (!member) {
        return res.status(404).json({ error: 'Member ID or Mobile Number not found' });
      }
      return res.json({
        role: 'member',
        userId: member.id,
        memberId: member.id,
        displayName: member.name,
      });
    }
    return res.status(400).json({ error: 'Invalid role' });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Create Member
app.post('/api/members', (req, res) => {
  try {
    const body = req.body;
    const nowISO = new Date().toISOString();
    const id = getNextMemberId();
    const qrToken = `GFG-QR-${id}`;
    const fee = Number(body.membershipFee) || 0;
    const discount = Number(body.discount) || 0;
    const paid = Number(body.amountPaid) || 0;
    const remaining = calcRemaining(fee, discount, paid);
    const membershipStatus = body.membershipStatus === 'Inactive' ? 'Inactive' : 'Active';

    const tx = db.transaction(() => {
      db.prepare(`
        INSERT INTO members (
          id, name, whatsapp, age, gender, address, joiningDate, photo,
          durationValue, durationUnit, startDate, expiryDate,
          membershipFee, discount, amountPaid, remainingAmount, paymentMethod,
          membershipStatus, trainerId, trainerName, notes, qrToken, createdAt, updatedAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        id,
        body.name || 'Unnamed Member',
        body.whatsapp || '',
        Number(body.age) || 24,
        body.gender || 'Male',
        body.address || '',
        body.joiningDate || nowISO.slice(0, 10),
        body.photo || '',
        Number(body.durationValue) || 1,
        body.durationUnit || 'months',
        body.startDate || nowISO.slice(0, 10),
        body.expiryDate || nowISO.slice(0, 10),
        fee,
        discount,
        paid,
        remaining,
        body.paymentMethod || 'Cash',
        membershipStatus,
        body.trainerId || '',
        body.trainerName || '',
        body.notes || '',
        qrToken,
        nowISO,
        nowISO
      );

      db.prepare(`
        INSERT INTO membership_history (
          id, memberId, actionType, durationValue, durationUnit,
          startDate, expiryDate, fee, discount, amountPaid, notes, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        makeId('HIST'),
        id,
        'new',
        Number(body.durationValue) || 1,
        body.durationUnit || 'months',
        body.startDate || nowISO.slice(0, 10),
        body.expiryDate || nowISO.slice(0, 10),
        fee,
        discount,
        paid,
        body.notes || 'New registration',
        nowISO
      );

      if (paid > 0) {
        db.prepare(`
          INSERT INTO payments (
            id, memberId, amount, discount, paymentMethod, paymentDate, type, notes, receiptNumber, createdAt
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          makeId('PAY'),
          id,
          paid,
          discount,
          body.paymentMethod || 'Cash',
          body.joiningDate || nowISO.slice(0, 10),
          'registration',
          `Registration fee (${body.durationValue || 1} ${body.durationUnit || 'months'})`,
          `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`,
          nowISO
        );
      }
    });

    tx();
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Update Member
app.put('/api/members/:id', (req, res) => {
  try {
    const { id } = req.params;
    const existing = db.prepare('SELECT * FROM members WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!existing) return res.status(404).json({ error: 'Member not found' });

    const body = req.body;
    const nowISO = new Date().toISOString();
    const fee = body.membershipFee !== undefined ? Number(body.membershipFee) : Number(existing.membershipFee);
    const discount = body.discount !== undefined ? Number(body.discount) : Number(existing.discount);
    const paid = body.amountPaid !== undefined ? Number(body.amountPaid) : Number(existing.amountPaid);
    const remaining = calcRemaining(fee, discount, paid);
    const membershipStatus =
      body.membershipStatus !== undefined
        ? body.membershipStatus === 'Inactive'
          ? 'Inactive'
          : 'Active'
        : (existing.membershipStatus as string) || 'Active';

    const tx = db.transaction(() => {
      db.prepare(`
        UPDATE members SET
          name = ?, whatsapp = ?, age = ?, gender = ?, address = ?, joiningDate = ?, photo = ?,
          durationValue = ?, durationUnit = ?, startDate = ?, expiryDate = ?,
          membershipFee = ?, discount = ?, amountPaid = ?, remainingAmount = ?, paymentMethod = ?,
          membershipStatus = ?, trainerId = ?, trainerName = ?, notes = ?, updatedAt = ?
        WHERE id = ?
      `).run(
        body.name ?? existing.name,
        body.whatsapp ?? existing.whatsapp,
        body.age !== undefined ? Number(body.age) : Number(existing.age),
        body.gender ?? existing.gender,
        body.address ?? existing.address,
        body.joiningDate ?? existing.joiningDate,
        body.photo ?? existing.photo,
        body.durationValue !== undefined ? Number(body.durationValue) : Number(existing.durationValue),
        body.durationUnit ?? existing.durationUnit,
        body.startDate ?? existing.startDate,
        body.expiryDate ?? existing.expiryDate,
        fee,
        discount,
        paid,
        remaining,
        body.paymentMethod ?? existing.paymentMethod,
        membershipStatus,
        body.trainerId ?? existing.trainerId,
        body.trainerName ?? existing.trainerName,
        body.notes ?? existing.notes,
        nowISO,
        id
      );

      if (
        Number(existing.membershipFee) !== fee ||
        Number(existing.discount) !== discount ||
        existing.expiryDate !== (body.expiryDate ?? existing.expiryDate)
      ) {
        db.prepare(`
          INSERT INTO membership_history (
            id, memberId, actionType, durationValue, durationUnit,
            startDate, expiryDate, fee, discount, amountPaid, notes, createdAt
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          makeId('HIST'),
          id,
          existing.expiryDate !== (body.expiryDate ?? existing.expiryDate) ? 'extension' : 'fee_update',
          body.durationValue !== undefined ? Number(body.durationValue) : Number(existing.durationValue),
          (body.durationUnit ?? existing.durationUnit) as string,
          (body.startDate ?? existing.startDate) as string,
          (body.expiryDate ?? existing.expiryDate) as string,
          fee,
          discount,
          paid,
          body.historyNote || 'Updated custom fee or expiry date',
          nowISO
        );
      }
    });

    tx();
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Delete Member
app.delete('/api/members/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('DELETE FROM attendance WHERE personType = ? AND personId = ?').run('member', id);
    db.prepare('DELETE FROM members WHERE id = ?').run(id);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Renew Membership (Custom Price, Custom Duration, Custom Expiry, Partial/Full Payment)
app.post('/api/members/:id/renew', (req, res) => {
  try {
    const { id } = req.params;
    const existing = db.prepare('SELECT * FROM members WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!existing) return res.status(404).json({ error: 'Member not found' });

    const {
      durationValue,
      durationUnit,
      startDate,
      expiryDate,
      membershipFee,
      discount,
      amountPaid,
      paymentMethod,
      paymentDate,
      carryPreviousBalance,
      notes,
    } = req.body;

    const nowISO = new Date().toISOString();
    const prevRemaining = carryPreviousBalance ? Number(existing.remainingAmount) || 0 : 0;
    const newFee = (Number(membershipFee) || 0) + prevRemaining;
    const newDiscount = Number(discount) || 0;
    const newPaid = Number(amountPaid) || 0;
    const remaining = calcRemaining(newFee, newDiscount, newPaid);
    const receiptNumber = `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`;

    const tx = db.transaction(() => {
      db.prepare(`
        UPDATE members SET
          durationValue = ?, durationUnit = ?, startDate = ?, expiryDate = ?,
          membershipFee = ?, discount = ?, amountPaid = ?, remainingAmount = ?,
          paymentMethod = ?, membershipStatus = 'Active', updatedAt = ?
        WHERE id = ?
      `).run(
        Number(durationValue) || 1,
        durationUnit || 'months',
        startDate,
        expiryDate,
        newFee,
        newDiscount,
        newPaid,
        remaining,
        paymentMethod || 'Cash',
        nowISO,
        id
      );

      db.prepare(`
        INSERT INTO membership_history (
          id, memberId, actionType, durationValue, durationUnit,
          startDate, expiryDate, fee, discount, amountPaid, notes, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        makeId('HIST'),
        id,
        'renewal',
        Number(durationValue) || 1,
        durationUnit || 'months',
        startDate,
        expiryDate,
        newFee,
        newDiscount,
        newPaid,
        notes || `Renewed for ${durationValue} ${durationUnit}`,
        nowISO
      );

      if (newPaid > 0) {
        db.prepare(`
          INSERT INTO payments (
            id, memberId, amount, discount, paymentMethod, paymentDate, type, notes, receiptNumber, createdAt
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          makeId('PAY'),
          id,
          newPaid,
          newDiscount,
          paymentMethod || 'Cash',
          paymentDate || nowISO.slice(0, 10),
          'renewal',
          notes || `Membership renewal (${durationValue} ${durationUnit})`,
          receiptNumber,
          nowISO
        );
      }
    });

    tx();
    res.json({ data: getAllData(), receiptNumber });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Record Payment (Partial / Full / Multiple Payments / Fee Adjustment)
app.post('/api/payments', (req, res) => {
  try {
    const {
      memberId,
      amount,
      discount,
      paymentMethod,
      paymentDate,
      type,
      notes,
      newMembershipFee,
    } = req.body;

    const member = db.prepare('SELECT * FROM members WHERE id = ?').get(memberId) as Record<string, unknown> | undefined;
    if (!member) return res.status(404).json({ error: 'Member not found' });

    const nowISO = new Date().toISOString();
    const payAmount = Number(amount) || 0;
    const extraDiscount = Number(discount) || 0;
    const updatedFee = newMembershipFee !== undefined ? Number(newMembershipFee) : Number(member.membershipFee);
    const updatedDiscount = Number(member.discount) + extraDiscount;
    const updatedPaid = Number(member.amountPaid) + payAmount;
    const remaining = calcRemaining(updatedFee, updatedDiscount, updatedPaid);
    const receiptNumber = `GFG-REC-${Math.floor(100000 + Math.random() * 899999)}`;

    const tx = db.transaction(() => {
      db.prepare(`
        UPDATE members SET
          membershipFee = ?, discount = ?, amountPaid = ?, remainingAmount = ?,
          paymentMethod = ?, updatedAt = ?
        WHERE id = ?
      `).run(
        updatedFee,
        updatedDiscount,
        updatedPaid,
        remaining,
        paymentMethod || member.paymentMethod,
        nowISO,
        memberId
      );

      db.prepare(`
        INSERT INTO payments (
          id, memberId, amount, discount, paymentMethod, paymentDate, type, notes, receiptNumber, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        makeId('PAY'),
        memberId,
        payAmount,
        extraDiscount,
        paymentMethod || 'Cash',
        paymentDate || nowISO.slice(0, 10),
        type || 'installment',
        notes || 'Fee payment',
        receiptNumber,
        nowISO
      );
    });

    tx();
    res.json({ data: getAllData(), receiptNumber });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Member QR Scanner Check-In / Check-Out (validates secure Gym QR Code)
app.post('/api/attendance/qr-scan', (req, res) => {
  try {
    const { memberId, qrCode, action = 'auto', clientDate, clientTime } = req.body as {
      memberId: string;
      qrCode: string;
      action?: 'auto' | 'entry' | 'exit';
      clientDate?: string;
      clientTime?: string;
    };

    if (!memberId) {
      return res.status(400).json({ error: 'Member ID is required' });
    }
    const member = db.prepare('SELECT id, name, membershipStatus FROM members WHERE id = ?').get(memberId) as
      | { id: string; name: string; membershipStatus: string }
      | undefined;
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const settings = db.prepare('SELECT gymQrSecret FROM settings WHERE id = 1').get() as { gymQrSecret: string };
    const scannedSecret = extractGymQrSecret(qrCode);
    if (!scannedSecret || scannedSecret !== settings.gymQrSecret) {
      return res.status(403).json({
        error: 'Invalid gym QR code. Please scan the official Golden Fitness Gym QR code at reception.',
      });
    }

    const nowMs = Date.now();
    const nowISO = new Date(nowMs).toISOString();
    const attDate = clientDate || getServerLocalDateISO();
    const attTime = clientTime || getServerLocalTimeHHMMSS();

    // Prevent duplicate scans within 10 seconds
    const latestScan = db
      .prepare('SELECT entryTimestamp, exitTimestamp, createdAt FROM attendance WHERE personType = ? AND personId = ? ORDER BY createdAt DESC LIMIT 1')
      .get('member', member.id) as { entryTimestamp?: string; exitTimestamp?: string; createdAt?: string } | undefined;
    if (latestScan) {
      const lastTs = Math.max(
        Date.parse(latestScan.entryTimestamp || latestScan.createdAt || '') || 0,
        Date.parse(latestScan.exitTimestamp || '') || 0
      );
      if (lastTs > 0 && nowMs - lastTs < 10000) {
        return res.status(429).json({
          error: 'Duplicate scan blocked. Please wait 10 seconds before scanning again.',
        });
      }
    }

    // Check for active open session (INSIDE GYM)
    const openVisit = db
      .prepare("SELECT * FROM attendance WHERE personType = 'member' AND personId = ? AND date = ? AND status = 'INSIDE GYM' ORDER BY createdAt DESC LIMIT 1")
      .get(member.id, attDate) as Record<string, unknown> | undefined;

    if (openVisit) {
      if (action === 'entry') {
        return res.status(409).json({
          error: 'Already checked in (INSIDE GYM). Scan or select EXIT when leaving.',
        });
      }
      const entryMs = Date.parse((openVisit.entryTimestamp as string) || (openVisit.createdAt as string)) || nowMs;
      const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));
      db.prepare(`
        UPDATE attendance
        SET exitTime = ?, exitTimestamp = ?, durationMinutes = ?, status = 'LEFT GYM'
        WHERE id = ?
      `).run(attTime, nowISO, durationMinutes, openVisit.id);

      return res.json({
        actionTaken: 'EXIT',
        durationMinutes,
        message: `EXIT recorded at ${attTime}. Status: LEFT GYM`,
        data: getMemberPortalData(member.id),
      });
    }

    if (action === 'exit') {
      return res.status(409).json({
        error: 'No active ENTRY found. Scan or select ENTRY first when entering the gym.',
      });
    }

    const attShift = determineShiftFromTime(attTime);
    const id = makeId('ATT');
    db.prepare(`
      INSERT INTO attendance (
        id, personType, personId, date, entryTime, exitTime, entryTimestamp, exitTimestamp,
        durationMinutes, status, shift, method, createdAt
      ) VALUES (?, 'member', ?, ?, ?, '', ?, '', 0, 'INSIDE GYM', ?, 'QR', ?)
    `).run(id, member.id, attDate, attTime, nowISO, attShift, nowISO);

    return res.json({
      actionTaken: 'ENTRY',
      shift: attShift,
      message: `ENTRY recorded (${attShift} session) at ${attTime}. Status: INSIDE GYM`,
      data: getMemberPortalData(member.id),
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Admin / Reception / Trainer Attendance (Entry, Exit, or Auto toggle)
app.post('/api/attendance', (req, res) => {
  try {
    const { personType = 'member', personIdOrToken, date, entryTime, shift, method, action = 'auto' } = req.body as {
      personType?: 'member' | 'trainer';
      personIdOrToken: string;
      date?: string;
      entryTime?: string;
      shift?: 'Morning' | 'Evening';
      method?: 'QR' | 'Manual';
      action?: 'auto' | 'entry' | 'exit';
    };
    const nowMs = Date.now();
    const nowISO = new Date(nowMs).toISOString();

    let resolvedId = personIdOrToken;
    if (personType === 'member') {
      const m = db
        .prepare('SELECT id, name FROM members WHERE UPPER(id) = UPPER(?) OR qrToken = ? OR whatsapp = ?')
        .get(personIdOrToken, personIdOrToken, personIdOrToken) as { id: string; name: string } | undefined;
      if (!m) {
        return res.status(404).json({ error: 'Member ID, mobile, or QR token not recognized' });
      }
      resolvedId = m.id;
    } else {
      const t = db.prepare('SELECT id FROM trainers WHERE id = ?').get(personIdOrToken) as { id: string } | undefined;
      if (!t) return res.status(404).json({ error: 'Trainer not found' });
      resolvedId = t.id;
    }

    const attDate = date || getServerLocalDateISO();
    const attTime = entryTime || getServerLocalTimeHHMMSS();

    // Prevent accidental duplicate clicks/scans within 10 seconds
    const latestScan = db
      .prepare('SELECT entryTimestamp, exitTimestamp, createdAt FROM attendance WHERE personType = ? AND personId = ? ORDER BY createdAt DESC LIMIT 1')
      .get(personType, resolvedId) as { entryTimestamp?: string; exitTimestamp?: string; createdAt?: string } | undefined;
    if (latestScan) {
      const lastTs = Math.max(
        Date.parse(latestScan.entryTimestamp || latestScan.createdAt || '') || 0,
        Date.parse(latestScan.exitTimestamp || '') || 0
      );
      if (lastTs > 0 && nowMs - lastTs < 10000) {
        return res.status(429).json({
          error: 'Duplicate scan ignored. Please wait 10 seconds before scanning again.',
        });
      }
    }

    const openVisit = db
      .prepare("SELECT * FROM attendance WHERE personType = ? AND personId = ? AND date = ? AND status = 'INSIDE GYM' ORDER BY createdAt DESC LIMIT 1")
      .get(personType, resolvedId, attDate) as Record<string, unknown> | undefined;

    if (openVisit) {
      if (action === 'entry') {
        return res.status(409).json({
          error: 'Already INSIDE GYM. Record EXIT before starting a new visit.',
        });
      }
      const entryMs = Date.parse((openVisit.entryTimestamp as string) || (openVisit.createdAt as string)) || nowMs;
      const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));
      db.prepare(`
        UPDATE attendance
        SET exitTime = ?, exitTimestamp = ?, durationMinutes = ?, status = 'LEFT GYM'
        WHERE id = ?
      `).run(attTime, nowISO, durationMinutes, openVisit.id);
      return res.json(getAllData());
    }

    if (action === 'exit') {
      return res.status(409).json({ error: 'No active ENTRY session found to mark EXIT.' });
    }

    const attShift = shift || determineShiftFromTime(attTime);
    db.prepare(`
      INSERT INTO attendance (
        id, personType, personId, date, entryTime, exitTime, entryTimestamp, exitTimestamp,
        durationMinutes, status, shift, method, createdAt
      ) VALUES (?, ?, ?, ?, ?, '', ?, '', 0, 'INSIDE GYM', ?, ?, ?)
    `).run(
      makeId('ATT'),
      personType,
      resolvedId,
      attDate,
      attTime,
      nowISO,
      attShift,
      method || 'Manual',
      nowISO
    );

    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Direct Exit button on an active attendance record
app.post('/api/attendance/:id/exit', (req, res) => {
  try {
    const { id } = req.params;
    const { exitTime } = (req.body || {}) as { exitTime?: string };
    const row = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!row) return res.status(404).json({ error: 'Attendance record not found' });
    if (row.status === 'LEFT GYM') {
      return res.status(409).json({ error: 'EXIT already recorded for this session' });
    }
    const nowMs = Date.now();
    const nowISO = new Date(nowMs).toISOString();
    const outTime = exitTime || getServerLocalTimeHHMMSS();
    const entryMs = Date.parse((row.entryTimestamp as string) || (row.createdAt as string)) || nowMs;
    const durationMinutes = Math.max(0, Math.round((nowMs - entryMs) / 60000));

    db.prepare(`
      UPDATE attendance
      SET exitTime = ?, exitTimestamp = ?, durationMinutes = ?, status = 'LEFT GYM'
      WHERE id = ?
    `).run(outTime, nowISO, durationMinutes, id);

    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Regenerate Secure Gym QR Code
app.post('/api/settings/regenerate-qr', (_req, res) => {
  try {
    const nextSecret = generateGymQrSecret();
    db.prepare('UPDATE settings SET gymQrSecret = ? WHERE id = 1').run(nextSecret);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Trainers CRUD
app.post('/api/trainers', (req, res) => {
  try {
    const { name, mobile, photo, specialization, pin } = req.body;
    const nowISO = new Date().toISOString();
    const id = makeId('TRN');
    db.prepare(`
      INSERT INTO trainers (id, name, mobile, photo, specialization, pin, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, mobile || '', photo || '', specialization || 'General Fitness', pin || '3333', nowISO);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.put('/api/trainers/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, mobile, photo, specialization, pin } = req.body;
    db.prepare(`
      UPDATE trainers SET name = ?, mobile = ?, photo = ?, specialization = ?, pin = ? WHERE id = ?
    `).run(name, mobile, photo || '', specialization || '', pin || '3333', id);
    db.prepare('UPDATE members SET trainerName = ? WHERE trainerId = ?').run(name, id);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.delete('/api/trainers/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('UPDATE members SET trainerId = ?, trainerName = ? WHERE trainerId = ?').run('', '', id);
    db.prepare('DELETE FROM attendance WHERE personType = ? AND personId = ?').run('trainer', id);
    db.prepare('DELETE FROM trainers WHERE id = ?').run(id);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Workout Plans
app.post('/api/workout-plans', (req, res) => {
  try {
    const { memberId, trainerId, muscleGroup, exerciseName, sets, reps, restTime, workoutDays, notes } = req.body;
    const nowISO = new Date().toISOString();
    db.prepare(`
      INSERT INTO workout_plans (id, memberId, trainerId, muscleGroup, exerciseName, sets, reps, restTime, workoutDays, notes, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      makeId('WP'),
      memberId,
      trainerId || '',
      muscleGroup || 'Chest',
      exerciseName,
      sets || '3',
      reps || '12',
      restTime || '60s',
      workoutDays || 'Mon / Thu',
      notes || '',
      nowISO
    );
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.delete('/api/workout-plans/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM workout_plans WHERE id = ?').run(req.params.id);
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Diet Plans (Upsert per member)
app.post('/api/diet-plans', (req, res) => {
  try {
    const { memberId, trainerId, breakfast, lunch, dinner, snacks, mealDetails, trainerNotes } = req.body;
    const nowISO = new Date().toISOString();
    const existing = db.prepare('SELECT id FROM diet_plans WHERE memberId = ?').get(memberId) as { id: string } | undefined;

    if (existing) {
      db.prepare(`
        UPDATE diet_plans SET
          trainerId = ?, breakfast = ?, lunch = ?, dinner = ?, snacks = ?,
          mealDetails = ?, trainerNotes = ?, updatedAt = ?
        WHERE memberId = ?
      `).run(trainerId || '', breakfast || '', lunch || '', dinner || '', snacks || '', mealDetails || '', trainerNotes || '', nowISO, memberId);
    } else {
      db.prepare(`
        INSERT INTO diet_plans (id, memberId, trainerId, breakfast, lunch, dinner, snacks, mealDetails, trainerNotes, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(makeId('DP'), memberId, trainerId || '', breakfast || '', lunch || '', dinner || '', snacks || '', mealDetails || '', trainerNotes || '', nowISO);
    }
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Settings
app.put('/api/settings', (req, res) => {
  try {
    const body = req.body;
    const existing = db.prepare('SELECT gymQrSecret FROM settings WHERE id = 1').get() as { gymQrSecret: string };
    db.prepare(`
      UPDATE settings SET
        gymName = ?, gymLogo = ?, gymAddress = ?, contactNumber = ?,
        ownerName = ?, ownerMobile = ?, paymentMethods = ?,
        theme = ?, language = ?, ownerPin = ?, receptionPin = ?, trainerPin = ?, gymQrSecret = ?
      WHERE id = 1
    `).run(
      body.gymName || 'Golden Fitness Gym',
      body.gymLogo || '/src/assets/images/gym_club_logo_1795080326591.jpg',
      body.gymAddress || '',
      body.contactNumber || '',
      body.ownerName || '',
      body.ownerMobile || '',
      JSON.stringify(body.paymentMethods || ['Cash', 'UPI']),
      body.theme || 'dark',
      body.language || 'en',
      body.ownerPin || '1234',
      body.receptionPin || '2222',
      body.trainerPin || '3333',
      body.gymQrSecret || existing?.gymQrSecret || generateGymQrSecret()
    );
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Backup & Restore
app.get('/api/backup', (_req, res) => {
  try {
    res.json({
      exportedAt: new Date().toISOString(),
      app: 'Golden Fitness Gym',
      data: getAllData(),
    });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/api/restore', (req, res) => {
  try {
    const payload = req.body?.data || req.body;
    if (!payload || !Array.isArray(payload.members)) {
      return res.status(400).json({ error: 'Invalid backup file format' });
    }

    const tx = db.transaction(() => {
      db.prepare('DELETE FROM workout_plans').run();
      db.prepare('DELETE FROM diet_plans').run();
      db.prepare('DELETE FROM attendance').run();
      db.prepare('DELETE FROM payments').run();
      db.prepare('DELETE FROM membership_history').run();
      db.prepare('DELETE FROM members').run();
      db.prepare('DELETE FROM trainers').run();

      if (payload.settings) {
        const s = payload.settings;
        db.prepare(`
          UPDATE settings SET
            gymName = ?, gymLogo = ?, gymAddress = ?, contactNumber = ?,
            ownerName = ?, ownerMobile = ?, paymentMethods = ?,
            theme = ?, language = ?, ownerPin = ?, receptionPin = ?, trainerPin = ?, gymQrSecret = ?
          WHERE id = 1
        `).run(
          s.gymName || 'Golden Fitness Gym',
          s.gymLogo || '',
          s.gymAddress || '',
          s.contactNumber || '',
          s.ownerName || '',
          s.ownerMobile || '',
          JSON.stringify(s.paymentMethods || ['Cash', 'UPI']),
          s.theme || 'dark',
          s.language || 'en',
          s.ownerPin || '1234',
          s.receptionPin || '2222',
          s.trainerPin || '3333',
          s.gymQrSecret || generateGymQrSecret()
        );
      }

      const insT = db.prepare('INSERT INTO trainers (id, name, mobile, photo, specialization, pin, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)');
      for (const t of payload.trainers || []) {
        insT.run(t.id, t.name, t.mobile || '', t.photo || '', t.specialization || '', t.pin || '3333', t.createdAt || new Date().toISOString());
      }

      const insM = db.prepare(`
        INSERT INTO members (
          id, name, whatsapp, age, gender, address, joiningDate, photo,
          durationValue, durationUnit, startDate, expiryDate,
          membershipFee, discount, amountPaid, remainingAmount, paymentMethod,
          membershipStatus, trainerId, trainerName, notes, qrToken, createdAt, updatedAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const m of payload.members || []) {
        insM.run(
          m.id, m.name, m.whatsapp || '', Number(m.age) || 24, m.gender || 'Male', m.address || '', m.joiningDate, m.photo || '',
          Number(m.durationValue) || 1, m.durationUnit || 'months', m.startDate, m.expiryDate,
          Number(m.membershipFee) || 0, Number(m.discount) || 0, Number(m.amountPaid) || 0, Number(m.remainingAmount) || 0, m.paymentMethod || 'Cash',
          m.membershipStatus === 'Inactive' ? 'Inactive' : 'Active',
          m.trainerId || '', m.trainerName || '', m.notes || '', m.qrToken || `GFG-QR-${m.id}`, m.createdAt || new Date().toISOString(), m.updatedAt || new Date().toISOString()
        );
      }

      const insP = db.prepare('INSERT INTO payments (id, memberId, amount, discount, paymentMethod, paymentDate, type, notes, receiptNumber, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
      for (const p of payload.payments || []) {
        insP.run(p.id, p.memberId, Number(p.amount) || 0, Number(p.discount) || 0, p.paymentMethod || 'Cash', p.paymentDate, p.type || 'installment', p.notes || '', p.receiptNumber || 'GFG-REC', p.createdAt || new Date().toISOString());
      }

      const insH = db.prepare('INSERT INTO membership_history (id, memberId, actionType, durationValue, durationUnit, startDate, expiryDate, fee, discount, amountPaid, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
      for (const h of payload.membershipHistory || []) {
        insH.run(h.id, h.memberId, h.actionType || 'new', Number(h.durationValue) || 1, h.durationUnit || 'months', h.startDate, h.expiryDate, Number(h.fee) || 0, Number(h.discount) || 0, Number(h.amountPaid) || 0, h.notes || '', h.createdAt || new Date().toISOString());
      }

      const insA = db.prepare(`
        INSERT INTO attendance (
          id, personType, personId, date, entryTime, exitTime, entryTimestamp, exitTimestamp,
          durationMinutes, status, shift, method, createdAt
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const a of payload.attendance || []) {
        insA.run(
          a.id,
          a.personType || 'member',
          a.personId,
          a.date,
          a.entryTime,
          a.exitTime || '',
          a.entryTimestamp || a.createdAt || new Date().toISOString(),
          a.exitTimestamp || '',
          Number(a.durationMinutes) || 0,
          a.status || (a.exitTime ? 'LEFT GYM' : 'INSIDE GYM'),
          a.shift || 'Morning',
          a.method || 'Manual',
          a.createdAt || new Date().toISOString()
        );
      }

      const insW = db.prepare('INSERT INTO workout_plans (id, memberId, trainerId, muscleGroup, exerciseName, sets, reps, restTime, workoutDays, notes, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
      for (const w of payload.workoutPlans || []) {
        insW.run(w.id, w.memberId, w.trainerId || '', w.muscleGroup, w.exerciseName, w.sets, w.reps, w.restTime, w.workoutDays, w.notes || '', w.updatedAt || new Date().toISOString());
      }

      const insD = db.prepare('INSERT INTO diet_plans (id, memberId, trainerId, breakfast, lunch, dinner, snacks, mealDetails, trainerNotes, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
      for (const d of payload.dietPlans || []) {
        insD.run(d.id, d.memberId, d.trainerId || '', d.breakfast || '', d.lunch || '', d.dinner || '', d.snacks || '', d.mealDetails || '', d.trainerNotes || '', d.updatedAt || new Date().toISOString());
      }
    });

    tx();
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Reset All Gym Data (keeps settings intact, clears all members, trainers, attendance, payments, workouts, diet plans)
app.post('/api/reset', (_req, res) => {
  try {
    resetAllGymData();
    res.json(getAllData());
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// Export Complete Project Source Code (.zip) for Android APK Conversion
app.get('/api/export-source', (_req, res) => {
  try {
    const { buffer } = buildProjectSourceZip(process.cwd());
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="golden-fitness-gym-android-source.zip"');
    res.setHeader('Content-Length', String(buffer.length));
    res.setHeader('Cache-Control', 'no-store');
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

async function startServer() {
  const distPath = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distPath);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Golden Fitness Gym server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
