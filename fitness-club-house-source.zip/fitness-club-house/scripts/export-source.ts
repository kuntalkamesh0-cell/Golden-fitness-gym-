import fs from 'fs';
import path from 'path';
import { buildProjectSourceZip } from '../server/sourceExporter.ts';

const outFile = path.resolve(process.cwd(), 'fitness-club-house-source.zip');
const { buffer, fileCount } = buildProjectSourceZip(process.cwd());
fs.writeFileSync(outFile, buffer);

const sizeKB = (buffer.length / 1024).toFixed(1);
console.log(`Exported ${fileCount} project files to ${outFile} (${sizeKB} KB)`);
