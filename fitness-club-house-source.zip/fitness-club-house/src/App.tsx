import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Home,
  Users,
  QrCode,
  IndianRupee,
  Settings,
  RefreshCw,
  Dumbbell,
  UserCheck,
  BarChart3,
  AlertTriangle,
  LogOut,
  Plus,
} from 'lucide-react';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import type {
  AttendanceMethod,
  AttendanceShift,
  AuthSession,
  CloudSyncMeta,
  DietPlan,
  DurationUnit,
  GymDataPayload,
  GymSettings,
  Language,
  Member,
  Trainer,
  WorkoutPlanItem,
} from './types';
import { auth } from './firebase';
import {
  addWorkoutToCloud,
  collectPaymentInCloud,
  deleteMemberFromCloud,
  deleteTrainerFromCloud,
  deleteWorkoutFromCloud,
  ensureOwnerDocument,
  markAttendanceInCloud,
  markExitInCloud,
  migrateLocalDataToCloud,
  regenerateGymQrInCloud,
  renewMembershipInCloud,
  resetAllCloudData,
  restoreBackupToCloud,
  saveDietToCloud,
  saveMemberToCloud,
  saveSettingsToCloud,
  saveTrainerToCloud,
  scanGymQrInCloud,
  subscribeToOwnerCloudData,
  triggerCloudBackupNow,
} from './services/firestoreSync';
import { useT } from './i18n/translations';
import { getCurrentTimeHHMMSS, getShiftForTime, getTodayISO } from './utils/gymHelpers';
import { Avatar } from './components/Avatar';
import { FirebaseAuthGate } from './components/FirebaseAuthGate';
import { LoginGate } from './components/LoginGate';
import { CloudSyncBadge } from './components/CloudSyncBadge';
import { DashboardView } from './components/DashboardView';
import { MembersView } from './components/MembersView';
import { MemberFormModal } from './components/MemberFormModal';
import { MemberProfileModal } from './components/MemberProfileModal';
import { AttendanceView } from './components/AttendanceView';
import { FeesView } from './components/FeesView';
import { RenewalsView } from './components/RenewalsView';
import { WorkoutsDietView } from './components/WorkoutsDietView';
import { TrainersView } from './components/TrainersView';
import { ReportsInactiveView } from './components/ReportsInactiveView';
import { SettingsView } from './components/SettingsView';
import { MemberPortalView } from './components/MemberPortalView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';

const CACHE_KEY = 'gfg_cached_data_v2';
const SESSION_KEY = 'gfg_auth_session_v1';
const PUBLIC_LANG_KEY = 'gfg_public_language_v1';

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [cloudError, setCloudError] = useState<Error | null>(null);

  const [publicLanguage, setPublicLanguage] = useState<Language>(() => {
    try {
      return localStorage.getItem(PUBLIC_LANG_KEY) === 'hi' ? 'hi' : 'en';
    } catch {
      return 'en';
    }
  });

  const [session, setSession] = useState<AuthSession | null>(() => {
    try {
      const saved = localStorage.getItem(SESSION_KEY);
      return saved ? (JSON.parse(saved) as AuthSession) : null;
    } catch {
      return null;
    }
  });

  const [data, setData] = useState<GymDataPayload | null>(null);
  const [syncMeta, setSyncMeta] = useState<CloudSyncMeta>({
    status: typeof navigator !== 'undefined' && !navigator.onLine ? 'offline' : 'syncing',
    lastBackupAt: '',
    hasPendingWrites: false,
    fromCache: false,
  });

  const [activeTab, setActiveTab] = useState<string>('home');
  const [loadingCloud, setLoadingCloud] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const migratedUidRef = useRef<string | null>(null);

  // Modals & Cross-tab Selections
  const [memberModalOpen, setMemberModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [selectedProfileMemberId, setSelectedProfileMemberId] = useState<string | null>(null);
  const [feePreselectedMember, setFeePreselectedMember] = useState<Member | null>(null);

  if (cloudError) {
    throw cloudError;
  }

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  }, []);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setAuthReady(true);
      if (!user) {
        setData(null);
        setLoadingCloud(false);
        migratedUidRef.current = null;
      }
    });
    return unsub;
  }, []);

  // Connect real-time Cloud Firestore subscription & migrate local records safely once per login
  useEffect(() => {
    if (!firebaseUser) return;

    let cancelled = false;
    let unsubFirestore: (() => void) | null = null;
    setLoadingCloud(true);

    const startSync = async () => {
      try {
        await ensureOwnerDocument(firebaseUser);
        if (cancelled) return;

        unsubFirestore = subscribeToOwnerCloudData(
          firebaseUser,
          (payload, meta) => {
            if (cancelled) return;
            setData(payload);
            setSyncMeta(meta);
            setLoadingCloud(false);
            try {
              localStorage.setItem(CACHE_KEY, JSON.stringify(payload));
            } catch {
              // ignore quota
            }
          },
          (err) => {
            if (!cancelled) setCloudError(err);
          }
        );

        if (migratedUidRef.current !== firebaseUser.uid) {
          migratedUidRef.current = firebaseUser.uid;
          const res = await migrateLocalDataToCloud(firebaseUser);
          if (!cancelled && res.migratedCount > 0) {
            showToast(`Synced ${res.migratedCount} local records to Cloud Firestore`);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setLoadingCloud(false);
          setCloudError(err as Error);
        }
      }
    };

    void startSync();

    return () => {
      cancelled = true;
      unsubFirestore?.();
    };
  }, [firebaseUser, showToast]);

  // Keep persisted role session valid against live cloud members/trainers
  useEffect(() => {
    if (!data || !session) return;
    if (session.role === 'member' && session.memberId) {
      if (!data.members.some((m) => m.id === session.memberId)) {
        setSession(null);
        localStorage.removeItem(SESSION_KEY);
      }
    } else if (session.role === 'trainer' && session.trainerId) {
      if (!data.trainers.some((tr) => tr.id === session.trainerId)) {
        setSession(null);
        localStorage.removeItem(SESSION_KEY);
      }
    }
  }, [data, session]);

  // Apply Dark / Light theme cleanly to <html>
  const activeTheme = data?.settings.theme || 'dark';
  useEffect(() => {
    document.documentElement.classList.toggle('dark', activeTheme === 'dark');
  }, [activeTheme]);

  const language: Language = data?.settings.language || publicLanguage;
  const t = useT(language);

  const handleLogin = (nextSession: AuthSession) => {
    setSession(nextSession);
    localStorage.setItem(SESSION_KEY, JSON.stringify(nextSession));
    if (nextSession.role === 'trainer') setActiveTab('workouts');
    else setActiveTab('home');
  };

  const handleSwitchRole = () => {
    setSession(null);
    setSelectedProfileMemberId(null);
    setFeePreselectedMember(null);
    setEditingMember(null);
    localStorage.removeItem(SESSION_KEY);
  };

  const handleCloudSignOut = async () => {
    setSession(null);
    setData(null);
    setSelectedProfileMemberId(null);
    setFeePreselectedMember(null);
    setEditingMember(null);
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(CACHE_KEY);
    await signOut(auth);
  };

  const handleTogglePublicLanguage = async () => {
    const nextLang: Language = language === 'en' ? 'hi' : 'en';
    setPublicLanguage(nextLang);
    localStorage.setItem(PUBLIC_LANG_KEY, nextLang);
    if (data && firebaseUser) {
      await saveSettingsToCloud(firebaseUser.uid, { ...data.settings, language: nextLang });
    }
  };

  // Cloud Firestore Mutations
  const handleSaveSettings = async (next: GymSettings) => {
    if (!firebaseUser) return;
    await saveSettingsToCloud(firebaseUser.uid, next);
    showToast('Settings saved to Cloud Firestore');
  };

  const handleRegenerateGymQr = async () => {
    if (!firebaseUser) return;
    await regenerateGymQrInCloud(firebaseUser.uid);
    showToast('New secure gym QR generated');
  };

  const handleSaveMember = async (payload: Partial<Member>, editingId?: string) => {
    if (!firebaseUser || !data) return;
    await saveMemberToCloud(firebaseUser.uid, payload, data.members, editingId);
    showToast(editingId ? 'Member updated in cloud' : 'Member registered in cloud');
  };

  const handleDeleteMember = async (id: string) => {
    if (!firebaseUser || !data) return;
    await deleteMemberFromCloud(firebaseUser.uid, id, data);
    showToast('Member deleted');
  };

  const handleCollectPayment = async (payload: {
    memberId: string;
    amount: number;
    discount: number;
    paymentMethod: string;
    paymentDate: string;
    notes: string;
    newMembershipFee?: number;
  }) => {
    if (!firebaseUser || !data) throw new Error('Cloud session not ready');
    const member = data.members.find((m) => m.id === payload.memberId);
    if (!member) throw new Error('Member not found');
    const result = await collectPaymentInCloud(firebaseUser.uid, member, payload);
    showToast(`Receipt ${result.receiptNumber} saved to cloud`);
    return result;
  };

  const handleRenewMembership = async (
    memberId: string,
    payload: {
      durationValue: number;
      durationUnit: DurationUnit;
      startDate: string;
      expiryDate: string;
      membershipFee: number;
      discount: number;
      amountPaid: number;
      paymentMethod: string;
      paymentDate: string;
      carryPreviousBalance: boolean;
      notes: string;
    }
  ) => {
    if (!firebaseUser || !data) return;
    const member = data.members.find((m) => m.id === memberId);
    if (!member) throw new Error('Member not found');
    await renewMembershipInCloud(firebaseUser.uid, member, payload);
    showToast('Membership renewed & synced');
  };

  const handleMarkAttendance = async (payload: {
    personType: 'member' | 'trainer';
    personIdOrToken: string;
    date: string;
    entryTime: string;
    shift: AttendanceShift;
    method: AttendanceMethod;
    action?: 'auto' | 'entry' | 'exit';
  }) => {
    if (!firebaseUser || !data) return;
    await markAttendanceInCloud(firebaseUser.uid, data, payload);
    showToast('Attendance synced');
  };

  const handleMarkExit = async (attendanceId: string) => {
    if (!firebaseUser || !data) return;
    const rec = data.attendance.find((a) => a.id === attendanceId);
    if (!rec) throw new Error('Attendance record not found');
    await markExitInCloud(firebaseUser.uid, rec);
    showToast('EXIT recorded · Status: LEFT GYM');
  };

  const handleMemberScanGymQr = async (payload: {
    memberId: string;
    qrCode: string;
    action: 'auto' | 'entry' | 'exit';
    clientDate: string;
    clientTime: string;
  }) => {
    if (!firebaseUser || !data) throw new Error('Cloud session not ready');
    const res = await scanGymQrInCloud(firebaseUser.uid, data, payload);
    showToast(res.message);
    return res;
  };

  const handleSaveTrainer = async (payload: Partial<Trainer>, id?: string) => {
    if (!firebaseUser || !data) return;
    await saveTrainerToCloud(firebaseUser.uid, payload, data.members, id);
    showToast('Trainer saved to cloud');
  };

  const handleDeleteTrainer = async (id: string) => {
    if (!firebaseUser || !data) return;
    await deleteTrainerFromCloud(firebaseUser.uid, id, data);
    showToast('Trainer removed');
  };

  const handleAddWorkout = async (payload: Omit<WorkoutPlanItem, 'id' | 'updatedAt'>) => {
    if (!firebaseUser) return;
    await addWorkoutToCloud(firebaseUser.uid, payload);
    showToast('Exercise added');
  };

  const handleDeleteWorkout = async (id: string) => {
    if (!firebaseUser) return;
    await deleteWorkoutFromCloud(firebaseUser.uid, id);
  };

  const handleSaveDiet = async (payload: Omit<DietPlan, 'id' | 'updatedAt'>) => {
    if (!firebaseUser || !data) return;
    await saveDietToCloud(firebaseUser.uid, data.dietPlans, payload);
    showToast('Diet plan saved');
  };

  const handleRestoreBackup = async (json: unknown) => {
    if (!firebaseUser || !data) return;
    await restoreBackupToCloud(firebaseUser.uid, data, json);
    showToast('Backup restored to Cloud Firestore');
  };

  const handleResetAllData = async () => {
    if (!firebaseUser || !data) return;
    await resetAllCloudData(firebaseUser.uid, data);
    setSelectedProfileMemberId(null);
    setFeePreselectedMember(null);
    setEditingMember(null);
    showToast('All gym data cleared from cloud');
  };

  const handleTriggerBackupNow = async () => {
    if (!firebaseUser) throw new Error('Not signed in');
    const res = await triggerCloudBackupNow(firebaseUser.uid);
    showToast(
      res.offlineQueued
        ? 'Offline — saved locally & queued for sync'
        : 'Cloud backup successful!'
    );
    return res;
  };

  const selectedProfileMember = useMemo(
    () => data?.members.find((m) => m.id === selectedProfileMemberId) || null,
    [data?.members, selectedProfileMemberId]
  );

  const visibleMembers = useMemo(() => {
    if (!data) return [];
    if (session?.role === 'trainer' && session.trainerId) {
      const assigned = data.members.filter((m) => m.trainerId === session.trainerId);
      return assigned.length > 0 ? assigned : data.members;
    }
    return data.members;
  }, [data, session]);

  // 1. Wait for Firebase Auth initialization
  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#09090B] text-white flex flex-col items-center justify-center gap-3">
        <div className="w-12 h-12 rounded-2xl border-2 border-[#F5B700] border-t-transparent animate-spin" />
        <p className="font-display text-sm text-zinc-400">Connecting to Golden Fitness Gym...</p>
      </div>
    );
  }

  // 2. Require Firebase Owner Login / Sign Up / Forgot Password
  if (!firebaseUser) {
    return (
      <FirebaseAuthGate
        language={publicLanguage}
        onToggleLanguage={handleTogglePublicLanguage}
      />
    );
  }

  // 3. Loading Owner Cloud Firestore Workspace
  if (loadingCloud || !data) {
    return (
      <div className="min-h-screen bg-[#09090B] text-white flex flex-col items-center justify-center gap-3">
        <div className="w-12 h-12 rounded-2xl border-2 border-[#F5B700] border-t-transparent animate-spin" />
        <p className="font-display text-sm text-zinc-400">
          Syncing your Cloud Gym Database...
        </p>
      </div>
    );
  }

  // 4. Role Switcher / PIN Gate within the signed-in owner's cloud gym
  if (!session) {
    return (
      <LoginGate
        settings={data.settings}
        trainers={data.trainers}
        members={data.members}
        cloudEmail={firebaseUser.email || ''}
        syncStatus={syncMeta.status}
        language={language}
        onToggleLanguage={handleTogglePublicLanguage}
        onLoginSuccess={handleLogin}
        onCloudSignOut={handleCloudSignOut}
      />
    );
  }

  // Navigation items gated by Role (Members NEVER see Admin modules)
  const allNavItems = [
    { id: 'home', label: t('navHome'), icon: <Home className="w-5 h-5" />, roles: ['owner', 'reception'] },
    { id: 'members', label: t('navMembers'), icon: <Users className="w-5 h-5" />, roles: ['owner', 'reception', 'trainer'] },
    { id: 'attendance', label: t('navAttendance'), icon: <QrCode className="w-5 h-5" />, roles: ['owner', 'reception', 'trainer'] },
    { id: 'fees', label: t('navFees'), icon: <IndianRupee className="w-5 h-5" />, roles: ['owner', 'reception'] },
    { id: 'renewals', label: t('navRenewals'), icon: <RefreshCw className="w-5 h-5" />, roles: ['owner', 'reception'] },
    { id: 'workouts', label: t('navWorkouts'), icon: <Dumbbell className="w-5 h-5" />, roles: ['owner', 'trainer'] },
    { id: 'trainers', label: t('navTrainers'), icon: <UserCheck className="w-5 h-5" />, roles: ['owner'] },
    { id: 'inactive', label: t('navInactive'), icon: <AlertTriangle className="w-5 h-5" />, roles: ['owner', 'reception'] },
    { id: 'reports', label: t('navReports'), icon: <BarChart3 className="w-5 h-5" />, roles: ['owner'] },
    { id: 'settings', label: t('navSettings'), icon: <Settings className="w-5 h-5" />, roles: ['owner'] },
  ];

  const sidebarItems = allNavItems.filter((item) => item.roles.includes(session.role));

  const mobileBottomNav =
    session.role === 'owner'
      ? [
          { id: 'home', label: t('navHome'), icon: <Home className="w-5 h-5" /> },
          { id: 'members', label: t('navMembers'), icon: <Users className="w-5 h-5" /> },
          { id: 'attendance', label: t('navAttendance'), icon: <QrCode className="w-5 h-5" /> },
          { id: 'fees', label: t('navFees'), icon: <IndianRupee className="w-5 h-5" /> },
          { id: 'settings', label: t('navSettings'), icon: <Settings className="w-5 h-5" /> },
        ]
      : session.role === 'reception'
      ? [
          { id: 'home', label: t('navHome'), icon: <Home className="w-5 h-5" /> },
          { id: 'members', label: t('navMembers'), icon: <Users className="w-5 h-5" /> },
          { id: 'attendance', label: t('navAttendance'), icon: <QrCode className="w-5 h-5" /> },
          { id: 'fees', label: t('navFees'), icon: <IndianRupee className="w-5 h-5" /> },
          { id: 'renewals', label: t('navRenewals'), icon: <RefreshCw className="w-5 h-5" /> },
        ]
      : session.role === 'trainer'
      ? [
          { id: 'workouts', label: t('navWorkouts'), icon: <Dumbbell className="w-5 h-5" /> },
          { id: 'members', label: t('navMembers'), icon: <Users className="w-5 h-5" /> },
          { id: 'attendance', label: t('navAttendance'), icon: <QrCode className="w-5 h-5" /> },
        ]
      : [];

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-[#09090B] text-zinc-900 dark:text-zinc-100 flex">
      {/* Desktop Sidebar (Admin / Reception / Trainer only) */}
      {session.role !== 'member' && (
        <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#0D0D11] p-4 justify-between">
          <div className="space-y-6">
            <div className="flex items-center gap-3 px-2 pt-1">
              <Avatar src={data.settings.gymLogo} name={data.settings.gymName} size="md" className="border-[#D4AF37]/50" />
              <div className="min-w-0">
                <div className="font-display font-bold text-base text-zinc-900 dark:text-white truncate">
                  {data.settings.gymName}
                </div>
                <div className="text-[11px] text-[#B45309] dark:text-[#F5B700] capitalize truncate font-medium">
                  {session.displayName} · {session.role}
                </div>
              </div>
            </div>

            <nav className="space-y-1">
              {sidebarItems.map((item) => {
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-[#F5B700] text-black'
                        : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/70 hover:text-zinc-900 dark:hover:text-white'
                    }`}
                  >
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="space-y-2.5 pt-4 border-t border-zinc-200 dark:border-zinc-800">
            <div className="px-2 flex items-center justify-between gap-2">
              <span className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                {firebaseUser.email}
              </span>
              <CloudSyncBadge
                status={syncMeta.status}
                onClick={() => session.role === 'owner' && setActiveTab('settings')}
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTogglePublicLanguage}
                className="flex-1 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:border-[#F5B700] cursor-pointer"
              >
                {language === 'en' ? 'हिन्दी' : 'English'}
              </button>
              <button
                type="button"
                onClick={handleSwitchRole}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:text-red-500 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" /> Switch
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col min-w-0 ${session.role !== 'member' ? 'lg:pl-64' : ''}`}>
        {/* Compact Sticky Top App Bar */}
        <header className="sticky top-0 z-30 h-14 px-4 sm:px-6 border-b border-zinc-200 dark:border-zinc-800 bg-white/90 dark:bg-[#09090B]/90 backdrop-blur-md flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="lg:hidden">
              <Avatar src={data.settings.gymLogo} name={data.settings.gymName} size="sm" />
            </div>
            <h1 className="font-display text-base sm:text-lg font-bold text-zinc-900 dark:text-white truncate">
              {session.role === 'member'
                ? data.settings.gymName
                : sidebarItems.find((i) => i.id === activeTab)?.label || data.settings.gymName}
            </h1>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <CloudSyncBadge
              status={syncMeta.status}
              onClick={() => session.role === 'owner' && setActiveTab('settings')}
            />
            <div className="hidden sm:block">
              <PWAInstallButton compact />
            </div>
            <button
              type="button"
              onClick={handleTogglePublicLanguage}
              className="lg:hidden px-2.5 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300 cursor-pointer"
            >
              {language === 'en' ? 'हिं' : 'EN'}
            </button>
            {(session.role === 'owner' || session.role === 'reception') && (
              <button
                type="button"
                onClick={() => {
                  setEditingMember(null);
                  setMemberModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F5B700] hover:bg-[#FACC15] text-black text-xs font-bold whitespace-nowrap cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">{t('addMember')}</span>
                <span className="sm:hidden">Add</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleSwitchRole}
              title={t('logout')}
              className={`${session.role !== 'member' ? 'lg:hidden' : ''} min-h-[38px] px-3 flex items-center justify-center gap-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-600 dark:text-zinc-300 hover:text-red-500 cursor-pointer`}
            >
              <LogOut className="w-4 h-4" />
              {session.role === 'member' && <span>Logout</span>}
            </button>
          </div>
        </header>

        {/* Secondary Horizontal Pill Scroller on Mobile for Extra Modules */}
        {session.role !== 'member' && sidebarItems.length > 5 && (
          <div className="lg:hidden px-4 py-2 border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-[#0D0D11] flex items-center gap-1.5 overflow-x-auto">
            {sidebarItems
              .filter((item) => !mobileBottomNav.some((b) => b.id === item.id))
              .map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
                    activeTab === item.id
                      ? 'bg-[#F5B700] text-black'
                      : 'bg-white dark:bg-[#121216] border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300'
                  }`}
                >
                  {item.label}
                </button>
              ))}
          </div>
        )}

        {/* Viewport Workspace */}
        <main className="flex-1 p-4 sm:p-6 pb-24 lg:pb-8 max-w-7xl w-full mx-auto">
          {session.role === 'member' ? (
            <MemberPortalView
              data={data}
              memberId={session.memberId || data.members[0]?.id || ''}
              language={language}
              onScanGymQR={handleMemberScanGymQr}
            />
          ) : (
            <>
              {activeTab === 'home' && (
                <DashboardView
                  data={data}
                  language={language}
                  onNavigate={setActiveTab}
                  onOpenNewMember={() => {
                    setEditingMember(null);
                    setMemberModalOpen(true);
                  }}
                  onSelectMember={(m) => setSelectedProfileMemberId(m.id)}
                  onQuickCollectFee={(m) => {
                    setFeePreselectedMember(m);
                    setActiveTab('fees');
                  }}
                  onMarkExit={handleMarkExit}
                  onRegenerateGymQr={handleRegenerateGymQr}
                />
              )}

              {activeTab === 'members' && (
                <MembersView
                  members={visibleMembers}
                  language={language}
                  onAddMember={() => {
                    setEditingMember(null);
                    setMemberModalOpen(true);
                  }}
                  onSelectMember={(m) => setSelectedProfileMemberId(m.id)}
                />
              )}

              {activeTab === 'attendance' && (
                <AttendanceView
                  members={visibleMembers}
                  trainers={data.trainers}
                  attendance={data.attendance}
                  settings={data.settings}
                  language={language}
                  onMarkAttendance={handleMarkAttendance}
                  onMarkExit={handleMarkExit}
                  onRegenerateGymQr={session.role === 'owner' ? handleRegenerateGymQr : undefined}
                  onToggleDuplicateRule={
                    session.role === 'owner'
                      ? () =>
                          handleSaveSettings({
                            ...data.settings,
                            preventDuplicateSameDay: !data.settings.preventDuplicateSameDay,
                          })
                      : undefined
                  }
                />
              )}

              {activeTab === 'fees' && (
                <FeesView
                  members={data.members}
                  payments={data.payments}
                  settings={data.settings}
                  language={language}
                  preselectedMember={feePreselectedMember}
                  onCollectPayment={handleCollectPayment}
                />
              )}

              {activeTab === 'renewals' && (
                <RenewalsView
                  members={data.members}
                  settings={data.settings}
                  language={language}
                  onRenewMembership={handleRenewMembership}
                />
              )}

              {activeTab === 'workouts' && (
                <WorkoutsDietView
                  members={visibleMembers}
                  trainers={data.trainers}
                  workoutPlans={data.workoutPlans}
                  dietPlans={data.dietPlans}
                  language={language}
                  editable={session.role === 'owner' || session.role === 'trainer'}
                  activeTrainerId={session.trainerId}
                  onAddWorkout={handleAddWorkout}
                  onDeleteWorkout={handleDeleteWorkout}
                  onSaveDiet={handleSaveDiet}
                />
              )}

              {activeTab === 'trainers' && (
                <TrainersView
                  trainers={data.trainers}
                  members={data.members}
                  attendance={data.attendance}
                  language={language}
                  onSaveTrainer={handleSaveTrainer}
                  onDeleteTrainer={handleDeleteTrainer}
                  onMarkTrainerAttendance={(trainerId) => {
                    const tNow = getCurrentTimeHHMMSS();
                    return handleMarkAttendance({
                      personType: 'trainer',
                      personIdOrToken: trainerId,
                      date: getTodayISO(),
                      entryTime: tNow,
                      shift: getShiftForTime(tNow),
                      method: 'Manual',
                    });
                  }}
                />
              )}

              {(activeTab === 'reports' || activeTab === 'inactive') && (
                <ReportsInactiveView
                  key={activeTab}
                  data={data}
                  language={language}
                  initialMode={activeTab === 'inactive' ? 'inactive' : 'reports'}
                />
              )}

              {activeTab === 'settings' && (
                <SettingsView
                  data={data}
                  settings={data.settings}
                  language={language}
                  cloudAccount={{
                    uid: firebaseUser.uid,
                    email: firebaseUser.email || '',
                    displayName: firebaseUser.displayName || data.settings.ownerName || 'Owner',
                  }}
                  syncMeta={syncMeta}
                  onSaveSettings={handleSaveSettings}
                  onRestoreBackup={handleRestoreBackup}
                  onResetAllData={handleResetAllData}
                  onTriggerBackupNow={handleTriggerBackupNow}
                  onSwitchRole={handleSwitchRole}
                  onCloudSignOut={handleCloudSignOut}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Fixed Android Bottom Navigation Bar */}
      {mobileBottomNav.length > 0 && (
        <nav
          aria-label="Bottom Navigation"
          className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#0D0D11]/95 backdrop-blur-md border-t border-zinc-200 dark:border-zinc-800 pb-safe"
        >
          <div
            className="grid items-center h-16"
            style={{ gridTemplateColumns: `repeat(${mobileBottomNav.length}, minmax(0, 1fr))` }}
          >
            {mobileBottomNav.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center justify-center min-h-[48px] px-1 transition-colors cursor-pointer ${
                    active
                      ? 'text-[#B45309] dark:text-[#F5B700]'
                      : 'text-zinc-500 dark:text-zinc-400'
                  }`}
                >
                  {item.icon}
                  <span className="text-[10px] font-semibold tracking-tight mt-1 truncate max-w-full">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Modals */}
      <MemberFormModal
        isOpen={memberModalOpen}
        editingMember={editingMember}
        trainers={data.trainers}
        paymentMethods={data.settings.paymentMethods}
        language={language}
        onClose={() => {
          setMemberModalOpen(false);
          setEditingMember(null);
        }}
        onSave={handleSaveMember}
      />

      <MemberProfileModal
        member={selectedProfileMember}
        settings={data.settings}
        payments={data.payments}
        history={data.membershipHistory}
        attendance={data.attendance}
        language={language}
        canDelete={session.role === 'owner' || session.role === 'reception'}
        onClose={() => setSelectedProfileMemberId(null)}
        onEdit={(m) => {
          setSelectedProfileMemberId(null);
          setEditingMember(m);
          setMemberModalOpen(true);
        }}
        onDelete={handleDeleteMember}
        onRenew={() => {
          setSelectedProfileMemberId(null);
          setActiveTab('renewals');
        }}
        onCollectFee={(m) => {
          setSelectedProfileMemberId(null);
          setFeePreselectedMember(m);
          setActiveTab('fees');
        }}
      />

      <OfflineIndicator />

      {toast && (
        <div className="fixed top-16 right-4 z-50 px-4 py-2.5 rounded-xl bg-[#F5B700] text-black text-xs font-bold shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
}
