import type {
  AttendanceRecord,
  AttendanceShift,
  DurationUnit,
  Member,
  ReminderTemplates,
  Trainer,
} from '../types';

export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentTimeHHMM(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

export function getCurrentTimeHHMMSS(): string {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// Morning: 4:00 AM to 12:00 PM | Evening: 12:00 PM to 11:59 PM
export function getShiftForTime(hhmm: string): AttendanceShift {
  const hour = Number((hhmm || '').split(':')[0]);
  if (!Number.isNaN(hour) && hour >= 4 && hour < 12) return 'Morning';
  return 'Evening';
}

export function formatTime12h(hhmmss: string): string {
  if (!hhmmss) return '—';
  const parts = hhmmss.split(':');
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  const s = parts[2] !== undefined ? Number(parts[2]) : NaN;
  if (Number.isNaN(h) || Number.isNaN(m)) return hhmmss;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  const timeCore = !Number.isNaN(s)
    ? `${String(h12).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    : `${String(h12).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  return `${timeCore} ${suffix}`;
}

export function formatDurationMinutes(totalMinutes: number): string {
  const safe = Math.max(0, Math.round(totalMinutes || 0));
  const hrs = Math.floor(safe / 60);
  const mins = safe % 60;
  if (hrs === 0) return `${mins}m`;
  return `${hrs}h ${mins}m`;
}

export function computeLiveDuration(entryTimestamp: string, nowMs: number): {
  minutes: number;
  formatted: string;
} {
  const startMs = Date.parse(entryTimestamp);
  if (Number.isNaN(startMs)) return { minutes: 0, formatted: '0m' };
  const diffSec = Math.max(0, Math.floor((nowMs - startMs) / 1000));
  const hrs = Math.floor(diffSec / 3600);
  const mins = Math.floor((diffSec % 3600) / 60);
  const secs = diffSec % 60;
  const formatted = hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m ${String(secs).padStart(2, '0')}s`;
  return { minutes: Math.floor(diffSec / 60), formatted };
}

export function addDaysISO(baseDateISO: string, days: number): string {
  const [y, m, d] = baseDateISO.split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  dt.setDate(dt.getDate() + days);
  const yy = dt.getFullYear();
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

export function calculateExpiryDate(
  startDateISO: string,
  durationValue: number,
  durationUnit: DurationUnit
): string {
  if (!startDateISO || !durationValue || durationValue <= 0) {
    return startDateISO || getTodayISO();
  }
  const [y, m, d] = startDateISO.split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  if (durationUnit === 'days') {
    dt.setDate(dt.getDate() + durationValue);
  } else if (durationUnit === 'months') {
    dt.setMonth(dt.getMonth() + durationValue);
  } else if (durationUnit === 'years') {
    dt.setFullYear(dt.getFullYear() + durationValue);
  }
  const yy = dt.getFullYear();
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

export function diffDaysBetween(fromISO: string, toISO: string): number {
  const [y1, m1, d1] = fromISO.split('-').map(Number);
  const [y2, m2, d2] = toISO.split('-').map(Number);
  const dt1 = new Date(y1, (m1 || 1) - 1, d1 || 1);
  const dt2 = new Date(y2, (m2 || 1) - 1, d2 || 1);
  return Math.round((dt2.getTime() - dt1.getTime()) / (1000 * 60 * 60 * 24));
}

export function formatINR(amount: number): string {
  const safe = Number.isFinite(amount) ? Math.round(amount) : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(safe);
}

export function formatDateShort(dateISO: string): string {
  if (!dateISO) return '—';
  const [y, m, d] = dateISO.split('-').map(Number);
  const dt = new Date(y, (m || 1) - 1, d || 1);
  return dt.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function isMemberActive(member: Member, todayISO: string): boolean {
  if (member.membershipStatus === 'Inactive') return false;
  return diffDaysBetween(todayISO, member.expiryDate) >= 0;
}

export function getMemberStatus(member: Member, todayISO: string): 'active' | 'expiring' | 'expired' | 'inactive' {
  if (member.membershipStatus === 'Inactive') return 'inactive';
  const daysLeft = diffDaysBetween(todayISO, member.expiryDate);
  if (daysLeft < 0) return 'expired';
  if (daysLeft <= 7) return 'expiring';
  return 'active';
}

export function getFeeStatus(member: Member): 'Paid' | 'Partially Paid' | 'Pending' {
  if (member.remainingAmount <= 0) return 'Paid';
  if (member.amountPaid > 0) return 'Partially Paid';
  return 'Pending';
}

export function computeRemainingBalance(
  membershipFee: number,
  discount: number,
  amountPaid: number
): number {
  const net = Math.max(0, (Number(membershipFee) || 0) - (Number(discount) || 0));
  return Math.max(0, net - (Number(amountPaid) || 0));
}

export function buildGymQrPayload(gymQrSecret: string): string {
  return `GFG-CHECKIN:${gymQrSecret}`;
}

export function exportMembersCSV(members: Member[], todayISO: string) {
  const rows = [
    [
      'Member ID',
      'Name',
      'Mobile',
      'Joining Date',
      'Membership Status',
      'Monthly/Custom Fee',
      'Discount',
      'Amount Paid',
      'Remaining Due',
      'Fee Status',
      'Expiry Date',
      'Trainer',
    ],
    ...members.map((m) => [
      m.id,
      m.name,
      m.whatsapp,
      m.joiningDate,
      isMemberActive(m, todayISO) ? 'Active' : 'Inactive',
      String(m.membershipFee),
      String(m.discount),
      String(m.amountPaid),
      String(m.remainingAmount),
      getFeeStatus(m),
      m.expiryDate,
      m.trainerName || 'Unassigned',
    ]),
  ];
  downloadCSV(rows, `golden-fitness-members-${todayISO}.csv`);
}

export function exportAttendanceCSV(
  attendance: AttendanceRecord[],
  members: Member[],
  trainers: Trainer[],
  todayISO: string
) {
  const memberMap = new Map(members.map((m) => [m.id, m.name]));
  const trainerMap = new Map(trainers.map((t) => [t.id, t.name]));
  const rows = [
    [
      'Type',
      'ID',
      'Name',
      'Date',
      'Entry Time',
      'Exit Time',
      'Session',
      'Total Duration',
      'Status',
      'Method',
    ],
    ...attendance.map((a) => [
      a.personType,
      a.personId,
      (a.personType === 'member' ? memberMap.get(a.personId) : trainerMap.get(a.personId)) || a.personId,
      a.date,
      a.entryTime || '',
      a.exitTime || '—',
      a.shift,
      a.status === 'INSIDE GYM' ? 'Live' : formatDurationMinutes(a.durationMinutes),
      a.status || (a.exitTime ? 'LEFT GYM' : 'INSIDE GYM'),
      a.method,
    ]),
  ];
  downloadCSV(rows, `golden-fitness-attendance-${todayISO}.csv`);
}

function downloadCSV(rows: string[][], filename: string) {
  const csv = rows
    .map((r) => r.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function sanitizePhoneForWhatsApp(rawPhone: string): string {
  const digits = (rawPhone || '').replace(/\D/g, '');
  if (digits.length === 10) return `91${digits}`;
  return digits;
}

export function openWhatsAppMessage(phone: string, message: string): void {
  const cleanPhone = sanitizePhoneForWhatsApp(phone);
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  const link = document.createElement('a');
  link.href = url;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export const DEFAULT_REMINDER_TEMPLATES: ReminderTemplates = {
  feeReminder:
    'Hello {name}, gentle reminder from *{gymName}*. Your custom membership fee is {fee} and pending balance is *{remaining}*. Please clear it at reception. Thank you!',
  renewalReminder:
    'Hello {name}, your membership at *{gymName}* (ID: {memberId}) expires on *{expiryDate}*. Renew at reception to continue your workouts uninterrupted!',
  pendingPayment:
    'Hi {name}, you have a pending fee balance of *{remaining}* at *{gymName}* (Member ID: {memberId}). Kindly pay via Cash or UPI on your next visit.',
  inactiveReminder:
    'Hi {name}, we missed you at *{gymName}*! It has been {daysAbsent}+ days since your last check-in. Stay consistent with your fitness goals — see you today!',
};

function interpolateTemplate(
  template: string,
  vars: Record<string, string>
): string {
  return Object.entries(vars).reduce(
    (acc, [key, value]) => acc.replaceAll(`{${key}}`, value),
    template
  );
}

export function buildWhatsAppTemplates(
  gymName: string,
  member: Member,
  extra?: { amountPaid?: number; receiptNumber?: string; paymentDate?: string; daysAbsent?: number },
  customTemplates?: Partial<ReminderTemplates>
) {
  const vars: Record<string, string> = {
    name: member.name,
    gymName: gymName || 'Golden Fitness Gym',
    memberId: member.id,
    fee: formatINR(Math.max(0, (member.membershipFee || 0) - (member.discount || 0))),
    paid: formatINR(member.amountPaid || 0),
    remaining: formatINR(member.remainingAmount || 0),
    expiryDate: formatDateShort(member.expiryDate),
    daysAbsent: String(extra?.daysAbsent ?? 7),
  };

  const feeTpl = (customTemplates?.feeReminder || '').trim() || DEFAULT_REMINDER_TEMPLATES.feeReminder;
  const renTpl = (customTemplates?.renewalReminder || '').trim() || DEFAULT_REMINDER_TEMPLATES.renewalReminder;
  const penTpl = (customTemplates?.pendingPayment || '').trim() || DEFAULT_REMINDER_TEMPLATES.pendingPayment;
  const inactTpl = (customTemplates?.inactiveReminder || '').trim() || DEFAULT_REMINDER_TEMPLATES.inactiveReminder;

  return {
    feeReminder: interpolateTemplate(feeTpl, vars),
    renewalReminder: interpolateTemplate(renTpl, vars),
    pendingPayment: interpolateTemplate(penTpl, vars),
    inactiveReminder: interpolateTemplate(inactTpl, vars),
    paymentReceipt: `*${gymName} — Payment Receipt*\nReceipt: ${extra?.receiptNumber || 'GFG-REC'}\nMember: ${member.name} (${member.id})\nAmount Paid: *${formatINR(extra?.amountPaid ?? member.amountPaid)}*\nRemaining Balance: *${formatINR(member.remainingAmount)}*\nValid Until: ${formatDateShort(member.expiryDate)}\nDate: ${formatDateShort(extra?.paymentDate || getTodayISO())}\nThank you for training with us!`,
  };
}

export function sanitizeFirestoreId(raw: string, fallbackPrefix = 'ID'): string {
  const cleaned = String(raw || '')
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, '-');
  if (cleaned.length >= 1) return cleaned.slice(0, 128);
  return `${fallbackPrefix}-${Date.now()}`;
}

export function compressImageDataUrl(
  file: File,
  maxDimension = 420,
  quality = 0.72
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const rawDataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!rawDataUrl) {
        resolve('');
        return;
      }
      const img = new Image();
      img.onerror = () => resolve(rawDataUrl.slice(0, 340000));
      img.onload = () => {
        const scale = Math.min(1, maxDimension / Math.max(img.width, img.height, 1));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(rawDataUrl.slice(0, 340000));
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        const compressed = canvas.toDataURL('image/jpeg', quality);
        resolve(compressed.length <= 340000 ? compressed : canvas.toDataURL('image/jpeg', 0.45).slice(0, 340000));
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  });
}

